//#### BEGIN Fo4LitPs_rec1498 ####
// class of identical transcribed code: rec1498 t00000001, rec1506 t00000011
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1498)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 2)  uniform sampler2D t2;
// b06_BSLighting_PS_rec1498_t00000001  technique 0x00000001 = VC
// constants by name (fxp offset table of rec1498, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1498(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b3, b8, b11;
    ivec4 i2, i3;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 48  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 49  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 50  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xyzw = texture(t0, lit_TEXCOORD0.xy).xyzw;                                         // 51  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t0.xyzw, s0
    r2.xy = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 52  sample_indexable(texture2d)(float,float,float,float) r2.xy, v1.xyxx, t1.xyzw, s1
    r2.xy = r2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 53  mad r2.xy, r2.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r2.w = dot(r2.xy, r2.xy);                                                             // 54  dp2 r2.w, r2.xyxx, r2.xyxx
    r2.w = d3d_min(r2.w, 1.0);                                                            // 55  min r2.w, r2.w, l(1.000000)
    r2.w = -r2.w + 1.0;                                                                   // 56  add r2.w, -r2.w, l(1.000000)
    r2.z = d3d_sqrt(r2.w);                                                                // 57  sqrt r2.z, r2.w
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 58  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 59  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 60  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 61  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 62  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 63  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 64  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 65  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 66  add r2.w, -r2.w, l(3.000000)
    r3.y = r3.z * FO4_L_PI;                                                               // 67  mul r3.y, r3.z, l(3.141593)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 68  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 69  exp r3.x, r3.x
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 70  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 71  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 72  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 73  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 74  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 75  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 76  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 77  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 78  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 79  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 80  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 81  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 82  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 83  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 84  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 85  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 86  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 87  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 88  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 89  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 90  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 91  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 92  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 93  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 94  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 95  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 96  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 97  dp4 r2.y, r6.xyzw, r8.xyzw
            r3.z = dot(r7.xyzw, r8.xyzw);                                                 // 98  dp4 r3.z, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 99  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r3.z);                                                        // 100  ge r2.x, r2.x, r3.z
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 101  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 102  else
            r2.x = 1.0;                                                                   // 103  mov r2.x, l(1.000000)
        }                                                                                 // 104  endif
    } else {                                                                              // 105  else
        r2.x = 1.0;                                                                       // 106  mov r2.x, l(1.000000)
    }                                                                                     // 107  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 108  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 109  dp3 r2.z, r0.ywzy, r4.xzwx
    r3.z = dot(DirLightDirection.xzy, r4.xzw);                                            // 110  dp3 r3.z, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 111  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r3.zzz + DirLightDirection.xyz;                                    // 112  mad r6.xyz, -r4.xwzx, r3.zzzz, cb2[0].xyzx
    r3.w = dot(r5.xyz, r6.xyz);                                                           // 113  dp3 r3.w, r5.xyzx, r6.xyzx
    r4.y = r2.y * r2.y;                                                                   // 114  mul r4.y, r2.y, r2.y
    r6.xy = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 115  mad r6.xy, r2.yyyy, r2.yyyy, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.y, r6.x), d3d_div(r4.y, r6.y));                               // 116  div r6.xy, r4.yyyy, r6.xyxx
    r2.y = r6.y * FO4_L_0_45;                                                             // 117  mul r2.y, r6.y, l(0.450000)
    r4.y = -r6.x * 0.5 + 1.0;                                                             // 118  mad r4.y, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r2.z * r2.z + 1.0;                                                            // 119  mad r5.w, -r2.z, r2.z, l(1.000000)
    r6.x = -r3.z * r3.z + 1.0;                                                            // 120  mad r6.x, -r3.z, r3.z, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 121  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 122  sqrt r6.x, r6.x
    r6.y = d3d_max(r2.z, r3.z);                                                           // 123  max r6.y, r2.z, r3.z
    r6.x = d3d_div(r6.x, r6.y);                                                           // 124  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r3.z, 0.0);                                                            // 125  max r6.y, r3.z, l(0.000000)
    r3.w = d3d_max(r3.w, 0.0);                                                            // 126  max r3.w, r3.w, l(0.000000)
    r3.w = r2.y * r3.w;                                                                   // 127  mul r3.w, r2.y, r3.w
    r3.w = r3.w * r6.x + r4.y;                                                            // 128  mad r3.w, r3.w, r6.x, r4.y
    r3.w = r3.w * r6.y;                                                                   // 129  mul r3.w, r3.w, r6.y
    r6.xzw = r3.www * DirLightColor.xyz;                                                  // 130  mul r6.xzw, r3.wwww, cb2[1].xxyz
    r3.w = d3d_min(r6.y, 1.0);                                                            // 131  min r3.w, r6.y, l(1.000000)
    r6.y = d3d_sat(r2.z);                                                                 // 132  mov_sat r6.y, r2.z
    r7.x = -r6.y + 1.0;                                                                   // 133  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 134  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 135  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 136  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 137  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 138  mul r7.y, r7.y, r7.x
    r7.y = r3.w * r7.y;                                                                   // 139  mul r7.y, r3.w, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 140  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r2.www * r7.yzw;                                                             // 141  mul r7.yzw, r2.wwww, r7.yyzw
    r6.xzw = r6.xzw * r2.xxx + r7.yzw;                                                    // 142  mad r6.xzw, r6.xxzw, r2.xxxx, r7.yyzw
    r7.yzw = r1.xyz * LightingEffectParams.yyy;                                           // 143  mul r7.yzw, r1.xxyz, cb1[7].yyyy
    r8.x = d3d_sat(-r3.z);                                                                // 144  mov_sat r8.x, -r3.z
    r7.yzw = r7.yzw * r8.xxx;                                                             // 145  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 146  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r3.z = r3.z + LightingEffectParams.x;                                                 // 147  add r3.z, r3.z, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 148  add r7.y, cb1[7].x, l(1.000000)
    r3.z = d3d_sat(d3d_div(r3.z, r7.y));                                                  // 149  div_sat r3.z, r3.z, r7.y
    r3.z = -r3.w + r3.z;                                                                  // 150  add r3.z, -r3.w, r3.z
    r3.z = d3d_max(r3.z, 0.0);                                                            // 151  max r3.z, r3.z, l(0.000000)
    r7.yzw = r3.zzz * DirLightColor.xyz;                                                  // 152  mul r7.yzw, r3.zzzz, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xyz + r6.xzw;                                                    // 153  mad r6.xzw, r7.yyzw, r1.xxyz, r6.xxzw
    r6.xzw = r2.xxx * r6.xzw;                                                             // 154  mul r6.xzw, r2.xxxx, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 155  mad r7.yzw, v6.xxyz, r0.xxxx, cb2[0].xxyz
    r3.z = dot(r7.yzw, r7.yzw);                                                           // 156  dp3 r3.z, r7.yzwy, r7.yzwy
    r3.z = d3d_rsq(r3.z);                                                                 // 157  rsq r3.z, r3.z
    r7.yzw = r3.zzz * r7.yzw;                                                             // 158  mul r7.yzw, r3.zzzz, r7.yyzw
    r3.z = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 159  dp3_sat r3.z, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r4.xzw));                                                  // 160  dp3_sat r7.y, r7.ywzy, r4.xzwx
    r7.z = r3.x + 2.0;                                                                    // 161  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 162  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 163  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 164  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 165  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 166  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r3.z, FO4_L_2POW_M23);                                                 // 167  max r8.x, r3.z, l(0.000000)
    r8.y = d3d_min(r3.w, r6.y);                                                           // 168  min r8.y, r3.w, r6.y
    r7.y = r7.y + r7.y;                                                                   // 169  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 170  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 171  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 172  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r3.w, r6.y);                                                           // 173  div r8.w, r3.w, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 174  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 175  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 176  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 177  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 178  movc r7.y, r8.z, r7.y, r8.x
    r3.z = -r3.z + 1.0;                                                                   // 179  add r3.z, -r3.z, l(1.000000)
    r8.y = r3.z * r3.z;                                                                   // 180  mul r8.y, r3.z, r3.z
    r8.y = r8.y * r8.y;                                                                   // 181  mul r8.y, r8.y, r8.y
    r8.z = r3.z * r8.y;                                                                   // 182  mul r8.z, r3.z, r8.y
    r3.z = -r3.z * r8.y + 1.0;                                                            // 183  mad r3.z, -r3.z, r8.y, l(1.000000)
    r3.z = r3.z * FO4_L_0_2 + r8.z;                                                       // 184  mad r3.z, r3.z, l(0.200000), r8.z
    r3.z = d3d_min(r3.z, 1.0);                                                            // 185  min r3.z, r3.z, l(1.000000)
    r3.z = r7.y * r3.z;                                                                   // 186  mul r3.z, r7.y, r3.z
    r3.z = r7.w * r3.z;                                                                   // 187  mul r3.z, r7.w, r3.z
    r3.z = r3.z * 0.25;                                                                   // 188  mul r3.z, r3.z, l(0.250000)
    r3.z = d3d_min(r3.z, 15.0);                                                           // 189  min r3.z, r3.z, l(15.000000)
    r3.z = r3.z * r3.y;                                                                   // 190  mul r3.z, r3.z, r3.y
    r8.yzw = r3.zzz * DirLightColor.xyz;                                                  // 191  mul r8.yzw, r3.zzzz, cb2[1].xxyz
    r8.yzw = r3.www * r8.yzw;                                                             // 192  mul r8.yzw, r3.wwww, r8.yyzw
    r8.yzw = r2.xxx * r8.yzw;                                                             // 193  mul r8.yzw, r2.xxxx, r8.yyzw
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 194  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 195  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 196  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 197  max r2.x, r2.x, l(0.000000)
    b3.z = (0.0 < r2.x);                                                                  // 198  lt r3.z, l(0.000000), r2.x
    if (b3.z) {                                                                           // 199  if_nz r3.z
        r9.xyz = r6.xzw;                                                                  // 200  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 201  mov r10.xyz, r8.yzwy
        i3.z = 0;                                                                         // 202  mov r3.z, l(0)
        for (;;) {                                                                        // 203  loop
            r3.w = float(i3.z);                                                           // 204  itof r3.w, r3.z
            b3.w = (r3.w >= r2.x);                                                        // 205  ge r3.w, r3.w, r2.x
            if (b3.w) break;                                                              // 206  breakc_nz r3.w
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i3.z + 13).xyz;                    // 207  add r11.xyz, -v2.xyzx, cb2[r3.z + 13].xyzx
            r3.w = dot(r11.xyz, r11.xyz);                                                 // 208  dp3 r3.w, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r3.w);                                                        // 209  sqrt r7.y, r3.w
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i3.z + 13).w));                      // 210  div_sat r7.y, r7.y, cb2[r3.z + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 211  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 212  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 213  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 214  exp r7.y, r7.y
            r3.w = d3d_rsq(r3.w);                                                         // 215  rsq r3.w, r3.w
            r11.xyz = r3.www * r11.xyz;                                                   // 216  mul r11.xyz, r3.wwww, r11.xyzx
            r3.w = dot(r11.xzy, r4.xzw);                                                  // 217  dp3 r3.w, r11.xzyx, r4.xzwx
            r12.xyz = -r4.xwz * r3.www + r11.xyz;                                         // 218  mad r12.xyz, -r4.xwzx, r3.wwww, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 219  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r3.w * r3.w + 1.0;                                                    // 220  mad r9.w, -r3.w, r3.w, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 221  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 222  sqrt r9.w, r9.w
            r10.w = d3d_max(r2.z, r3.w);                                                  // 223  max r10.w, r2.z, r3.w
            r9.w = d3d_div(r9.w, r10.w);                                                  // 224  div r9.w, r9.w, r10.w
            r3.w = d3d_max(r3.w, 0.0);                                                    // 225  max r3.w, r3.w, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 226  max r7.w, r7.w, l(0.000000)
            r7.w = r2.y * r7.w;                                                           // 227  mul r7.w, r2.y, r7.w
            r7.w = r7.w * r9.w + r4.y;                                                    // 228  mad r7.w, r7.w, r9.w, r4.y
            r7.w = r3.w * r7.w;                                                           // 229  mul r7.w, r3.w, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 230  mul r12.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 231  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 232  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r3.w = d3d_min(r3.w, 1.0);                                                    // 233  min r3.w, r3.w, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 234  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 235  mul r7.w, r7.w, r7.x
            r7.w = r3.w * r7.w;                                                           // 236  mul r7.w, r3.w, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 237  mul r13.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r13.xyz = r2.www * r13.xyz;                                                   // 238  mul r13.xyz, r2.wwww, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 239  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 240  mad r11.xyz, v6.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 241  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 242  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 243  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 244  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r4.xzw));                                         // 245  dp3_sat r9.w, r11.xzyx, r4.xzwx
            r10.w = d3d_log2(r9.w);                                                       // 246  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 247  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 248  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 249  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 250  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r3.w, r6.y);                                                  // 251  min r11.y, r3.w, r6.y
            r9.w = r9.w + r9.w;                                                           // 252  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 253  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 254  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 255  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r3.w, r6.y);                                                  // 256  div r11.w, r3.w, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 257  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 258  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 259  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 260  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 261  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 262  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 263  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 264  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 265  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 266  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 267  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 268  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 269  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 270  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 271  min r7.w, r7.w, l(15.000000)
            r7.w = r3.y * r7.w;                                                           // 272  mul r7.w, r3.y, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 273  mul r11.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r11.xyz = r3.www * r11.xyz;                                                   // 274  mul r11.xyz, r3.wwww, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 275  mul r10.xyz, r7.yyyy, r11.xyzx
            i3.z = (i3.z + 1);                                                            // 276  iadd r3.z, r3.z, l(1)
        }                                                                                 // 277  endloop
        r6.xzw = r9.xyz;                                                                  // 278  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 279  mov r8.yzw, r10.xxyz
    } else { i3.z = (b3.z ? -1 : 0); }                                                    // 280  endif
    r0.xyz = r6.xzw + EmitColor.xyz;                                                      // 281  add r0.xyz, r6.xzwx, cb2[3].yzwy
    r0.xyz = r1.xyz * r0.xyz;                                                             // 282  mul r0.xyz, r1.xyzx, r0.xyzx
    o0.xyz = r0.xyz * lit_COLOR0.xyz + r8.yzw;                                            // 283  mad o0.xyz, r0.xyzx, v7.xyzx, r8.yzwy
    r0.x = r1.w * lit_COLOR0.w + -AlphaTestRef.x;                                         // 284  mad r0.x, r1.w, v7.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 285  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 286  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 287  mov o0.w, cb2[2].z
    return;                                                                               // 288  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1498(o0, kill);
}
//#### END Fo4LitPs_rec1498 ####
//#### BEGIN Fo4LitPs_rec1499 ####
// class of identical transcribed code: rec1499 t00000401
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1499)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 2)  uniform sampler2D t2;
// b06_BSLighting_PS_rec1499_t00000401  technique 0x00000401 = VC|FACE
// constants by name (fxp offset table of rec1499, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1499(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b3, b8, b11;
    ivec4 i2, i3;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 48  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 49  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 50  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xyzw = texture(t0, lit_TEXCOORD0.xy).xyzw;                                         // 51  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t0.xyzw, s0
    r2.xy = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 52  sample_indexable(texture2d)(float,float,float,float) r2.xy, v1.xyxx, t1.xyzw, s1
    r2.xy = r2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 53  mad r2.xy, r2.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r2.w = dot(r2.xy, r2.xy);                                                             // 54  dp2 r2.w, r2.xyxx, r2.xyxx
    r2.w = d3d_min(r2.w, 1.0);                                                            // 55  min r2.w, r2.w, l(1.000000)
    r2.w = -r2.w + 1.0;                                                                   // 56  add r2.w, -r2.w, l(1.000000)
    r2.z = d3d_sqrt(r2.w);                                                                // 57  sqrt r2.z, r2.w
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 58  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 59  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 60  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 61  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 62  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 63  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 64  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 65  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 66  add r2.w, -r2.w, l(3.000000)
    r3.y = r3.z * FO4_L_PI;                                                               // 67  mul r3.y, r3.z, l(3.141593)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 68  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 69  exp r3.x, r3.x
    r4.xyz = r1.xyz + r1.xyz;                                                             // 70  add r4.xyz, r1.xyzx, r1.xyzx
    r4.xyz = -r4.xyz * r1.xyz + r4.xyz;                                                   // 71  mad r4.xyz, -r4.xyzx, r1.xyzx, r4.xyzx
    r1.xyz = r1.xyz * r1.xyz + r4.xyz;                                                    // 72  mad r1.xyz, r1.xyzx, r1.xyzx, r4.xyzx
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 73  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 74  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 75  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 76  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 77  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 78  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 79  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 80  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 81  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 82  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 83  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 84  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 85  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 86  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 87  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 88  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 89  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 90  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 91  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 92  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 93  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 94  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 95  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 96  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 97  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 98  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 99  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 100  dp4 r2.y, r6.xyzw, r8.xyzw
            r3.z = dot(r7.xyzw, r8.xyzw);                                                 // 101  dp4 r3.z, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 102  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r3.z);                                                        // 103  ge r2.x, r2.x, r3.z
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 104  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 105  else
            r2.x = 1.0;                                                                   // 106  mov r2.x, l(1.000000)
        }                                                                                 // 107  endif
    } else {                                                                              // 108  else
        r2.x = 1.0;                                                                       // 109  mov r2.x, l(1.000000)
    }                                                                                     // 110  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 111  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 112  dp3 r2.z, r0.ywzy, r4.xzwx
    r3.z = dot(DirLightDirection.xzy, r4.xzw);                                            // 113  dp3 r3.z, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 114  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r3.zzz + DirLightDirection.xyz;                                    // 115  mad r6.xyz, -r4.xwzx, r3.zzzz, cb2[0].xyzx
    r3.w = dot(r5.xyz, r6.xyz);                                                           // 116  dp3 r3.w, r5.xyzx, r6.xyzx
    r4.y = r2.y * r2.y;                                                                   // 117  mul r4.y, r2.y, r2.y
    r6.xy = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 118  mad r6.xy, r2.yyyy, r2.yyyy, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.y, r6.x), d3d_div(r4.y, r6.y));                               // 119  div r6.xy, r4.yyyy, r6.xyxx
    r2.y = r6.y * FO4_L_0_45;                                                             // 120  mul r2.y, r6.y, l(0.450000)
    r4.y = -r6.x * 0.5 + 1.0;                                                             // 121  mad r4.y, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r2.z * r2.z + 1.0;                                                            // 122  mad r5.w, -r2.z, r2.z, l(1.000000)
    r6.x = -r3.z * r3.z + 1.0;                                                            // 123  mad r6.x, -r3.z, r3.z, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 124  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 125  sqrt r6.x, r6.x
    r6.y = d3d_max(r2.z, r3.z);                                                           // 126  max r6.y, r2.z, r3.z
    r6.x = d3d_div(r6.x, r6.y);                                                           // 127  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r3.z, 0.0);                                                            // 128  max r6.y, r3.z, l(0.000000)
    r3.w = d3d_max(r3.w, 0.0);                                                            // 129  max r3.w, r3.w, l(0.000000)
    r3.w = r2.y * r3.w;                                                                   // 130  mul r3.w, r2.y, r3.w
    r3.w = r3.w * r6.x + r4.y;                                                            // 131  mad r3.w, r3.w, r6.x, r4.y
    r3.w = r3.w * r6.y;                                                                   // 132  mul r3.w, r3.w, r6.y
    r6.xzw = r3.www * DirLightColor.xyz;                                                  // 133  mul r6.xzw, r3.wwww, cb2[1].xxyz
    r3.w = d3d_min(r6.y, 1.0);                                                            // 134  min r3.w, r6.y, l(1.000000)
    r6.y = d3d_sat(r2.z);                                                                 // 135  mov_sat r6.y, r2.z
    r7.x = -r6.y + 1.0;                                                                   // 136  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 137  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 138  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 139  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 140  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 141  mul r7.y, r7.y, r7.x
    r7.y = r3.w * r7.y;                                                                   // 142  mul r7.y, r3.w, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 143  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r2.www * r7.yzw;                                                             // 144  mul r7.yzw, r2.wwww, r7.yyzw
    r6.xzw = r6.xzw * r2.xxx + r7.yzw;                                                    // 145  mad r6.xzw, r6.xxzw, r2.xxxx, r7.yyzw
    r7.yzw = r1.xyz * LightingEffectParams.yyy;                                           // 146  mul r7.yzw, r1.xxyz, cb1[7].yyyy
    r8.x = d3d_sat(-r3.z);                                                                // 147  mov_sat r8.x, -r3.z
    r7.yzw = r7.yzw * r8.xxx;                                                             // 148  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 149  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r3.z = r3.z + LightingEffectParams.x;                                                 // 150  add r3.z, r3.z, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 151  add r7.y, cb1[7].x, l(1.000000)
    r3.z = d3d_sat(d3d_div(r3.z, r7.y));                                                  // 152  div_sat r3.z, r3.z, r7.y
    r3.z = -r3.w + r3.z;                                                                  // 153  add r3.z, -r3.w, r3.z
    r3.z = d3d_max(r3.z, 0.0);                                                            // 154  max r3.z, r3.z, l(0.000000)
    r7.yzw = r3.zzz * DirLightColor.xyz;                                                  // 155  mul r7.yzw, r3.zzzz, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xyz + r6.xzw;                                                    // 156  mad r6.xzw, r7.yyzw, r1.xxyz, r6.xxzw
    r6.xzw = r2.xxx * r6.xzw;                                                             // 157  mul r6.xzw, r2.xxxx, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 158  mad r7.yzw, v6.xxyz, r0.xxxx, cb2[0].xxyz
    r3.z = dot(r7.yzw, r7.yzw);                                                           // 159  dp3 r3.z, r7.yzwy, r7.yzwy
    r3.z = d3d_rsq(r3.z);                                                                 // 160  rsq r3.z, r3.z
    r7.yzw = r3.zzz * r7.yzw;                                                             // 161  mul r7.yzw, r3.zzzz, r7.yyzw
    r3.z = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 162  dp3_sat r3.z, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r4.xzw));                                                  // 163  dp3_sat r7.y, r7.ywzy, r4.xzwx
    r7.z = r3.x + 2.0;                                                                    // 164  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 165  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 166  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 167  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 168  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 169  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r3.z, FO4_L_2POW_M23);                                                 // 170  max r8.x, r3.z, l(0.000000)
    r8.y = d3d_min(r3.w, r6.y);                                                           // 171  min r8.y, r3.w, r6.y
    r7.y = r7.y + r7.y;                                                                   // 172  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 173  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 174  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 175  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r3.w, r6.y);                                                           // 176  div r8.w, r3.w, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 177  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 178  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 179  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 180  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 181  movc r7.y, r8.z, r7.y, r8.x
    r3.z = -r3.z + 1.0;                                                                   // 182  add r3.z, -r3.z, l(1.000000)
    r8.y = r3.z * r3.z;                                                                   // 183  mul r8.y, r3.z, r3.z
    r8.y = r8.y * r8.y;                                                                   // 184  mul r8.y, r8.y, r8.y
    r8.z = r3.z * r8.y;                                                                   // 185  mul r8.z, r3.z, r8.y
    r3.z = -r3.z * r8.y + 1.0;                                                            // 186  mad r3.z, -r3.z, r8.y, l(1.000000)
    r3.z = r3.z * FO4_L_0_2 + r8.z;                                                       // 187  mad r3.z, r3.z, l(0.200000), r8.z
    r3.z = d3d_min(r3.z, 1.0);                                                            // 188  min r3.z, r3.z, l(1.000000)
    r3.z = r7.y * r3.z;                                                                   // 189  mul r3.z, r7.y, r3.z
    r3.z = r7.w * r3.z;                                                                   // 190  mul r3.z, r7.w, r3.z
    r3.z = r3.z * 0.25;                                                                   // 191  mul r3.z, r3.z, l(0.250000)
    r3.z = d3d_min(r3.z, 15.0);                                                           // 192  min r3.z, r3.z, l(15.000000)
    r3.z = r3.z * r3.y;                                                                   // 193  mul r3.z, r3.z, r3.y
    r8.yzw = r3.zzz * DirLightColor.xyz;                                                  // 194  mul r8.yzw, r3.zzzz, cb2[1].xxyz
    r8.yzw = r3.www * r8.yzw;                                                             // 195  mul r8.yzw, r3.wwww, r8.yyzw
    r8.yzw = r2.xxx * r8.yzw;                                                             // 196  mul r8.yzw, r2.xxxx, r8.yyzw
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 197  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 198  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 199  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 200  max r2.x, r2.x, l(0.000000)
    b3.z = (0.0 < r2.x);                                                                  // 201  lt r3.z, l(0.000000), r2.x
    if (b3.z) {                                                                           // 202  if_nz r3.z
        r9.xyz = r6.xzw;                                                                  // 203  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 204  mov r10.xyz, r8.yzwy
        i3.z = 0;                                                                         // 205  mov r3.z, l(0)
        for (;;) {                                                                        // 206  loop
            r3.w = float(i3.z);                                                           // 207  itof r3.w, r3.z
            b3.w = (r3.w >= r2.x);                                                        // 208  ge r3.w, r3.w, r2.x
            if (b3.w) break;                                                              // 209  breakc_nz r3.w
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i3.z + 13).xyz;                    // 210  add r11.xyz, -v2.xyzx, cb2[r3.z + 13].xyzx
            r3.w = dot(r11.xyz, r11.xyz);                                                 // 211  dp3 r3.w, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r3.w);                                                        // 212  sqrt r7.y, r3.w
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i3.z + 13).w));                      // 213  div_sat r7.y, r7.y, cb2[r3.z + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 214  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 215  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 216  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 217  exp r7.y, r7.y
            r3.w = d3d_rsq(r3.w);                                                         // 218  rsq r3.w, r3.w
            r11.xyz = r3.www * r11.xyz;                                                   // 219  mul r11.xyz, r3.wwww, r11.xyzx
            r3.w = dot(r11.xzy, r4.xzw);                                                  // 220  dp3 r3.w, r11.xzyx, r4.xzwx
            r12.xyz = -r4.xwz * r3.www + r11.xyz;                                         // 221  mad r12.xyz, -r4.xwzx, r3.wwww, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 222  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r3.w * r3.w + 1.0;                                                    // 223  mad r9.w, -r3.w, r3.w, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 224  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 225  sqrt r9.w, r9.w
            r10.w = d3d_max(r2.z, r3.w);                                                  // 226  max r10.w, r2.z, r3.w
            r9.w = d3d_div(r9.w, r10.w);                                                  // 227  div r9.w, r9.w, r10.w
            r3.w = d3d_max(r3.w, 0.0);                                                    // 228  max r3.w, r3.w, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 229  max r7.w, r7.w, l(0.000000)
            r7.w = r2.y * r7.w;                                                           // 230  mul r7.w, r2.y, r7.w
            r7.w = r7.w * r9.w + r4.y;                                                    // 231  mad r7.w, r7.w, r9.w, r4.y
            r7.w = r3.w * r7.w;                                                           // 232  mul r7.w, r3.w, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 233  mul r12.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 234  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 235  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r3.w = d3d_min(r3.w, 1.0);                                                    // 236  min r3.w, r3.w, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 237  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 238  mul r7.w, r7.w, r7.x
            r7.w = r3.w * r7.w;                                                           // 239  mul r7.w, r3.w, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 240  mul r13.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r13.xyz = r2.www * r13.xyz;                                                   // 241  mul r13.xyz, r2.wwww, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 242  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 243  mad r11.xyz, v6.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 244  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 245  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 246  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 247  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r4.xzw));                                         // 248  dp3_sat r9.w, r11.xzyx, r4.xzwx
            r10.w = d3d_log2(r9.w);                                                       // 249  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 250  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 251  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 252  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 253  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r3.w, r6.y);                                                  // 254  min r11.y, r3.w, r6.y
            r9.w = r9.w + r9.w;                                                           // 255  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 256  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 257  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 258  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r3.w, r6.y);                                                  // 259  div r11.w, r3.w, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 260  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 261  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 262  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 263  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 264  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 265  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 266  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 267  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 268  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 269  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 270  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 271  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 272  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 273  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 274  min r7.w, r7.w, l(15.000000)
            r7.w = r3.y * r7.w;                                                           // 275  mul r7.w, r3.y, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 276  mul r11.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r11.xyz = r3.www * r11.xyz;                                                   // 277  mul r11.xyz, r3.wwww, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 278  mul r10.xyz, r7.yyyy, r11.xyzx
            i3.z = (i3.z + 1);                                                            // 279  iadd r3.z, r3.z, l(1)
        }                                                                                 // 280  endloop
        r6.xzw = r9.xyz;                                                                  // 281  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 282  mov r8.yzw, r10.xxyz
    } else { i3.z = (b3.z ? -1 : 0); }                                                    // 283  endif
    r0.xyz = r6.xzw + EmitColor.xyz;                                                      // 284  add r0.xyz, r6.xzwx, cb2[3].yzwy
    r0.xyz = r1.xyz * r0.xyz;                                                             // 285  mul r0.xyz, r1.xyzx, r0.xyzx
    o0.xyz = r0.xyz * lit_COLOR0.xyz + r8.yzw;                                            // 286  mad o0.xyz, r0.xyzx, v7.xyzx, r8.yzwy
    r0.x = r1.w * lit_COLOR0.w + -AlphaTestRef.x;                                         // 287  mad r0.x, r1.w, v7.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 288  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 289  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 290  mov o0.w, cb2[2].z
    return;                                                                               // 291  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1499(o0, kill);
}
//#### END Fo4LitPs_rec1499 ####
//#### BEGIN Fo4LitPs_rec1500 ####
// class of identical transcribed code: rec1500 t00000501
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
uniform vec4 TintColor;                   // name 21, cb1, writer SM 0x14223ABFA..E1B
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1500)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 2)  uniform sampler2D t2;
// b06_BSLighting_PS_rec1500_t00000501  technique 0x00000501 = VC|SKIN_TINT
// constants by name (fxp offset table of rec1500, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, TintColor = cb1[1].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1500(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b3, b8, b11;
    ivec4 i2, i3;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 48  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 49  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 50  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xyzw = texture(t0, lit_TEXCOORD0.xy).xyzw;                                         // 51  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t0.xyzw, s0
    r2.xy = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 52  sample_indexable(texture2d)(float,float,float,float) r2.xy, v1.xyxx, t1.xyzw, s1
    r2.xy = r2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 53  mad r2.xy, r2.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r2.w = dot(r2.xy, r2.xy);                                                             // 54  dp2 r2.w, r2.xyxx, r2.xyxx
    r2.w = d3d_min(r2.w, 1.0);                                                            // 55  min r2.w, r2.w, l(1.000000)
    r2.w = -r2.w + 1.0;                                                                   // 56  add r2.w, -r2.w, l(1.000000)
    r2.z = d3d_sqrt(r2.w);                                                                // 57  sqrt r2.z, r2.w
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 58  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 59  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 60  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 61  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 62  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 63  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 64  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 65  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 66  add r2.w, -r2.w, l(3.000000)
    r3.y = r3.z * FO4_L_PI;                                                               // 67  mul r3.y, r3.z, l(3.141593)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 68  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 69  exp r3.x, r3.x
    r4.xyz = r1.xyz * TintColor.xyz;                                                      // 70  mul r4.xyz, r1.xyzx, cb1[1].xyzx
    r4.xyz = r4.xyz + r4.xyz;                                                             // 71  add r4.xyz, r4.xyzx, r4.xyzx
    r4.xyz = -r4.xyz * r1.xyz + r4.xyz;                                                   // 72  mad r4.xyz, -r4.xyzx, r1.xyzx, r4.xyzx
    r1.xyz = r1.xyz * r1.xyz + r4.xyz;                                                    // 73  mad r1.xyz, r1.xyzx, r1.xyzx, r4.xyzx
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 74  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 75  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 76  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 77  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 78  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 79  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 80  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 81  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 82  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 83  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 84  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 85  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 86  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 87  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 88  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 89  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 90  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 91  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 92  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 93  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 94  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 95  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 96  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 97  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 98  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 99  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 100  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 101  dp4 r2.y, r6.xyzw, r8.xyzw
            r3.z = dot(r7.xyzw, r8.xyzw);                                                 // 102  dp4 r3.z, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 103  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r3.z);                                                        // 104  ge r2.x, r2.x, r3.z
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 105  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 106  else
            r2.x = 1.0;                                                                   // 107  mov r2.x, l(1.000000)
        }                                                                                 // 108  endif
    } else {                                                                              // 109  else
        r2.x = 1.0;                                                                       // 110  mov r2.x, l(1.000000)
    }                                                                                     // 111  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 112  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 113  dp3 r2.z, r0.ywzy, r4.xzwx
    r3.z = dot(DirLightDirection.xzy, r4.xzw);                                            // 114  dp3 r3.z, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 115  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r3.zzz + DirLightDirection.xyz;                                    // 116  mad r6.xyz, -r4.xwzx, r3.zzzz, cb2[0].xyzx
    r3.w = dot(r5.xyz, r6.xyz);                                                           // 117  dp3 r3.w, r5.xyzx, r6.xyzx
    r4.y = r2.y * r2.y;                                                                   // 118  mul r4.y, r2.y, r2.y
    r6.xy = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 119  mad r6.xy, r2.yyyy, r2.yyyy, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.y, r6.x), d3d_div(r4.y, r6.y));                               // 120  div r6.xy, r4.yyyy, r6.xyxx
    r2.y = r6.y * FO4_L_0_45;                                                             // 121  mul r2.y, r6.y, l(0.450000)
    r4.y = -r6.x * 0.5 + 1.0;                                                             // 122  mad r4.y, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r2.z * r2.z + 1.0;                                                            // 123  mad r5.w, -r2.z, r2.z, l(1.000000)
    r6.x = -r3.z * r3.z + 1.0;                                                            // 124  mad r6.x, -r3.z, r3.z, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 125  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 126  sqrt r6.x, r6.x
    r6.y = d3d_max(r2.z, r3.z);                                                           // 127  max r6.y, r2.z, r3.z
    r6.x = d3d_div(r6.x, r6.y);                                                           // 128  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r3.z, 0.0);                                                            // 129  max r6.y, r3.z, l(0.000000)
    r3.w = d3d_max(r3.w, 0.0);                                                            // 130  max r3.w, r3.w, l(0.000000)
    r3.w = r2.y * r3.w;                                                                   // 131  mul r3.w, r2.y, r3.w
    r3.w = r3.w * r6.x + r4.y;                                                            // 132  mad r3.w, r3.w, r6.x, r4.y
    r3.w = r3.w * r6.y;                                                                   // 133  mul r3.w, r3.w, r6.y
    r6.xzw = r3.www * DirLightColor.xyz;                                                  // 134  mul r6.xzw, r3.wwww, cb2[1].xxyz
    r3.w = d3d_min(r6.y, 1.0);                                                            // 135  min r3.w, r6.y, l(1.000000)
    r6.y = d3d_sat(r2.z);                                                                 // 136  mov_sat r6.y, r2.z
    r7.x = -r6.y + 1.0;                                                                   // 137  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 138  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 139  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 140  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 141  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 142  mul r7.y, r7.y, r7.x
    r7.y = r3.w * r7.y;                                                                   // 143  mul r7.y, r3.w, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 144  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r2.www * r7.yzw;                                                             // 145  mul r7.yzw, r2.wwww, r7.yyzw
    r6.xzw = r6.xzw * r2.xxx + r7.yzw;                                                    // 146  mad r6.xzw, r6.xxzw, r2.xxxx, r7.yyzw
    r7.yzw = r1.xyz * LightingEffectParams.yyy;                                           // 147  mul r7.yzw, r1.xxyz, cb1[7].yyyy
    r8.x = d3d_sat(-r3.z);                                                                // 148  mov_sat r8.x, -r3.z
    r7.yzw = r7.yzw * r8.xxx;                                                             // 149  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 150  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r3.z = r3.z + LightingEffectParams.x;                                                 // 151  add r3.z, r3.z, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 152  add r7.y, cb1[7].x, l(1.000000)
    r3.z = d3d_sat(d3d_div(r3.z, r7.y));                                                  // 153  div_sat r3.z, r3.z, r7.y
    r3.z = -r3.w + r3.z;                                                                  // 154  add r3.z, -r3.w, r3.z
    r3.z = d3d_max(r3.z, 0.0);                                                            // 155  max r3.z, r3.z, l(0.000000)
    r7.yzw = r3.zzz * DirLightColor.xyz;                                                  // 156  mul r7.yzw, r3.zzzz, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xyz + r6.xzw;                                                    // 157  mad r6.xzw, r7.yyzw, r1.xxyz, r6.xxzw
    r6.xzw = r2.xxx * r6.xzw;                                                             // 158  mul r6.xzw, r2.xxxx, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 159  mad r7.yzw, v6.xxyz, r0.xxxx, cb2[0].xxyz
    r3.z = dot(r7.yzw, r7.yzw);                                                           // 160  dp3 r3.z, r7.yzwy, r7.yzwy
    r3.z = d3d_rsq(r3.z);                                                                 // 161  rsq r3.z, r3.z
    r7.yzw = r3.zzz * r7.yzw;                                                             // 162  mul r7.yzw, r3.zzzz, r7.yyzw
    r3.z = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 163  dp3_sat r3.z, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r4.xzw));                                                  // 164  dp3_sat r7.y, r7.ywzy, r4.xzwx
    r7.z = r3.x + 2.0;                                                                    // 165  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 166  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 167  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 168  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 169  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 170  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r3.z, FO4_L_2POW_M23);                                                 // 171  max r8.x, r3.z, l(0.000000)
    r8.y = d3d_min(r3.w, r6.y);                                                           // 172  min r8.y, r3.w, r6.y
    r7.y = r7.y + r7.y;                                                                   // 173  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 174  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 175  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 176  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r3.w, r6.y);                                                           // 177  div r8.w, r3.w, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 178  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 179  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 180  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 181  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 182  movc r7.y, r8.z, r7.y, r8.x
    r3.z = -r3.z + 1.0;                                                                   // 183  add r3.z, -r3.z, l(1.000000)
    r8.y = r3.z * r3.z;                                                                   // 184  mul r8.y, r3.z, r3.z
    r8.y = r8.y * r8.y;                                                                   // 185  mul r8.y, r8.y, r8.y
    r8.z = r3.z * r8.y;                                                                   // 186  mul r8.z, r3.z, r8.y
    r3.z = -r3.z * r8.y + 1.0;                                                            // 187  mad r3.z, -r3.z, r8.y, l(1.000000)
    r3.z = r3.z * FO4_L_0_2 + r8.z;                                                       // 188  mad r3.z, r3.z, l(0.200000), r8.z
    r3.z = d3d_min(r3.z, 1.0);                                                            // 189  min r3.z, r3.z, l(1.000000)
    r3.z = r7.y * r3.z;                                                                   // 190  mul r3.z, r7.y, r3.z
    r3.z = r7.w * r3.z;                                                                   // 191  mul r3.z, r7.w, r3.z
    r3.z = r3.z * 0.25;                                                                   // 192  mul r3.z, r3.z, l(0.250000)
    r3.z = d3d_min(r3.z, 15.0);                                                           // 193  min r3.z, r3.z, l(15.000000)
    r3.z = r3.z * r3.y;                                                                   // 194  mul r3.z, r3.z, r3.y
    r8.yzw = r3.zzz * DirLightColor.xyz;                                                  // 195  mul r8.yzw, r3.zzzz, cb2[1].xxyz
    r8.yzw = r3.www * r8.yzw;                                                             // 196  mul r8.yzw, r3.wwww, r8.yyzw
    r8.yzw = r2.xxx * r8.yzw;                                                             // 197  mul r8.yzw, r2.xxxx, r8.yyzw
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 198  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 199  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 200  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 201  max r2.x, r2.x, l(0.000000)
    b3.z = (0.0 < r2.x);                                                                  // 202  lt r3.z, l(0.000000), r2.x
    if (b3.z) {                                                                           // 203  if_nz r3.z
        r9.xyz = r6.xzw;                                                                  // 204  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 205  mov r10.xyz, r8.yzwy
        i3.z = 0;                                                                         // 206  mov r3.z, l(0)
        for (;;) {                                                                        // 207  loop
            r3.w = float(i3.z);                                                           // 208  itof r3.w, r3.z
            b3.w = (r3.w >= r2.x);                                                        // 209  ge r3.w, r3.w, r2.x
            if (b3.w) break;                                                              // 210  breakc_nz r3.w
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i3.z + 13).xyz;                    // 211  add r11.xyz, -v2.xyzx, cb2[r3.z + 13].xyzx
            r3.w = dot(r11.xyz, r11.xyz);                                                 // 212  dp3 r3.w, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r3.w);                                                        // 213  sqrt r7.y, r3.w
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i3.z + 13).w));                      // 214  div_sat r7.y, r7.y, cb2[r3.z + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 215  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 216  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 217  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 218  exp r7.y, r7.y
            r3.w = d3d_rsq(r3.w);                                                         // 219  rsq r3.w, r3.w
            r11.xyz = r3.www * r11.xyz;                                                   // 220  mul r11.xyz, r3.wwww, r11.xyzx
            r3.w = dot(r11.xzy, r4.xzw);                                                  // 221  dp3 r3.w, r11.xzyx, r4.xzwx
            r12.xyz = -r4.xwz * r3.www + r11.xyz;                                         // 222  mad r12.xyz, -r4.xwzx, r3.wwww, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 223  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r3.w * r3.w + 1.0;                                                    // 224  mad r9.w, -r3.w, r3.w, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 225  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 226  sqrt r9.w, r9.w
            r10.w = d3d_max(r2.z, r3.w);                                                  // 227  max r10.w, r2.z, r3.w
            r9.w = d3d_div(r9.w, r10.w);                                                  // 228  div r9.w, r9.w, r10.w
            r3.w = d3d_max(r3.w, 0.0);                                                    // 229  max r3.w, r3.w, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 230  max r7.w, r7.w, l(0.000000)
            r7.w = r2.y * r7.w;                                                           // 231  mul r7.w, r2.y, r7.w
            r7.w = r7.w * r9.w + r4.y;                                                    // 232  mad r7.w, r7.w, r9.w, r4.y
            r7.w = r3.w * r7.w;                                                           // 233  mul r7.w, r3.w, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 234  mul r12.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 235  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 236  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r3.w = d3d_min(r3.w, 1.0);                                                    // 237  min r3.w, r3.w, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 238  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 239  mul r7.w, r7.w, r7.x
            r7.w = r3.w * r7.w;                                                           // 240  mul r7.w, r3.w, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 241  mul r13.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r13.xyz = r2.www * r13.xyz;                                                   // 242  mul r13.xyz, r2.wwww, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 243  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 244  mad r11.xyz, v6.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 245  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 246  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 247  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 248  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r4.xzw));                                         // 249  dp3_sat r9.w, r11.xzyx, r4.xzwx
            r10.w = d3d_log2(r9.w);                                                       // 250  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 251  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 252  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 253  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 254  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r3.w, r6.y);                                                  // 255  min r11.y, r3.w, r6.y
            r9.w = r9.w + r9.w;                                                           // 256  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 257  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 258  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 259  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r3.w, r6.y);                                                  // 260  div r11.w, r3.w, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 261  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 262  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 263  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 264  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 265  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 266  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 267  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 268  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 269  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 270  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 271  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 272  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 273  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 274  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 275  min r7.w, r7.w, l(15.000000)
            r7.w = r3.y * r7.w;                                                           // 276  mul r7.w, r3.y, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 277  mul r11.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r11.xyz = r3.www * r11.xyz;                                                   // 278  mul r11.xyz, r3.wwww, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 279  mul r10.xyz, r7.yyyy, r11.xyzx
            i3.z = (i3.z + 1);                                                            // 280  iadd r3.z, r3.z, l(1)
        }                                                                                 // 281  endloop
        r6.xzw = r9.xyz;                                                                  // 282  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 283  mov r8.yzw, r10.xxyz
    } else { i3.z = (b3.z ? -1 : 0); }                                                    // 284  endif
    r0.xyz = r6.xzw + EmitColor.xyz;                                                      // 285  add r0.xyz, r6.xzwx, cb2[3].yzwy
    r0.xyz = r1.xyz * r0.xyz;                                                             // 286  mul r0.xyz, r1.xyzx, r0.xyzx
    o0.xyz = r0.xyz * lit_COLOR0.xyz + r8.yzw;                                            // 287  mad o0.xyz, r0.xyzx, v7.xyzx, r8.yzwy
    r0.x = r1.w * lit_COLOR0.w + -AlphaTestRef.x;                                         // 288  mad r0.x, r1.w, v7.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 289  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 290  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 291  mov o0.w, cb2[2].z
    return;                                                                               // 292  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1500(o0, kill);
}
//#### END Fo4LitPs_rec1500 ####
//#### BEGIN Fo4LitPs_rec1501 ####
// class of identical transcribed code: rec1501 t00000081
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 MenuScreenParams;            // name 28, cb0, writer ST 0x14223A742
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1501)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 12)  uniform sampler2D t12;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 2)  uniform sampler2D t2;
// b06_BSLighting_PS_rec1501_t00000081  technique 0x00000081 = VC|MENU_SCREEN
// constants by name (fxp offset table of rec1501, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, LightingEffectParams = cb1[7].x, MenuScreenParams = cb0[0].x
void Fo4LitPs_rec1501(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b3, b8, b11;
    ivec4 i2, i3;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 51  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 52  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 53  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xyzw = texture(t0, lit_TEXCOORD0.xy).xyzw;                                         // 54  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t0.xyzw, s0
    r2.xy = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 55  sample_indexable(texture2d)(float,float,float,float) r2.xy, v1.xyxx, t1.xyzw, s1
    r2.xy = r2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 56  mad r2.xy, r2.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r2.w = dot(r2.xy, r2.xy);                                                             // 57  dp2 r2.w, r2.xyxx, r2.xyxx
    r2.w = d3d_min(r2.w, 1.0);                                                            // 58  min r2.w, r2.w, l(1.000000)
    r2.w = -r2.w + 1.0;                                                                   // 59  add r2.w, -r2.w, l(1.000000)
    r2.z = d3d_sqrt(r2.w);                                                                // 60  sqrt r2.z, r2.w
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 61  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 62  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 63  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 64  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 65  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 66  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 67  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 68  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 69  add r2.w, -r2.w, l(3.000000)
    r3.y = r3.z * FO4_L_PI;                                                               // 70  mul r3.y, r3.z, l(3.141593)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 71  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 72  exp r3.x, r3.x
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 73  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 74  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 75  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 76  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 77  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 78  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 79  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 80  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 81  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 82  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 83  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 84  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 85  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 86  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 87  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 88  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 89  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 90  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 91  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 92  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 93  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 94  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 95  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 96  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 97  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 98  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 99  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 100  dp4 r2.y, r6.xyzw, r8.xyzw
            r3.z = dot(r7.xyzw, r8.xyzw);                                                 // 101  dp4 r3.z, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 102  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r3.z);                                                        // 103  ge r2.x, r2.x, r3.z
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 104  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 105  else
            r2.x = 1.0;                                                                   // 106  mov r2.x, l(1.000000)
        }                                                                                 // 107  endif
    } else {                                                                              // 108  else
        r2.x = 1.0;                                                                       // 109  mov r2.x, l(1.000000)
    }                                                                                     // 110  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 111  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 112  dp3 r2.z, r0.ywzy, r4.xzwx
    r3.z = dot(DirLightDirection.xzy, r4.xzw);                                            // 113  dp3 r3.z, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 114  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r3.zzz + DirLightDirection.xyz;                                    // 115  mad r6.xyz, -r4.xwzx, r3.zzzz, cb2[0].xyzx
    r3.w = dot(r5.xyz, r6.xyz);                                                           // 116  dp3 r3.w, r5.xyzx, r6.xyzx
    r4.y = r2.y * r2.y;                                                                   // 117  mul r4.y, r2.y, r2.y
    r6.xy = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 118  mad r6.xy, r2.yyyy, r2.yyyy, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.y, r6.x), d3d_div(r4.y, r6.y));                               // 119  div r6.xy, r4.yyyy, r6.xyxx
    r2.y = r6.y * FO4_L_0_45;                                                             // 120  mul r2.y, r6.y, l(0.450000)
    r4.y = -r6.x * 0.5 + 1.0;                                                             // 121  mad r4.y, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r2.z * r2.z + 1.0;                                                            // 122  mad r5.w, -r2.z, r2.z, l(1.000000)
    r6.x = -r3.z * r3.z + 1.0;                                                            // 123  mad r6.x, -r3.z, r3.z, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 124  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 125  sqrt r6.x, r6.x
    r6.y = d3d_max(r2.z, r3.z);                                                           // 126  max r6.y, r2.z, r3.z
    r6.x = d3d_div(r6.x, r6.y);                                                           // 127  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r3.z, 0.0);                                                            // 128  max r6.y, r3.z, l(0.000000)
    r3.w = d3d_max(r3.w, 0.0);                                                            // 129  max r3.w, r3.w, l(0.000000)
    r3.w = r2.y * r3.w;                                                                   // 130  mul r3.w, r2.y, r3.w
    r3.w = r3.w * r6.x + r4.y;                                                            // 131  mad r3.w, r3.w, r6.x, r4.y
    r3.w = r3.w * r6.y;                                                                   // 132  mul r3.w, r3.w, r6.y
    r6.xzw = r3.www * DirLightColor.xyz;                                                  // 133  mul r6.xzw, r3.wwww, cb2[1].xxyz
    r3.w = d3d_min(r6.y, 1.0);                                                            // 134  min r3.w, r6.y, l(1.000000)
    r6.y = d3d_sat(r2.z);                                                                 // 135  mov_sat r6.y, r2.z
    r7.x = -r6.y + 1.0;                                                                   // 136  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 137  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 138  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 139  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 140  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 141  mul r7.y, r7.y, r7.x
    r7.y = r3.w * r7.y;                                                                   // 142  mul r7.y, r3.w, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 143  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r2.www * r7.yzw;                                                             // 144  mul r7.yzw, r2.wwww, r7.yyzw
    r6.xzw = r6.xzw * r2.xxx + r7.yzw;                                                    // 145  mad r6.xzw, r6.xxzw, r2.xxxx, r7.yyzw
    r7.yzw = r1.xyz * LightingEffectParams.yyy;                                           // 146  mul r7.yzw, r1.xxyz, cb1[7].yyyy
    r8.x = d3d_sat(-r3.z);                                                                // 147  mov_sat r8.x, -r3.z
    r7.yzw = r7.yzw * r8.xxx;                                                             // 148  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 149  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r3.z = r3.z + LightingEffectParams.x;                                                 // 150  add r3.z, r3.z, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 151  add r7.y, cb1[7].x, l(1.000000)
    r3.z = d3d_sat(d3d_div(r3.z, r7.y));                                                  // 152  div_sat r3.z, r3.z, r7.y
    r3.z = -r3.w + r3.z;                                                                  // 153  add r3.z, -r3.w, r3.z
    r3.z = d3d_max(r3.z, 0.0);                                                            // 154  max r3.z, r3.z, l(0.000000)
    r7.yzw = r3.zzz * DirLightColor.xyz;                                                  // 155  mul r7.yzw, r3.zzzz, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xyz + r6.xzw;                                                    // 156  mad r6.xzw, r7.yyzw, r1.xxyz, r6.xxzw
    r6.xzw = r2.xxx * r6.xzw;                                                             // 157  mul r6.xzw, r2.xxxx, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 158  mad r7.yzw, v6.xxyz, r0.xxxx, cb2[0].xxyz
    r3.z = dot(r7.yzw, r7.yzw);                                                           // 159  dp3 r3.z, r7.yzwy, r7.yzwy
    r3.z = d3d_rsq(r3.z);                                                                 // 160  rsq r3.z, r3.z
    r7.yzw = r3.zzz * r7.yzw;                                                             // 161  mul r7.yzw, r3.zzzz, r7.yyzw
    r3.z = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 162  dp3_sat r3.z, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r4.xzw));                                                  // 163  dp3_sat r7.y, r7.ywzy, r4.xzwx
    r7.z = r3.x + 2.0;                                                                    // 164  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 165  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 166  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 167  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 168  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 169  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r3.z, FO4_L_2POW_M23);                                                 // 170  max r8.x, r3.z, l(0.000000)
    r8.y = d3d_min(r3.w, r6.y);                                                           // 171  min r8.y, r3.w, r6.y
    r7.y = r7.y + r7.y;                                                                   // 172  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 173  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 174  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 175  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r3.w, r6.y);                                                           // 176  div r8.w, r3.w, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 177  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 178  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 179  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 180  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 181  movc r7.y, r8.z, r7.y, r8.x
    r3.z = -r3.z + 1.0;                                                                   // 182  add r3.z, -r3.z, l(1.000000)
    r8.y = r3.z * r3.z;                                                                   // 183  mul r8.y, r3.z, r3.z
    r8.y = r8.y * r8.y;                                                                   // 184  mul r8.y, r8.y, r8.y
    r8.z = r3.z * r8.y;                                                                   // 185  mul r8.z, r3.z, r8.y
    r3.z = -r3.z * r8.y + 1.0;                                                            // 186  mad r3.z, -r3.z, r8.y, l(1.000000)
    r3.z = r3.z * FO4_L_0_2 + r8.z;                                                       // 187  mad r3.z, r3.z, l(0.200000), r8.z
    r3.z = d3d_min(r3.z, 1.0);                                                            // 188  min r3.z, r3.z, l(1.000000)
    r3.z = r7.y * r3.z;                                                                   // 189  mul r3.z, r7.y, r3.z
    r3.z = r7.w * r3.z;                                                                   // 190  mul r3.z, r7.w, r3.z
    r3.z = r3.z * 0.25;                                                                   // 191  mul r3.z, r3.z, l(0.250000)
    r3.z = d3d_min(r3.z, 15.0);                                                           // 192  min r3.z, r3.z, l(15.000000)
    r3.z = r3.z * r3.y;                                                                   // 193  mul r3.z, r3.z, r3.y
    r8.yzw = r3.zzz * DirLightColor.xyz;                                                  // 194  mul r8.yzw, r3.zzzz, cb2[1].xxyz
    r8.yzw = r3.www * r8.yzw;                                                             // 195  mul r8.yzw, r3.wwww, r8.yyzw
    r8.yzw = r2.xxx * r8.yzw;                                                             // 196  mul r8.yzw, r2.xxxx, r8.yyzw
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 197  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 198  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 199  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 200  max r2.x, r2.x, l(0.000000)
    b3.z = (0.0 < r2.x);                                                                  // 201  lt r3.z, l(0.000000), r2.x
    if (b3.z) {                                                                           // 202  if_nz r3.z
        r9.xyz = r6.xzw;                                                                  // 203  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 204  mov r10.xyz, r8.yzwy
        i3.z = 0;                                                                         // 205  mov r3.z, l(0)
        for (;;) {                                                                        // 206  loop
            r3.w = float(i3.z);                                                           // 207  itof r3.w, r3.z
            b3.w = (r3.w >= r2.x);                                                        // 208  ge r3.w, r3.w, r2.x
            if (b3.w) break;                                                              // 209  breakc_nz r3.w
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i3.z + 13).xyz;                    // 210  add r11.xyz, -v2.xyzx, cb2[r3.z + 13].xyzx
            r3.w = dot(r11.xyz, r11.xyz);                                                 // 211  dp3 r3.w, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r3.w);                                                        // 212  sqrt r7.y, r3.w
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i3.z + 13).w));                      // 213  div_sat r7.y, r7.y, cb2[r3.z + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 214  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 215  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 216  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 217  exp r7.y, r7.y
            r3.w = d3d_rsq(r3.w);                                                         // 218  rsq r3.w, r3.w
            r11.xyz = r3.www * r11.xyz;                                                   // 219  mul r11.xyz, r3.wwww, r11.xyzx
            r3.w = dot(r11.xzy, r4.xzw);                                                  // 220  dp3 r3.w, r11.xzyx, r4.xzwx
            r12.xyz = -r4.xwz * r3.www + r11.xyz;                                         // 221  mad r12.xyz, -r4.xwzx, r3.wwww, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 222  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r3.w * r3.w + 1.0;                                                    // 223  mad r9.w, -r3.w, r3.w, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 224  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 225  sqrt r9.w, r9.w
            r10.w = d3d_max(r2.z, r3.w);                                                  // 226  max r10.w, r2.z, r3.w
            r9.w = d3d_div(r9.w, r10.w);                                                  // 227  div r9.w, r9.w, r10.w
            r3.w = d3d_max(r3.w, 0.0);                                                    // 228  max r3.w, r3.w, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 229  max r7.w, r7.w, l(0.000000)
            r7.w = r2.y * r7.w;                                                           // 230  mul r7.w, r2.y, r7.w
            r7.w = r7.w * r9.w + r4.y;                                                    // 231  mad r7.w, r7.w, r9.w, r4.y
            r7.w = r3.w * r7.w;                                                           // 232  mul r7.w, r3.w, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 233  mul r12.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 234  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 235  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r3.w = d3d_min(r3.w, 1.0);                                                    // 236  min r3.w, r3.w, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 237  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 238  mul r7.w, r7.w, r7.x
            r7.w = r3.w * r7.w;                                                           // 239  mul r7.w, r3.w, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 240  mul r13.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r13.xyz = r2.www * r13.xyz;                                                   // 241  mul r13.xyz, r2.wwww, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 242  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 243  mad r11.xyz, v6.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 244  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 245  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 246  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 247  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r4.xzw));                                         // 248  dp3_sat r9.w, r11.xzyx, r4.xzwx
            r10.w = d3d_log2(r9.w);                                                       // 249  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 250  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 251  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 252  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 253  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r3.w, r6.y);                                                  // 254  min r11.y, r3.w, r6.y
            r9.w = r9.w + r9.w;                                                           // 255  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 256  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 257  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 258  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r3.w, r6.y);                                                  // 259  div r11.w, r3.w, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 260  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 261  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 262  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 263  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 264  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 265  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 266  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 267  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 268  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 269  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 270  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 271  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 272  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 273  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 274  min r7.w, r7.w, l(15.000000)
            r7.w = r3.y * r7.w;                                                           // 275  mul r7.w, r3.y, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 276  mul r11.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r11.xyz = r3.www * r11.xyz;                                                   // 277  mul r11.xyz, r3.wwww, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 278  mul r10.xyz, r7.yyyy, r11.xyzx
            i3.z = (i3.z + 1);                                                            // 279  iadd r3.z, r3.z, l(1)
        }                                                                                 // 280  endloop
        r6.xzw = r9.xyz;                                                                  // 281  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 282  mov r8.yzw, r10.xxyz
    } else { i3.z = (b3.z ? -1 : 0); }                                                    // 283  endif
    r0.xyz = r6.xzw + EmitColor.xyz;                                                      // 284  add r0.xyz, r6.xzwx, cb2[3].yzwy
    r0.xyz = r1.xyz * r0.xyz;                                                             // 285  mul r0.xyz, r1.xyzx, r0.xyzx
    r0.xyz = r0.xyz * lit_COLOR0.xyz + r8.yzw;                                            // 286  mad r0.xyz, r0.xyzx, v7.xyzx, r8.yzwy
    r0.w = r1.w * lit_COLOR0.w + -AlphaTestRef.x;                                         // 287  mad r0.w, r1.w, v7.w, -cb2[3].x
    b0.w = (r0.w < 0.0);                                                                  // 288  lt r0.w, r0.w, l(0.000000)
    kill = kill || b0.w;                                                                  // 289  discard_nz r0.w
    r1.xyzw = texture(t12, lit_TEXCOORD0.xy).xyzw;                                        // 290  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t12.xyzw, s12
    r1.xyz = vec3(d3d_log2(r1.x), d3d_log2(r1.y), d3d_log2(r1.z));                        // 291  log r1.xyz, r1.xyzx
    r1.xyz = r1.xyz * vec3(FO4_L_2_2);                                                    // 292  mul r1.xyz, r1.xyzx, l(2.200000, 2.200000, 2.200000, 0.000000)
    r1.xyz = vec3(d3d_exp2(r1.x), d3d_exp2(r1.y), d3d_exp2(r1.z));                        // 293  exp r1.xyz, r1.xyzx
    r1.xyz = r1.www * r1.xyz;                                                             // 294  mul r1.xyz, r1.wwww, r1.xyzx
    r0.w = -r1.w * MenuScreenParams.x + 1.0;                                              // 295  mad r0.w, -r1.w, cb0[0].x, l(1.000000)
    o0.xyz = r0.xyz * r0.www + r1.xyz;                                                    // 296  mad o0.xyz, r0.xyzx, r0.wwww, r1.xyzx
    o0.w = MaterialData.z;                                                                // 297  mov o0.w, cb2[2].z
    return;                                                                               // 298  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1501(o0, kill);
}
//#### END Fo4LitPs_rec1501 ####
//#### BEGIN Fo4LitPs_rec1502 ####
// class of identical transcribed code: rec1502 t00000601, rec1503 t00000611
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
uniform vec4 TintColor;                   // name 21, cb1, writer SM 0x14223ABFA..E1B
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1502)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 2)  uniform sampler2D t2;
// b06_BSLighting_PS_rec1502_t00000601  technique 0x00000601 = VC|HAIR
// constants by name (fxp offset table of rec1502, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, TintColor = cb1[1].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1502(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b3, b8, b11;
    ivec4 i2, i3;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 48  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 49  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 50  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xyzw = texture(t0, lit_TEXCOORD0.xy).xyzw;                                         // 51  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t0.xyzw, s0
    r2.xy = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 52  sample_indexable(texture2d)(float,float,float,float) r2.xy, v1.xyxx, t1.xyzw, s1
    r2.xy = r2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 53  mad r2.xy, r2.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r2.w = dot(r2.xy, r2.xy);                                                             // 54  dp2 r2.w, r2.xyxx, r2.xyxx
    r2.w = d3d_min(r2.w, 1.0);                                                            // 55  min r2.w, r2.w, l(1.000000)
    r2.w = -r2.w + 1.0;                                                                   // 56  add r2.w, -r2.w, l(1.000000)
    r2.z = d3d_sqrt(r2.w);                                                                // 57  sqrt r2.z, r2.w
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 58  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 59  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 60  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 61  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 62  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 63  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 64  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 65  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 66  add r2.w, -r2.w, l(3.000000)
    r3.y = r3.z * FO4_L_PI;                                                               // 67  mul r3.y, r3.z, l(3.141593)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 68  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 69  exp r3.x, r3.x
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 70  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 71  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 72  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 73  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 74  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 75  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 76  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 77  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 78  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 79  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 80  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 81  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 82  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 83  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 84  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 85  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 86  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 87  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 88  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 89  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 90  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 91  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 92  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 93  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 94  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 95  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 96  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 97  dp4 r2.y, r6.xyzw, r8.xyzw
            r3.z = dot(r7.xyzw, r8.xyzw);                                                 // 98  dp4 r3.z, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 99  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r3.z);                                                        // 100  ge r2.x, r2.x, r3.z
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 101  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 102  else
            r2.x = 1.0;                                                                   // 103  mov r2.x, l(1.000000)
        }                                                                                 // 104  endif
    } else {                                                                              // 105  else
        r2.x = 1.0;                                                                       // 106  mov r2.x, l(1.000000)
    }                                                                                     // 107  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 108  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 109  dp3 r2.z, r0.ywzy, r4.xzwx
    r3.z = dot(DirLightDirection.xzy, r4.xzw);                                            // 110  dp3 r3.z, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 111  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r3.zzz + DirLightDirection.xyz;                                    // 112  mad r6.xyz, -r4.xwzx, r3.zzzz, cb2[0].xyzx
    r3.w = dot(r5.xyz, r6.xyz);                                                           // 113  dp3 r3.w, r5.xyzx, r6.xyzx
    r4.y = r2.y * r2.y;                                                                   // 114  mul r4.y, r2.y, r2.y
    r6.xy = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 115  mad r6.xy, r2.yyyy, r2.yyyy, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.y, r6.x), d3d_div(r4.y, r6.y));                               // 116  div r6.xy, r4.yyyy, r6.xyxx
    r2.y = r6.y * FO4_L_0_45;                                                             // 117  mul r2.y, r6.y, l(0.450000)
    r4.y = -r6.x * 0.5 + 1.0;                                                             // 118  mad r4.y, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r2.z * r2.z + 1.0;                                                            // 119  mad r5.w, -r2.z, r2.z, l(1.000000)
    r6.x = -r3.z * r3.z + 1.0;                                                            // 120  mad r6.x, -r3.z, r3.z, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 121  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 122  sqrt r6.x, r6.x
    r6.y = d3d_max(r2.z, r3.z);                                                           // 123  max r6.y, r2.z, r3.z
    r6.x = d3d_div(r6.x, r6.y);                                                           // 124  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r3.z, 0.0);                                                            // 125  max r6.y, r3.z, l(0.000000)
    r3.w = d3d_max(r3.w, 0.0);                                                            // 126  max r3.w, r3.w, l(0.000000)
    r3.w = r2.y * r3.w;                                                                   // 127  mul r3.w, r2.y, r3.w
    r3.w = r3.w * r6.x + r4.y;                                                            // 128  mad r3.w, r3.w, r6.x, r4.y
    r3.w = r3.w * r6.y;                                                                   // 129  mul r3.w, r3.w, r6.y
    r6.xzw = r3.www * DirLightColor.xyz;                                                  // 130  mul r6.xzw, r3.wwww, cb2[1].xxyz
    r3.w = d3d_min(r6.y, 1.0);                                                            // 131  min r3.w, r6.y, l(1.000000)
    r6.y = d3d_sat(r2.z);                                                                 // 132  mov_sat r6.y, r2.z
    r7.x = -r6.y + 1.0;                                                                   // 133  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 134  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 135  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 136  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 137  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 138  mul r7.y, r7.y, r7.x
    r7.y = r3.w * r7.y;                                                                   // 139  mul r7.y, r3.w, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 140  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r2.www * r7.yzw;                                                             // 141  mul r7.yzw, r2.wwww, r7.yyzw
    r6.xzw = r6.xzw * r2.xxx + r7.yzw;                                                    // 142  mad r6.xzw, r6.xxzw, r2.xxxx, r7.yyzw
    r7.yzw = r1.xyz * LightingEffectParams.yyy;                                           // 143  mul r7.yzw, r1.xxyz, cb1[7].yyyy
    r8.x = d3d_sat(-r3.z);                                                                // 144  mov_sat r8.x, -r3.z
    r7.yzw = r7.yzw * r8.xxx;                                                             // 145  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 146  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r3.z = r3.z + LightingEffectParams.x;                                                 // 147  add r3.z, r3.z, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 148  add r7.y, cb1[7].x, l(1.000000)
    r3.z = d3d_sat(d3d_div(r3.z, r7.y));                                                  // 149  div_sat r3.z, r3.z, r7.y
    r3.z = -r3.w + r3.z;                                                                  // 150  add r3.z, -r3.w, r3.z
    r3.z = d3d_max(r3.z, 0.0);                                                            // 151  max r3.z, r3.z, l(0.000000)
    r7.yzw = r3.zzz * DirLightColor.xyz;                                                  // 152  mul r7.yzw, r3.zzzz, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xyz + r6.xzw;                                                    // 153  mad r6.xzw, r7.yyzw, r1.xxyz, r6.xxzw
    r6.xzw = r2.xxx * r6.xzw;                                                             // 154  mul r6.xzw, r2.xxxx, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 155  mad r7.yzw, v6.xxyz, r0.xxxx, cb2[0].xxyz
    r3.z = dot(r7.yzw, r7.yzw);                                                           // 156  dp3 r3.z, r7.yzwy, r7.yzwy
    r3.z = d3d_rsq(r3.z);                                                                 // 157  rsq r3.z, r3.z
    r7.yzw = r3.zzz * r7.yzw;                                                             // 158  mul r7.yzw, r3.zzzz, r7.yyzw
    r3.z = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 159  dp3_sat r3.z, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r4.xzw));                                                  // 160  dp3_sat r7.y, r7.ywzy, r4.xzwx
    r7.z = r3.x + 2.0;                                                                    // 161  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 162  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 163  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 164  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 165  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 166  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r3.z, FO4_L_2POW_M23);                                                 // 167  max r8.x, r3.z, l(0.000000)
    r8.y = d3d_min(r3.w, r6.y);                                                           // 168  min r8.y, r3.w, r6.y
    r7.y = r7.y + r7.y;                                                                   // 169  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 170  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 171  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 172  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r3.w, r6.y);                                                           // 173  div r8.w, r3.w, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 174  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 175  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 176  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 177  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 178  movc r7.y, r8.z, r7.y, r8.x
    r3.z = -r3.z + 1.0;                                                                   // 179  add r3.z, -r3.z, l(1.000000)
    r8.y = r3.z * r3.z;                                                                   // 180  mul r8.y, r3.z, r3.z
    r8.y = r8.y * r8.y;                                                                   // 181  mul r8.y, r8.y, r8.y
    r8.z = r3.z * r8.y;                                                                   // 182  mul r8.z, r3.z, r8.y
    r3.z = -r3.z * r8.y + 1.0;                                                            // 183  mad r3.z, -r3.z, r8.y, l(1.000000)
    r3.z = r3.z * FO4_L_0_2 + r8.z;                                                       // 184  mad r3.z, r3.z, l(0.200000), r8.z
    r3.z = d3d_min(r3.z, 1.0);                                                            // 185  min r3.z, r3.z, l(1.000000)
    r3.z = r7.y * r3.z;                                                                   // 186  mul r3.z, r7.y, r3.z
    r3.z = r7.w * r3.z;                                                                   // 187  mul r3.z, r7.w, r3.z
    r3.z = r3.z * 0.25;                                                                   // 188  mul r3.z, r3.z, l(0.250000)
    r3.z = d3d_min(r3.z, 15.0);                                                           // 189  min r3.z, r3.z, l(15.000000)
    r3.z = r3.z * r3.y;                                                                   // 190  mul r3.z, r3.z, r3.y
    r8.yzw = r3.zzz * DirLightColor.xyz;                                                  // 191  mul r8.yzw, r3.zzzz, cb2[1].xxyz
    r8.yzw = r3.www * r8.yzw;                                                             // 192  mul r8.yzw, r3.wwww, r8.yyzw
    r8.yzw = r2.xxx * r8.yzw;                                                             // 193  mul r8.yzw, r2.xxxx, r8.yyzw
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 194  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 195  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 196  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 197  max r2.x, r2.x, l(0.000000)
    b3.z = (0.0 < r2.x);                                                                  // 198  lt r3.z, l(0.000000), r2.x
    if (b3.z) {                                                                           // 199  if_nz r3.z
        r9.xyz = r6.xzw;                                                                  // 200  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 201  mov r10.xyz, r8.yzwy
        i3.z = 0;                                                                         // 202  mov r3.z, l(0)
        for (;;) {                                                                        // 203  loop
            r3.w = float(i3.z);                                                           // 204  itof r3.w, r3.z
            b3.w = (r3.w >= r2.x);                                                        // 205  ge r3.w, r3.w, r2.x
            if (b3.w) break;                                                              // 206  breakc_nz r3.w
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i3.z + 13).xyz;                    // 207  add r11.xyz, -v2.xyzx, cb2[r3.z + 13].xyzx
            r3.w = dot(r11.xyz, r11.xyz);                                                 // 208  dp3 r3.w, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r3.w);                                                        // 209  sqrt r7.y, r3.w
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i3.z + 13).w));                      // 210  div_sat r7.y, r7.y, cb2[r3.z + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 211  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 212  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 213  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 214  exp r7.y, r7.y
            r3.w = d3d_rsq(r3.w);                                                         // 215  rsq r3.w, r3.w
            r11.xyz = r3.www * r11.xyz;                                                   // 216  mul r11.xyz, r3.wwww, r11.xyzx
            r3.w = dot(r11.xzy, r4.xzw);                                                  // 217  dp3 r3.w, r11.xzyx, r4.xzwx
            r12.xyz = -r4.xwz * r3.www + r11.xyz;                                         // 218  mad r12.xyz, -r4.xwzx, r3.wwww, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 219  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r3.w * r3.w + 1.0;                                                    // 220  mad r9.w, -r3.w, r3.w, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 221  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 222  sqrt r9.w, r9.w
            r10.w = d3d_max(r2.z, r3.w);                                                  // 223  max r10.w, r2.z, r3.w
            r9.w = d3d_div(r9.w, r10.w);                                                  // 224  div r9.w, r9.w, r10.w
            r3.w = d3d_max(r3.w, 0.0);                                                    // 225  max r3.w, r3.w, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 226  max r7.w, r7.w, l(0.000000)
            r7.w = r2.y * r7.w;                                                           // 227  mul r7.w, r2.y, r7.w
            r7.w = r7.w * r9.w + r4.y;                                                    // 228  mad r7.w, r7.w, r9.w, r4.y
            r7.w = r3.w * r7.w;                                                           // 229  mul r7.w, r3.w, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 230  mul r12.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 231  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 232  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r3.w = d3d_min(r3.w, 1.0);                                                    // 233  min r3.w, r3.w, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 234  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 235  mul r7.w, r7.w, r7.x
            r7.w = r3.w * r7.w;                                                           // 236  mul r7.w, r3.w, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 237  mul r13.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r13.xyz = r2.www * r13.xyz;                                                   // 238  mul r13.xyz, r2.wwww, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 239  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 240  mad r11.xyz, v6.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 241  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 242  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 243  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 244  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r4.xzw));                                         // 245  dp3_sat r9.w, r11.xzyx, r4.xzwx
            r10.w = d3d_log2(r9.w);                                                       // 246  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 247  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 248  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 249  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 250  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r3.w, r6.y);                                                  // 251  min r11.y, r3.w, r6.y
            r9.w = r9.w + r9.w;                                                           // 252  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 253  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 254  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 255  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r3.w, r6.y);                                                  // 256  div r11.w, r3.w, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 257  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 258  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 259  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 260  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 261  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 262  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 263  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 264  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 265  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 266  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 267  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 268  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 269  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 270  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 271  min r7.w, r7.w, l(15.000000)
            r7.w = r3.y * r7.w;                                                           // 272  mul r7.w, r3.y, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 273  mul r11.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r11.xyz = r3.www * r11.xyz;                                                   // 274  mul r11.xyz, r3.wwww, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 275  mul r10.xyz, r7.yyyy, r11.xyzx
            i3.z = (i3.z + 1);                                                            // 276  iadd r3.z, r3.z, l(1)
        }                                                                                 // 277  endloop
        r6.xzw = r9.xyz;                                                                  // 278  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 279  mov r8.yzw, r10.xxyz
    } else { i3.z = (b3.z ? -1 : 0); }                                                    // 280  endif
    r0.xyz = r6.xzw + EmitColor.xyz;                                                      // 281  add r0.xyz, r6.xzwx, cb2[3].yzwy
    r0.xyz = r1.xyz * r0.xyz;                                                             // 282  mul r0.xyz, r1.xyzx, r0.xyzx
    r1.xyz = TintColor.xyz + vec3(-1.0, -1.0, -1.0);                                      // 283  add r1.xyz, cb1[1].xyzx, l(-1.000000, -1.000000, -1.000000, 0.000000)
    r1.xyz = lit_COLOR0.yyy * r1.xyz + vec3(1.0, 1.0, 1.0);                               // 284  mad r1.xyz, v7.yyyy, r1.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
    o0.xyz = r0.xyz * r1.xyz + r8.yzw;                                                    // 285  mad o0.xyz, r0.xyzx, r1.xyzx, r8.yzwy
    r0.x = r1.w * lit_COLOR0.w + -AlphaTestRef.x;                                         // 286  mad r0.x, r1.w, v7.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 287  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 288  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 289  mov o0.w, cb2[2].z
    return;                                                                               // 290  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1502(o0, kill);
}
//#### END Fo4LitPs_rec1502 ####
//#### BEGIN Fo4LitPs_rec1504 ####
// class of identical transcribed code: rec1504 t00000641, rec1505 t00000651
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
uniform vec4 TintColor;                   // name 21, cb1, writer SM 0x14223ABFA..E1B
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1504)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 15)  uniform sampler2D t15;
layout(binding = 2)  uniform sampler2D t2;
// b06_BSLighting_PS_rec1504_t00000641  technique 0x00000641 = VC|GRADIENT_REMAP|HAIR
// constants by name (fxp offset table of rec1504, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, TintColor = cb1[1].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1504(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b3, b8, b11;
    ivec4 i2, i3;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 50  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 51  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 52  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xy = texture(t0, lit_TEXCOORD0.xy).yw;                                             // 53  sample_indexable(texture2d)(float,float,float,float) r1.xy, v1.xyxx, t0.ywxz, s0
    r1.zw = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 54  sample_indexable(texture2d)(float,float,float,float) r1.zw, v1.xyxx, t1.zwxy, s1
    r2.xy = r1.zw * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 55  mad r2.xy, r1.zwzz, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r1.z = dot(r2.xy, r2.xy);                                                             // 56  dp2 r1.z, r2.xyxx, r2.xyxx
    r1.z = d3d_min(r1.z, 1.0);                                                            // 57  min r1.z, r1.z, l(1.000000)
    r1.z = -r1.z + 1.0;                                                                   // 58  add r1.z, -r1.z, l(1.000000)
    r2.z = d3d_sqrt(r1.z);                                                                // 59  sqrt r2.z, r1.z
    r1.z = d3d_log2(lit_COLOR0.x);                                                        // 60  log r1.z, v7.x
    r1.z = r1.z * FO4_L_0_454545;                                                         // 61  mul r1.z, r1.z, l(0.454545)
    r1.z = d3d_exp2(r1.z);                                                                // 62  exp r1.z, r1.z
    r1.x = d3d_log2(r1.x);                                                                // 63  log r1.x, r1.x
    r1.x = r1.x * FO4_L_0_454545;                                                         // 64  mul r1.x, r1.x, l(0.454545)
    r3.x = d3d_exp2(r1.x);                                                                // 65  exp r3.x, r1.x
    r1.x = -r1.z + 1.0;                                                                   // 66  add r1.x, -r1.z, l(1.000000)
    r3.y = -r1.x + TintColor.x;                                                           // 67  add r3.y, -r1.x, cb1[1].x
    r1.xzw = textureLod(t15, r3.xy, 0.0).xyz;                                             // 68  sample_l_indexable(texture2d)(float,float,float,float) r1.xzw, r3.xyxx, t15.xwyz, s15, l(0.000000)
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 69  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 70  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 71  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 72  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 73  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 74  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 75  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 76  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 77  add r2.w, -r2.w, l(3.000000)
    r3.y = r3.z * FO4_L_PI;                                                               // 78  mul r3.y, r3.z, l(3.141593)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 79  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 80  exp r3.x, r3.x
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 81  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 82  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 83  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 84  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 85  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 86  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 87  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 88  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 89  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 90  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 91  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 92  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 93  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 94  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 95  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 96  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 97  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 98  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 99  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 100  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 101  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 102  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 103  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 104  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 105  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 106  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 107  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 108  dp4 r2.y, r6.xyzw, r8.xyzw
            r3.z = dot(r7.xyzw, r8.xyzw);                                                 // 109  dp4 r3.z, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 110  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r3.z);                                                        // 111  ge r2.x, r2.x, r3.z
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 112  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 113  else
            r2.x = 1.0;                                                                   // 114  mov r2.x, l(1.000000)
        }                                                                                 // 115  endif
    } else {                                                                              // 116  else
        r2.x = 1.0;                                                                       // 117  mov r2.x, l(1.000000)
    }                                                                                     // 118  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 119  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 120  dp3 r2.z, r0.ywzy, r4.xzwx
    r3.z = dot(DirLightDirection.xzy, r4.xzw);                                            // 121  dp3 r3.z, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 122  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r3.zzz + DirLightDirection.xyz;                                    // 123  mad r6.xyz, -r4.xwzx, r3.zzzz, cb2[0].xyzx
    r3.w = dot(r5.xyz, r6.xyz);                                                           // 124  dp3 r3.w, r5.xyzx, r6.xyzx
    r4.y = r2.y * r2.y;                                                                   // 125  mul r4.y, r2.y, r2.y
    r6.xy = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 126  mad r6.xy, r2.yyyy, r2.yyyy, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.y, r6.x), d3d_div(r4.y, r6.y));                               // 127  div r6.xy, r4.yyyy, r6.xyxx
    r2.y = r6.y * FO4_L_0_45;                                                             // 128  mul r2.y, r6.y, l(0.450000)
    r4.y = -r6.x * 0.5 + 1.0;                                                             // 129  mad r4.y, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r2.z * r2.z + 1.0;                                                            // 130  mad r5.w, -r2.z, r2.z, l(1.000000)
    r6.x = -r3.z * r3.z + 1.0;                                                            // 131  mad r6.x, -r3.z, r3.z, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 132  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 133  sqrt r6.x, r6.x
    r6.y = d3d_max(r2.z, r3.z);                                                           // 134  max r6.y, r2.z, r3.z
    r6.x = d3d_div(r6.x, r6.y);                                                           // 135  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r3.z, 0.0);                                                            // 136  max r6.y, r3.z, l(0.000000)
    r3.w = d3d_max(r3.w, 0.0);                                                            // 137  max r3.w, r3.w, l(0.000000)
    r3.w = r2.y * r3.w;                                                                   // 138  mul r3.w, r2.y, r3.w
    r3.w = r3.w * r6.x + r4.y;                                                            // 139  mad r3.w, r3.w, r6.x, r4.y
    r3.w = r3.w * r6.y;                                                                   // 140  mul r3.w, r3.w, r6.y
    r6.xzw = r3.www * DirLightColor.xyz;                                                  // 141  mul r6.xzw, r3.wwww, cb2[1].xxyz
    r3.w = d3d_min(r6.y, 1.0);                                                            // 142  min r3.w, r6.y, l(1.000000)
    r6.y = d3d_sat(r2.z);                                                                 // 143  mov_sat r6.y, r2.z
    r7.x = -r6.y + 1.0;                                                                   // 144  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 145  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 146  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 147  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 148  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 149  mul r7.y, r7.y, r7.x
    r7.y = r3.w * r7.y;                                                                   // 150  mul r7.y, r3.w, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 151  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r2.www * r7.yzw;                                                             // 152  mul r7.yzw, r2.wwww, r7.yyzw
    r6.xzw = r6.xzw * r2.xxx + r7.yzw;                                                    // 153  mad r6.xzw, r6.xxzw, r2.xxxx, r7.yyzw
    r7.yzw = r1.xzw * LightingEffectParams.yyy;                                           // 154  mul r7.yzw, r1.xxzw, cb1[7].yyyy
    r8.x = d3d_sat(-r3.z);                                                                // 155  mov_sat r8.x, -r3.z
    r7.yzw = r7.yzw * r8.xxx;                                                             // 156  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 157  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r3.z = r3.z + LightingEffectParams.x;                                                 // 158  add r3.z, r3.z, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 159  add r7.y, cb1[7].x, l(1.000000)
    r3.z = d3d_sat(d3d_div(r3.z, r7.y));                                                  // 160  div_sat r3.z, r3.z, r7.y
    r3.z = -r3.w + r3.z;                                                                  // 161  add r3.z, -r3.w, r3.z
    r3.z = d3d_max(r3.z, 0.0);                                                            // 162  max r3.z, r3.z, l(0.000000)
    r7.yzw = r3.zzz * DirLightColor.xyz;                                                  // 163  mul r7.yzw, r3.zzzz, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xzw + r6.xzw;                                                    // 164  mad r6.xzw, r7.yyzw, r1.xxzw, r6.xxzw
    r6.xzw = r2.xxx * r6.xzw;                                                             // 165  mul r6.xzw, r2.xxxx, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 166  mad r7.yzw, v6.xxyz, r0.xxxx, cb2[0].xxyz
    r3.z = dot(r7.yzw, r7.yzw);                                                           // 167  dp3 r3.z, r7.yzwy, r7.yzwy
    r3.z = d3d_rsq(r3.z);                                                                 // 168  rsq r3.z, r3.z
    r7.yzw = r3.zzz * r7.yzw;                                                             // 169  mul r7.yzw, r3.zzzz, r7.yyzw
    r3.z = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 170  dp3_sat r3.z, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r4.xzw));                                                  // 171  dp3_sat r7.y, r7.ywzy, r4.xzwx
    r7.z = r3.x + 2.0;                                                                    // 172  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 173  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 174  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 175  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 176  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 177  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r3.z, FO4_L_2POW_M23);                                                 // 178  max r8.x, r3.z, l(0.000000)
    r8.y = d3d_min(r3.w, r6.y);                                                           // 179  min r8.y, r3.w, r6.y
    r7.y = r7.y + r7.y;                                                                   // 180  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 181  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 182  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 183  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r3.w, r6.y);                                                           // 184  div r8.w, r3.w, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 185  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 186  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 187  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 188  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 189  movc r7.y, r8.z, r7.y, r8.x
    r3.z = -r3.z + 1.0;                                                                   // 190  add r3.z, -r3.z, l(1.000000)
    r8.y = r3.z * r3.z;                                                                   // 191  mul r8.y, r3.z, r3.z
    r8.y = r8.y * r8.y;                                                                   // 192  mul r8.y, r8.y, r8.y
    r8.z = r3.z * r8.y;                                                                   // 193  mul r8.z, r3.z, r8.y
    r3.z = -r3.z * r8.y + 1.0;                                                            // 194  mad r3.z, -r3.z, r8.y, l(1.000000)
    r3.z = r3.z * FO4_L_0_2 + r8.z;                                                       // 195  mad r3.z, r3.z, l(0.200000), r8.z
    r3.z = d3d_min(r3.z, 1.0);                                                            // 196  min r3.z, r3.z, l(1.000000)
    r3.z = r7.y * r3.z;                                                                   // 197  mul r3.z, r7.y, r3.z
    r3.z = r7.w * r3.z;                                                                   // 198  mul r3.z, r7.w, r3.z
    r3.z = r3.z * 0.25;                                                                   // 199  mul r3.z, r3.z, l(0.250000)
    r3.z = d3d_min(r3.z, 15.0);                                                           // 200  min r3.z, r3.z, l(15.000000)
    r3.z = r3.z * r3.y;                                                                   // 201  mul r3.z, r3.z, r3.y
    r8.yzw = r3.zzz * DirLightColor.xyz;                                                  // 202  mul r8.yzw, r3.zzzz, cb2[1].xxyz
    r8.yzw = r3.www * r8.yzw;                                                             // 203  mul r8.yzw, r3.wwww, r8.yyzw
    r8.yzw = r2.xxx * r8.yzw;                                                             // 204  mul r8.yzw, r2.xxxx, r8.yyzw
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 205  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 206  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 207  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 208  max r2.x, r2.x, l(0.000000)
    b3.z = (0.0 < r2.x);                                                                  // 209  lt r3.z, l(0.000000), r2.x
    if (b3.z) {                                                                           // 210  if_nz r3.z
        r9.xyz = r6.xzw;                                                                  // 211  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 212  mov r10.xyz, r8.yzwy
        i3.z = 0;                                                                         // 213  mov r3.z, l(0)
        for (;;) {                                                                        // 214  loop
            r3.w = float(i3.z);                                                           // 215  itof r3.w, r3.z
            b3.w = (r3.w >= r2.x);                                                        // 216  ge r3.w, r3.w, r2.x
            if (b3.w) break;                                                              // 217  breakc_nz r3.w
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i3.z + 13).xyz;                    // 218  add r11.xyz, -v2.xyzx, cb2[r3.z + 13].xyzx
            r3.w = dot(r11.xyz, r11.xyz);                                                 // 219  dp3 r3.w, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r3.w);                                                        // 220  sqrt r7.y, r3.w
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i3.z + 13).w));                      // 221  div_sat r7.y, r7.y, cb2[r3.z + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 222  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 223  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 224  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 225  exp r7.y, r7.y
            r3.w = d3d_rsq(r3.w);                                                         // 226  rsq r3.w, r3.w
            r11.xyz = r3.www * r11.xyz;                                                   // 227  mul r11.xyz, r3.wwww, r11.xyzx
            r3.w = dot(r11.xzy, r4.xzw);                                                  // 228  dp3 r3.w, r11.xzyx, r4.xzwx
            r12.xyz = -r4.xwz * r3.www + r11.xyz;                                         // 229  mad r12.xyz, -r4.xwzx, r3.wwww, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 230  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r3.w * r3.w + 1.0;                                                    // 231  mad r9.w, -r3.w, r3.w, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 232  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 233  sqrt r9.w, r9.w
            r10.w = d3d_max(r2.z, r3.w);                                                  // 234  max r10.w, r2.z, r3.w
            r9.w = d3d_div(r9.w, r10.w);                                                  // 235  div r9.w, r9.w, r10.w
            r3.w = d3d_max(r3.w, 0.0);                                                    // 236  max r3.w, r3.w, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 237  max r7.w, r7.w, l(0.000000)
            r7.w = r2.y * r7.w;                                                           // 238  mul r7.w, r2.y, r7.w
            r7.w = r7.w * r9.w + r4.y;                                                    // 239  mad r7.w, r7.w, r9.w, r4.y
            r7.w = r3.w * r7.w;                                                           // 240  mul r7.w, r3.w, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 241  mul r12.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 242  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 243  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r3.w = d3d_min(r3.w, 1.0);                                                    // 244  min r3.w, r3.w, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 245  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 246  mul r7.w, r7.w, r7.x
            r7.w = r3.w * r7.w;                                                           // 247  mul r7.w, r3.w, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 248  mul r13.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r13.xyz = r2.www * r13.xyz;                                                   // 249  mul r13.xyz, r2.wwww, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 250  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 251  mad r11.xyz, v6.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 252  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 253  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 254  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 255  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r4.xzw));                                         // 256  dp3_sat r9.w, r11.xzyx, r4.xzwx
            r10.w = d3d_log2(r9.w);                                                       // 257  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 258  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 259  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 260  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 261  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r3.w, r6.y);                                                  // 262  min r11.y, r3.w, r6.y
            r9.w = r9.w + r9.w;                                                           // 263  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 264  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 265  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 266  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r3.w, r6.y);                                                  // 267  div r11.w, r3.w, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 268  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 269  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 270  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 271  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 272  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 273  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 274  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 275  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 276  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 277  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 278  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 279  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 280  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 281  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 282  min r7.w, r7.w, l(15.000000)
            r7.w = r3.y * r7.w;                                                           // 283  mul r7.w, r3.y, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 284  mul r11.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r11.xyz = r3.www * r11.xyz;                                                   // 285  mul r11.xyz, r3.wwww, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 286  mul r10.xyz, r7.yyyy, r11.xyzx
            i3.z = (i3.z + 1);                                                            // 287  iadd r3.z, r3.z, l(1)
        }                                                                                 // 288  endloop
        r6.xzw = r9.xyz;                                                                  // 289  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 290  mov r8.yzw, r10.xxyz
    } else { i3.z = (b3.z ? -1 : 0); }                                                    // 291  endif
    r0.xyz = r6.xzw + EmitColor.xyz;                                                      // 292  add r0.xyz, r6.xzwx, cb2[3].yzwy
    r0.xyz = r1.xzw * r0.xyz;                                                             // 293  mul r0.xyz, r1.xzwx, r0.xyzx
    r1.xzw = TintColor.xyz + vec3(-1.0, -1.0, -1.0);                                      // 294  add r1.xzw, cb1[1].xxyz, l(-1.000000, 0.000000, -1.000000, -1.000000)
    r1.xzw = lit_COLOR0.yyy * r1.xzw + vec3(1.0, 1.0, 1.0);                               // 295  mad r1.xzw, v7.yyyy, r1.xxzw, l(1.000000, 0.000000, 1.000000, 1.000000)
    o0.xyz = r0.xyz * r1.xzw + r8.yzw;                                                    // 296  mad o0.xyz, r0.xyzx, r1.xzwx, r8.yzwy
    r0.x = r1.y * lit_COLOR0.w + -AlphaTestRef.x;                                         // 297  mad r0.x, r1.y, v7.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 298  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 299  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 300  mov o0.w, cb2[2].z
    return;                                                                               // 301  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1504(o0, kill);
}
//#### END Fo4LitPs_rec1504 ####
//#### BEGIN Fo4LitPs_rec1507 ####
// class of identical transcribed code: rec1507 t00000101, rec1508 t00000111
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 EnvmapData;                  // name 19, cb1, writer SM 0x14223AA37..AED; .zw none (engine-no-writer seat: fo4 b06 ps EnvmapData.zw)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1507)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 2)  uniform sampler2D t2;
layout(binding = 4)  uniform samplerCube t4;
// b06_BSLighting_PS_rec1507_t00000101  technique 0x00000101 = VC|ENVMAP
// constants by name (fxp offset table of rec1507, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, EnvmapData = cb1[2].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1507(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14;
    bvec4 b0, b2, b4, b5, b8, b9, b11, b12;
    ivec4 i2, i4;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 51  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 52  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 53  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xyzw = texture(t0, lit_TEXCOORD0.xy).xyzw;                                         // 54  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t0.xyzw, s0
    r2.xy = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 55  sample_indexable(texture2d)(float,float,float,float) r2.xy, v1.xyxx, t1.xyzw, s1
    r2.xy = r2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 56  mad r2.xy, r2.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r2.w = dot(r2.xy, r2.xy);                                                             // 57  dp2 r2.w, r2.xyxx, r2.xyxx
    r2.w = d3d_min(r2.w, 1.0);                                                            // 58  min r2.w, r2.w, l(1.000000)
    r2.w = -r2.w + 1.0;                                                                   // 59  add r2.w, -r2.w, l(1.000000)
    r2.z = d3d_sqrt(r2.w);                                                                // 60  sqrt r2.z, r2.w
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 61  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.zw = r3.yx * SpecularParam.xy;                                                     // 62  mul r3.zw, r3.yyyx, cb2[11].xxxy
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 63  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 64  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 65  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 66  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 67  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 68  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 69  add r2.w, -r2.w, l(3.000000)
    r3.w = r3.w * FO4_L_PI;                                                               // 70  mul r3.w, r3.w, l(3.141593)
    r3.z = r3.z * 10.0 + 1.0;                                                             // 71  mad r3.z, r3.z, l(10.000000), l(1.000000)
    r3.z = d3d_exp2(r3.z);                                                                // 72  exp r3.z, r3.z
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 73  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 74  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 75  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 76  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 77  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 78  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 79  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 80  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 81  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 82  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 83  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 84  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 85  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 86  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 87  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 88  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 89  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 90  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 91  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 92  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 93  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 94  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 95  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 96  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 97  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 98  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 99  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 100  dp4 r2.y, r6.xyzw, r8.xyzw
            r4.y = dot(r7.xyzw, r8.xyzw);                                                 // 101  dp4 r4.y, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 102  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r4.y);                                                        // 103  ge r2.x, r2.x, r4.y
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 104  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 105  else
            r2.x = 1.0;                                                                   // 106  mov r2.x, l(1.000000)
        }                                                                                 // 107  endif
    } else {                                                                              // 108  else
        r2.x = 1.0;                                                                       // 109  mov r2.x, l(1.000000)
    }                                                                                     // 110  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 111  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 112  dp3 r2.z, r0.ywzy, r4.xzwx
    r4.y = dot(DirLightDirection.xzy, r4.xzw);                                            // 113  dp3 r4.y, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 114  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r4.yyy + DirLightDirection.xyz;                                    // 115  mad r6.xyz, -r4.xwzx, r4.yyyy, cb2[0].xyzx
    r5.w = dot(r5.xyz, r6.xyz);                                                           // 116  dp3 r5.w, r5.xyzx, r6.xyzx
    r6.x = r2.y * r2.y;                                                                   // 117  mul r6.x, r2.y, r2.y
    r6.yz = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 118  mad r6.yz, r2.yyyy, r2.yyyy, l(0.000000, 0.570000, 0.090000, 0.000000)
    r6.xy = vec2(d3d_div(r6.x, r6.y), d3d_div(r6.x, r6.z));                               // 119  div r6.xy, r6.xxxx, r6.yzyy
    r2.y = r6.y * FO4_L_0_45;                                                             // 120  mul r2.y, r6.y, l(0.450000)
    r6.x = -r6.x * 0.5 + 1.0;                                                             // 121  mad r6.x, -r6.x, l(0.500000), l(1.000000)
    r6.y = -r2.z * r2.z + 1.0;                                                            // 122  mad r6.y, -r2.z, r2.z, l(1.000000)
    r6.z = -r4.y * r4.y + 1.0;                                                            // 123  mad r6.z, -r4.y, r4.y, l(1.000000)
    r6.z = d3d_sat(r6.z * r6.y);                                                          // 124  mul_sat r6.z, r6.z, r6.y
    r6.z = d3d_sqrt(r6.z);                                                                // 125  sqrt r6.z, r6.z
    r6.w = d3d_max(r2.z, r4.y);                                                           // 126  max r6.w, r2.z, r4.y
    r6.z = d3d_div(r6.z, r6.w);                                                           // 127  div r6.z, r6.z, r6.w
    r6.w = d3d_max(r4.y, 0.0);                                                            // 128  max r6.w, r4.y, l(0.000000)
    r5.w = d3d_max(r5.w, 0.0);                                                            // 129  max r5.w, r5.w, l(0.000000)
    r5.w = r2.y * r5.w;                                                                   // 130  mul r5.w, r2.y, r5.w
    r5.w = r5.w * r6.z + r6.x;                                                            // 131  mad r5.w, r5.w, r6.z, r6.x
    r5.w = r5.w * r6.w;                                                                   // 132  mul r5.w, r5.w, r6.w
    r7.xyz = r5.www * DirLightColor.xyz;                                                  // 133  mul r7.xyz, r5.wwww, cb2[1].xyzx
    r5.w = d3d_min(r6.w, 1.0);                                                            // 134  min r5.w, r6.w, l(1.000000)
    r6.z = d3d_sat(r2.z);                                                                 // 135  mov_sat r6.z, r2.z
    r6.w = -r6.z + 1.0;                                                                   // 136  add r6.w, -r6.z, l(1.000000)
    r6.w = d3d_log2(r6.w);                                                                // 137  log r6.w, r6.w
    r6.w = r6.w * FO4_L_0_01;                                                             // 138  mul r6.w, r6.w, l(0.010000)
    r6.w = d3d_exp2(r6.w);                                                                // 139  exp r6.w, r6.w
    r7.w = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 140  dp3_sat r7.w, r0.yzwy, -cb2[0].xyzx
    r7.w = r6.w * r7.w;                                                                   // 141  mul r7.w, r6.w, r7.w
    r7.w = r5.w * r7.w;                                                                   // 142  mul r7.w, r5.w, r7.w
    r8.xyz = r7.www * DirLightColor.xyz;                                                  // 143  mul r8.xyz, r7.wwww, cb2[1].xyzx
    r8.xyz = r2.www * r8.xyz;                                                             // 144  mul r8.xyz, r2.wwww, r8.xyzx
    r7.xyz = r7.xyz * r2.xxx + r8.xyz;                                                    // 145  mad r7.xyz, r7.xyzx, r2.xxxx, r8.xyzx
    r8.xyz = r1.xyz * LightingEffectParams.yyy;                                           // 146  mul r8.xyz, r1.xyzx, cb1[7].yyyy
    r7.w = d3d_sat(-r4.y);                                                                // 147  mov_sat r7.w, -r4.y
    r8.xyz = r8.xyz * r7.www;                                                             // 148  mul r8.xyz, r8.xyzx, r7.wwww
    r7.xyz = DirLightColor.xyz * r8.xyz + r7.xyz;                                         // 149  mad r7.xyz, cb2[1].xyzx, r8.xyzx, r7.xyzx
    r4.y = r4.y + LightingEffectParams.x;                                                 // 150  add r4.y, r4.y, cb1[7].x
    r7.w = LightingEffectParams.x + 1.0;                                                  // 151  add r7.w, cb1[7].x, l(1.000000)
    r4.y = d3d_sat(d3d_div(r4.y, r7.w));                                                  // 152  div_sat r4.y, r4.y, r7.w
    r4.y = -r5.w + r4.y;                                                                  // 153  add r4.y, -r5.w, r4.y
    r4.y = d3d_max(r4.y, 0.0);                                                            // 154  max r4.y, r4.y, l(0.000000)
    r8.xyz = r4.yyy * DirLightColor.xyz;                                                  // 155  mul r8.xyz, r4.yyyy, cb2[1].xyzx
    r7.xyz = r8.xyz * r1.xyz + r7.xyz;                                                    // 156  mad r7.xyz, r8.xyzx, r1.xyzx, r7.xyzx
    r7.xyz = r2.xxx * r7.xyz;                                                             // 157  mul r7.xyz, r2.xxxx, r7.xyzx
    r8.xyz = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 158  mad r8.xyz, v6.xyzx, r0.xxxx, cb2[0].xyzx
    r4.y = dot(r8.xyz, r8.xyz);                                                           // 159  dp3 r4.y, r8.xyzx, r8.xyzx
    r4.y = d3d_rsq(r4.y);                                                                 // 160  rsq r4.y, r4.y
    r8.xyz = r4.yyy * r8.xyz;                                                             // 161  mul r8.xyz, r4.yyyy, r8.xyzx
    r4.y = d3d_sat(dot(r0.yzw, r8.xyz));                                                  // 162  dp3_sat r4.y, r0.yzwy, r8.xyzx
    r7.w = d3d_sat(dot(r8.xzy, r4.xzw));                                                  // 163  dp3_sat r7.w, r8.xzyx, r4.xzwx
    r8.x = r3.z + 2.0;                                                                    // 164  add r8.x, r3.z, l(2.000000)
    r8.x = r8.x * FO4_L_INV_2PI;                                                          // 165  mul r8.x, r8.x, l(0.159155)
    r8.y = d3d_log2(r7.w);                                                                // 166  log r8.y, r7.w
    r8.y = r3.z * r8.y;                                                                   // 167  mul r8.y, r3.z, r8.y
    r8.y = d3d_exp2(r8.y);                                                                // 168  exp r8.y, r8.y
    r8.z = d3d_max(r4.y, FO4_L_2POW_M23);                                                 // 169  max r8.z, r4.y, l(0.000000)
    r8.w = d3d_min(r5.w, r6.z);                                                           // 170  min r8.w, r5.w, r6.z
    r7.w = r7.w + r7.w;                                                                   // 171  add r7.w, r7.w, r7.w
    r9.x = r7.w * r8.w;                                                                   // 172  mul r9.x, r7.w, r8.w
    b9.x = (r8.z >= r9.x);                                                                // 173  ge r9.x, r8.z, r9.x
    b8.w = (r6.z == r8.w);                                                                // 174  eq r8.w, r6.z, r8.w
    r9.y = d3d_div(r5.w, r6.z);                                                           // 175  div r9.y, r5.w, r6.z
    r8.w = b8.w ? 1.0 : r9.y;                                                             // 176  movc r8.w, r8.w, l(1.000000), r9.y
    r7.w = r7.w * r8.w;                                                                   // 177  mul r7.w, r7.w, r8.w
    r7.w = d3d_div(r7.w, r8.z);                                                           // 178  div r7.w, r7.w, r8.z
    r8.z = d3d_div(1.0, r6.z);                                                            // 179  div r8.z, l(1.000000, 1.000000, 1.000000, 1.000000), r6.z
    r7.w = b9.x ? r7.w : r8.z;                                                            // 180  movc r7.w, r9.x, r7.w, r8.z
    r4.y = -r4.y + 1.0;                                                                   // 181  add r4.y, -r4.y, l(1.000000)
    r8.w = r4.y * r4.y;                                                                   // 182  mul r8.w, r4.y, r4.y
    r8.yw = r8.yw * r8.xw;                                                                // 183  mul r8.yw, r8.yyyw, r8.xxxw
    r9.x = r4.y * r8.w;                                                                   // 184  mul r9.x, r4.y, r8.w
    r4.y = -r4.y * r8.w + 1.0;                                                            // 185  mad r4.y, -r4.y, r8.w, l(1.000000)
    r4.y = r4.y * FO4_L_0_2 + r9.x;                                                       // 186  mad r4.y, r4.y, l(0.200000), r9.x
    r4.y = d3d_min(r4.y, 1.0);                                                            // 187  min r4.y, r4.y, l(1.000000)
    r4.y = r7.w * r4.y;                                                                   // 188  mul r4.y, r7.w, r4.y
    r4.y = r8.y * r4.y;                                                                   // 189  mul r4.y, r8.y, r4.y
    r4.y = r4.y * 0.25;                                                                   // 190  mul r4.y, r4.y, l(0.250000)
    r4.y = d3d_min(r4.y, 15.0);                                                           // 191  min r4.y, r4.y, l(15.000000)
    r4.y = r3.w * r4.y;                                                                   // 192  mul r4.y, r3.w, r4.y
    r9.xyz = r4.yyy * DirLightColor.xyz;                                                  // 193  mul r9.xyz, r4.yyyy, cb2[1].xyzx
    r9.xyz = r5.www * r9.xyz;                                                             // 194  mul r9.xyz, r5.wwww, r9.xyzx
    r9.xyz = r2.xxx * r9.xyz;                                                             // 195  mul r9.xyz, r2.xxxx, r9.xyzx
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 196  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 197  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 198  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 199  max r2.x, r2.x, l(0.000000)
    b4.y = (0.0 < r2.x);                                                                  // 200  lt r4.y, l(0.000000), r2.x
    if (b4.y) {                                                                           // 201  if_nz r4.y
        r10.xyz = r7.xyz;                                                                 // 202  mov r10.xyz, r7.xyzx
        r11.xyz = r9.xyz;                                                                 // 203  mov r11.xyz, r9.xyzx
        i4.y = 0;                                                                         // 204  mov r4.y, l(0)
        for (;;) {                                                                        // 205  loop
            r5.w = float(i4.y);                                                           // 206  itof r5.w, r4.y
            b5.w = (r5.w >= r2.x);                                                        // 207  ge r5.w, r5.w, r2.x
            if (b5.w) break;                                                              // 208  breakc_nz r5.w
            r12.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i4.y + 13).xyz;                    // 209  add r12.xyz, -v2.xyzx, cb2[r4.y + 13].xyzx
            r5.w = dot(r12.xyz, r12.xyz);                                                 // 210  dp3 r5.w, r12.xyzx, r12.xyzx
            r7.w = d3d_sqrt(r5.w);                                                        // 211  sqrt r7.w, r5.w
            r7.w = d3d_sat(d3d_div(r7.w, fo4_cb2_row(i4.y + 13).w));                      // 212  div_sat r7.w, r7.w, cb2[r4.y + 13].w
            r7.w = -r7.w * r7.w + 1.0;                                                    // 213  mad r7.w, -r7.w, r7.w, l(1.000000)
            r7.w = d3d_log2(r7.w);                                                        // 214  log r7.w, r7.w
            r7.w = r7.w * FO4_L_2_2;                                                      // 215  mul r7.w, r7.w, l(2.200000)
            r7.w = d3d_exp2(r7.w);                                                        // 216  exp r7.w, r7.w
            r5.w = d3d_rsq(r5.w);                                                         // 217  rsq r5.w, r5.w
            r12.xyz = r5.www * r12.xyz;                                                   // 218  mul r12.xyz, r5.wwww, r12.xyzx
            r5.w = dot(r12.xzy, r4.xzw);                                                  // 219  dp3 r5.w, r12.xzyx, r4.xzwx
            r13.xyz = -r4.xwz * r5.www + r12.xyz;                                         // 220  mad r13.xyz, -r4.xwzx, r5.wwww, r12.xyzx
            r8.y = dot(r5.xyz, r13.xyz);                                                  // 221  dp3 r8.y, r5.xyzx, r13.xyzx
            r8.w = -r5.w * r5.w + 1.0;                                                    // 222  mad r8.w, -r5.w, r5.w, l(1.000000)
            r8.w = d3d_sat(r6.y * r8.w);                                                  // 223  mul_sat r8.w, r6.y, r8.w
            r8.w = d3d_sqrt(r8.w);                                                        // 224  sqrt r8.w, r8.w
            r9.w = d3d_max(r2.z, r5.w);                                                   // 225  max r9.w, r2.z, r5.w
            r8.w = d3d_div(r8.w, r9.w);                                                   // 226  div r8.w, r8.w, r9.w
            r5.w = d3d_max(r5.w, 0.0);                                                    // 227  max r5.w, r5.w, l(0.000000)
            r8.y = d3d_max(r8.y, 0.0);                                                    // 228  max r8.y, r8.y, l(0.000000)
            r8.y = r2.y * r8.y;                                                           // 229  mul r8.y, r2.y, r8.y
            r8.y = r8.y * r8.w + r6.x;                                                    // 230  mad r8.y, r8.y, r8.w, r6.x
            r8.y = r5.w * r8.y;                                                           // 231  mul r8.y, r5.w, r8.y
            r13.xyz = r8.yyy * fo4_cb2_row(i4.y + 19).xyz;                                // 232  mul r13.xyz, r8.yyyy, cb2[r4.y + 19].xyzx
            r8.y = r7.w * r7.w;                                                           // 233  mul r8.y, r7.w, r7.w
            r13.xyz = r8.yyy * r13.xyz + r10.xyz;                                         // 234  mad r13.xyz, r8.yyyy, r13.xyzx, r10.xyzx
            r5.w = d3d_min(r5.w, 1.0);                                                    // 235  min r5.w, r5.w, l(1.000000)
            r8.y = d3d_sat(dot(r0.yzw, -r12.xyz));                                        // 236  dp3_sat r8.y, r0.yzwy, -r12.xyzx
            r8.y = r6.w * r8.y;                                                           // 237  mul r8.y, r6.w, r8.y
            r8.y = r5.w * r8.y;                                                           // 238  mul r8.y, r5.w, r8.y
            r14.xyz = r8.yyy * fo4_cb2_row(i4.y + 19).xyz;                                // 239  mul r14.xyz, r8.yyyy, cb2[r4.y + 19].xyzx
            r14.xyz = r2.www * r14.xyz;                                                   // 240  mul r14.xyz, r2.wwww, r14.xyzx
            r10.xyz = r14.xyz * r7.www + r13.xyz;                                         // 241  mad r10.xyz, r14.xyzx, r7.wwww, r13.xyzx
            r12.xyz = lit_TEXCOORD5.xyz * r0.xxx + r12.xyz;                               // 242  mad r12.xyz, v6.xyzx, r0.xxxx, r12.xyzx
            r8.y = dot(r12.xyz, r12.xyz);                                                 // 243  dp3 r8.y, r12.xyzx, r12.xyzx
            r8.y = d3d_rsq(r8.y);                                                         // 244  rsq r8.y, r8.y
            r12.xyz = r8.yyy * r12.xyz;                                                   // 245  mul r12.xyz, r8.yyyy, r12.xyzx
            r8.y = d3d_sat(dot(r0.yzw, r12.xyz));                                         // 246  dp3_sat r8.y, r0.yzwy, r12.xyzx
            r8.w = d3d_sat(dot(r12.xzy, r4.xzw));                                         // 247  dp3_sat r8.w, r12.xzyx, r4.xzwx
            r9.w = d3d_log2(r8.w);                                                        // 248  log r9.w, r8.w
            r9.w = r3.z * r9.w;                                                           // 249  mul r9.w, r3.z, r9.w
            r9.w = d3d_exp2(r9.w);                                                        // 250  exp r9.w, r9.w
            r9.w = r8.x * r9.w;                                                           // 251  mul r9.w, r8.x, r9.w
            r10.w = d3d_max(r8.y, FO4_L_2POW_M23);                                        // 252  max r10.w, r8.y, l(0.000000)
            r11.w = d3d_min(r5.w, r6.z);                                                  // 253  min r11.w, r5.w, r6.z
            r8.w = r8.w + r8.w;                                                           // 254  add r8.w, r8.w, r8.w
            r12.x = r8.w * r11.w;                                                         // 255  mul r12.x, r8.w, r11.w
            b12.x = (r10.w >= r12.x);                                                     // 256  ge r12.x, r10.w, r12.x
            b11.w = (r6.z == r11.w);                                                      // 257  eq r11.w, r6.z, r11.w
            r12.y = d3d_div(r5.w, r6.z);                                                  // 258  div r12.y, r5.w, r6.z
            r11.w = b11.w ? 1.0 : r12.y;                                                  // 259  movc r11.w, r11.w, l(1.000000), r12.y
            r8.w = r8.w * r11.w;                                                          // 260  mul r8.w, r8.w, r11.w
            r8.w = d3d_div(r8.w, r10.w);                                                  // 261  div r8.w, r8.w, r10.w
            r8.w = b12.x ? r8.w : r8.z;                                                   // 262  movc r8.w, r12.x, r8.w, r8.z
            r8.y = -r8.y + 1.0;                                                           // 263  add r8.y, -r8.y, l(1.000000)
            r10.w = r8.y * r8.y;                                                          // 264  mul r10.w, r8.y, r8.y
            r10.w = r10.w * r10.w;                                                        // 265  mul r10.w, r10.w, r10.w
            r11.w = r8.y * r10.w;                                                         // 266  mul r11.w, r8.y, r10.w
            r8.y = -r8.y * r10.w + 1.0;                                                   // 267  mad r8.y, -r8.y, r10.w, l(1.000000)
            r8.y = r8.y * FO4_L_0_2 + r11.w;                                              // 268  mad r8.y, r8.y, l(0.200000), r11.w
            r8.y = d3d_min(r8.y, 1.0);                                                    // 269  min r8.y, r8.y, l(1.000000)
            r8.y = r8.w * r8.y;                                                           // 270  mul r8.y, r8.w, r8.y
            r8.y = r9.w * r8.y;                                                           // 271  mul r8.y, r9.w, r8.y
            r8.y = r8.y * 0.25;                                                           // 272  mul r8.y, r8.y, l(0.250000)
            r8.y = d3d_min(r8.y, 15.0);                                                   // 273  min r8.y, r8.y, l(15.000000)
            r8.y = r3.w * r8.y;                                                           // 274  mul r8.y, r3.w, r8.y
            r12.xyz = r8.yyy * fo4_cb2_row(i4.y + 19).xyz;                                // 275  mul r12.xyz, r8.yyyy, cb2[r4.y + 19].xyzx
            r12.xyz = r5.www * r12.xyz;                                                   // 276  mul r12.xyz, r5.wwww, r12.xyzx
            r11.xyz = r7.www * r12.xyz;                                                   // 277  mul r11.xyz, r7.wwww, r12.xyzx
            i4.y = (i4.y + 1);                                                            // 278  iadd r4.y, r4.y, l(1)
        }                                                                                 // 279  endloop
        r7.xyz = r10.xyz;                                                                 // 280  mov r7.xyz, r10.xyzx
        r9.xyz = r11.xyz;                                                                 // 281  mov r9.xyz, r11.xyzx
    } else { i4.y = (b4.y ? -1 : 0); }                                                    // 282  endif
    r0.x = -r3.y + 1.0;                                                                   // 283  add r0.x, -r3.y, l(1.000000)
    r0.x = r0.x * 6.0;                                                                    // 284  mul r0.x, r0.x, l(6.000000)
    r0.x = litSvPosition.z * 0.001953125 + r0.x;                                          // 285  mad r0.x, v0.z, l(0.001953), r0.x
    r2.x = r3.x * 3.0;                                                                    // 286  mul r2.x, r3.x, l(3.000000)
    r2.y = d3d_sat(r3.y + FO4_L_M0_3);                                                    // 287  add_sat r2.y, r3.y, l(-0.300000)
    r2.y = d3d_rsq(r2.y);                                                                 // 288  rsq r2.y, r2.y
    r2.y = d3d_div(1.0, r2.y);                                                            // 289  div r2.y, l(1.000000, 1.000000, 1.000000, 1.000000), r2.y
    r2.y = d3d_min(r2.y, 1.0);                                                            // 290  min r2.y, r2.y, l(1.000000)
    r2.x = r2.y * r2.x;                                                                   // 291  mul r2.x, r2.y, r2.x
    r2.x = r2.x * SpecularParam.y;                                                        // 292  mul r2.x, r2.x, cb2[11].y
    r2.y = r2.z + r2.z;                                                                   // 293  add r2.y, r2.z, r2.z
    r0.yzw = r2.yyy * r4.xwz + -r0.yzw;                                                   // 294  mad r0.yzw, r2.yyyy, r4.xxwz, -r0.yyzw
    r0.yzw = -r0.yzw;                                                                     // 295  mov r0.yzw, -r0.yyzw
    r0.xyz = textureLod(t4, r0.yzw, r0.x).xyz;                                            // 296  sample_l_indexable(texturecube)(float,float,float,float) r0.xyz, r0.yzwy, t4.xyzw, s4, r0.x
    r0.xyz = r2.xxx * r0.xyz;                                                             // 297  mul r0.xyz, r2.xxxx, r0.xyzx
    r0.xyz = r0.xyz * EnvmapData.xxx;                                                     // 298  mul r0.xyz, r0.xyzx, cb1[2].xxxx
    r2.xyz = r7.xyz + EmitColor.xyz;                                                      // 299  add r2.xyz, r7.xyzx, cb2[3].yzwy
    r1.xyz = r1.xyz * r2.xyz;                                                             // 300  mul r1.xyz, r1.xyzx, r2.xyzx
    r1.xyz = r1.xyz * lit_COLOR0.xyz + r9.xyz;                                            // 301  mad r1.xyz, r1.xyzx, v7.xyzx, r9.xyzx
    o0.xyz = r0.xyz * r2.xyz + r1.xyz;                                                    // 302  mad o0.xyz, r0.xyzx, r2.xyzx, r1.xyzx
    r0.x = r1.w * lit_COLOR0.w + -AlphaTestRef.x;                                         // 303  mad r0.x, r1.w, v7.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 304  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 305  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 306  mov o0.w, cb2[2].z
    return;                                                                               // 307  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1507(o0, kill);
}
//#### END Fo4LitPs_rec1507 ####
//#### BEGIN Fo4LitPs_rec1509 ####
// class of identical transcribed code: rec1509 t00000C01
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1509)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 2)  uniform sampler2D t2;
// b06_BSLighting_PS_rec1509_t00000C01  technique 0x00000C01 = VC|TREE_ANIM
// constants by name (fxp offset table of rec1509, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1509(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b3, b8, b11;
    ivec4 i2, i3;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 48  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 49  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 50  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xyzw = texture(t0, lit_TEXCOORD0.xy).xyzw;                                         // 51  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t0.xyzw, s0
    r2.xy = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 52  sample_indexable(texture2d)(float,float,float,float) r2.xy, v1.xyxx, t1.xyzw, s1
    r2.xy = r2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 53  mad r2.xy, r2.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r2.w = dot(r2.xy, r2.xy);                                                             // 54  dp2 r2.w, r2.xyxx, r2.xyxx
    r2.w = d3d_min(r2.w, 1.0);                                                            // 55  min r2.w, r2.w, l(1.000000)
    r2.w = -r2.w + 1.0;                                                                   // 56  add r2.w, -r2.w, l(1.000000)
    r2.z = d3d_sqrt(r2.w);                                                                // 57  sqrt r2.z, r2.w
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 58  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 59  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 60  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 61  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 62  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 63  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 64  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 65  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 66  add r2.w, -r2.w, l(3.000000)
    r3.y = r3.z * FO4_L_PI;                                                               // 67  mul r3.y, r3.z, l(3.141593)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 68  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 69  exp r3.x, r3.x
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 70  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 71  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 72  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 73  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 74  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 75  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 76  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 77  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 78  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 79  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 80  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 81  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 82  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 83  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 84  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 85  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 86  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 87  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 88  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 89  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 90  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 91  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 92  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 93  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 94  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 95  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 96  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 97  dp4 r2.y, r6.xyzw, r8.xyzw
            r3.z = dot(r7.xyzw, r8.xyzw);                                                 // 98  dp4 r3.z, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 99  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r3.z);                                                        // 100  ge r2.x, r2.x, r3.z
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 101  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 102  else
            r2.x = 1.0;                                                                   // 103  mov r2.x, l(1.000000)
        }                                                                                 // 104  endif
    } else {                                                                              // 105  else
        r2.x = 1.0;                                                                       // 106  mov r2.x, l(1.000000)
    }                                                                                     // 107  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 108  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 109  dp3 r2.z, r0.ywzy, r4.xzwx
    r3.z = dot(DirLightDirection.xzy, r4.xzw);                                            // 110  dp3 r3.z, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 111  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r3.zzz + DirLightDirection.xyz;                                    // 112  mad r6.xyz, -r4.xwzx, r3.zzzz, cb2[0].xyzx
    r3.w = dot(r5.xyz, r6.xyz);                                                           // 113  dp3 r3.w, r5.xyzx, r6.xyzx
    r4.y = r2.y * r2.y;                                                                   // 114  mul r4.y, r2.y, r2.y
    r6.xy = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 115  mad r6.xy, r2.yyyy, r2.yyyy, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.y, r6.x), d3d_div(r4.y, r6.y));                               // 116  div r6.xy, r4.yyyy, r6.xyxx
    r2.y = r6.y * FO4_L_0_45;                                                             // 117  mul r2.y, r6.y, l(0.450000)
    r4.y = -r6.x * 0.5 + 1.0;                                                             // 118  mad r4.y, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r2.z * r2.z + 1.0;                                                            // 119  mad r5.w, -r2.z, r2.z, l(1.000000)
    r6.x = -r3.z * r3.z + 1.0;                                                            // 120  mad r6.x, -r3.z, r3.z, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 121  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 122  sqrt r6.x, r6.x
    r6.y = d3d_max(r2.z, r3.z);                                                           // 123  max r6.y, r2.z, r3.z
    r6.x = d3d_div(r6.x, r6.y);                                                           // 124  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r3.z, 0.0);                                                            // 125  max r6.y, r3.z, l(0.000000)
    r3.w = d3d_max(r3.w, 0.0);                                                            // 126  max r3.w, r3.w, l(0.000000)
    r3.w = r2.y * r3.w;                                                                   // 127  mul r3.w, r2.y, r3.w
    r3.w = r3.w * r6.x + r4.y;                                                            // 128  mad r3.w, r3.w, r6.x, r4.y
    r3.w = r3.w * r6.y;                                                                   // 129  mul r3.w, r3.w, r6.y
    r6.xzw = r3.www * DirLightColor.xyz;                                                  // 130  mul r6.xzw, r3.wwww, cb2[1].xxyz
    r3.w = d3d_min(r6.y, 1.0);                                                            // 131  min r3.w, r6.y, l(1.000000)
    r6.y = d3d_sat(r2.z);                                                                 // 132  mov_sat r6.y, r2.z
    r7.x = -r6.y + 1.0;                                                                   // 133  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 134  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 135  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 136  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 137  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 138  mul r7.y, r7.y, r7.x
    r7.y = r3.w * r7.y;                                                                   // 139  mul r7.y, r3.w, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 140  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r2.www * r7.yzw;                                                             // 141  mul r7.yzw, r2.wwww, r7.yyzw
    r6.xzw = r6.xzw * r2.xxx + r7.yzw;                                                    // 142  mad r6.xzw, r6.xxzw, r2.xxxx, r7.yyzw
    r7.yzw = r1.xyz * LightingEffectParams.yyy;                                           // 143  mul r7.yzw, r1.xxyz, cb1[7].yyyy
    r8.x = d3d_sat(-r3.z);                                                                // 144  mov_sat r8.x, -r3.z
    r7.yzw = r7.yzw * r8.xxx;                                                             // 145  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 146  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r3.z = r3.z + LightingEffectParams.x;                                                 // 147  add r3.z, r3.z, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 148  add r7.y, cb1[7].x, l(1.000000)
    r3.z = d3d_sat(d3d_div(r3.z, r7.y));                                                  // 149  div_sat r3.z, r3.z, r7.y
    r3.z = -r3.w + r3.z;                                                                  // 150  add r3.z, -r3.w, r3.z
    r3.z = d3d_max(r3.z, 0.0);                                                            // 151  max r3.z, r3.z, l(0.000000)
    r7.yzw = r3.zzz * DirLightColor.xyz;                                                  // 152  mul r7.yzw, r3.zzzz, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xyz + r6.xzw;                                                    // 153  mad r6.xzw, r7.yyzw, r1.xxyz, r6.xxzw
    r6.xzw = r2.xxx * r6.xzw;                                                             // 154  mul r6.xzw, r2.xxxx, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 155  mad r7.yzw, v6.xxyz, r0.xxxx, cb2[0].xxyz
    r3.z = dot(r7.yzw, r7.yzw);                                                           // 156  dp3 r3.z, r7.yzwy, r7.yzwy
    r3.z = d3d_rsq(r3.z);                                                                 // 157  rsq r3.z, r3.z
    r7.yzw = r3.zzz * r7.yzw;                                                             // 158  mul r7.yzw, r3.zzzz, r7.yyzw
    r3.z = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 159  dp3_sat r3.z, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r4.xzw));                                                  // 160  dp3_sat r7.y, r7.ywzy, r4.xzwx
    r7.z = r3.x + 2.0;                                                                    // 161  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 162  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 163  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 164  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 165  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 166  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r3.z, FO4_L_2POW_M23);                                                 // 167  max r8.x, r3.z, l(0.000000)
    r8.y = d3d_min(r3.w, r6.y);                                                           // 168  min r8.y, r3.w, r6.y
    r7.y = r7.y + r7.y;                                                                   // 169  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 170  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 171  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 172  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r3.w, r6.y);                                                           // 173  div r8.w, r3.w, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 174  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 175  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 176  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 177  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 178  movc r7.y, r8.z, r7.y, r8.x
    r3.z = -r3.z + 1.0;                                                                   // 179  add r3.z, -r3.z, l(1.000000)
    r8.y = r3.z * r3.z;                                                                   // 180  mul r8.y, r3.z, r3.z
    r8.y = r8.y * r8.y;                                                                   // 181  mul r8.y, r8.y, r8.y
    r8.z = r3.z * r8.y;                                                                   // 182  mul r8.z, r3.z, r8.y
    r3.z = -r3.z * r8.y + 1.0;                                                            // 183  mad r3.z, -r3.z, r8.y, l(1.000000)
    r3.z = r3.z * FO4_L_0_2 + r8.z;                                                       // 184  mad r3.z, r3.z, l(0.200000), r8.z
    r3.z = d3d_min(r3.z, 1.0);                                                            // 185  min r3.z, r3.z, l(1.000000)
    r3.z = r7.y * r3.z;                                                                   // 186  mul r3.z, r7.y, r3.z
    r3.z = r7.w * r3.z;                                                                   // 187  mul r3.z, r7.w, r3.z
    r3.z = r3.z * 0.25;                                                                   // 188  mul r3.z, r3.z, l(0.250000)
    r3.z = d3d_min(r3.z, 15.0);                                                           // 189  min r3.z, r3.z, l(15.000000)
    r3.z = r3.z * r3.y;                                                                   // 190  mul r3.z, r3.z, r3.y
    r8.yzw = r3.zzz * DirLightColor.xyz;                                                  // 191  mul r8.yzw, r3.zzzz, cb2[1].xxyz
    r8.yzw = r3.www * r8.yzw;                                                             // 192  mul r8.yzw, r3.wwww, r8.yyzw
    r8.yzw = r2.xxx * r8.yzw;                                                             // 193  mul r8.yzw, r2.xxxx, r8.yyzw
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 194  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 195  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 196  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 197  max r2.x, r2.x, l(0.000000)
    b3.z = (0.0 < r2.x);                                                                  // 198  lt r3.z, l(0.000000), r2.x
    if (b3.z) {                                                                           // 199  if_nz r3.z
        r9.xyz = r6.xzw;                                                                  // 200  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 201  mov r10.xyz, r8.yzwy
        i3.z = 0;                                                                         // 202  mov r3.z, l(0)
        for (;;) {                                                                        // 203  loop
            r3.w = float(i3.z);                                                           // 204  itof r3.w, r3.z
            b3.w = (r3.w >= r2.x);                                                        // 205  ge r3.w, r3.w, r2.x
            if (b3.w) break;                                                              // 206  breakc_nz r3.w
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i3.z + 13).xyz;                    // 207  add r11.xyz, -v2.xyzx, cb2[r3.z + 13].xyzx
            r3.w = dot(r11.xyz, r11.xyz);                                                 // 208  dp3 r3.w, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r3.w);                                                        // 209  sqrt r7.y, r3.w
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i3.z + 13).w));                      // 210  div_sat r7.y, r7.y, cb2[r3.z + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 211  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 212  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 213  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 214  exp r7.y, r7.y
            r3.w = d3d_rsq(r3.w);                                                         // 215  rsq r3.w, r3.w
            r11.xyz = r3.www * r11.xyz;                                                   // 216  mul r11.xyz, r3.wwww, r11.xyzx
            r3.w = dot(r11.xzy, r4.xzw);                                                  // 217  dp3 r3.w, r11.xzyx, r4.xzwx
            r12.xyz = -r4.xwz * r3.www + r11.xyz;                                         // 218  mad r12.xyz, -r4.xwzx, r3.wwww, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 219  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r3.w * r3.w + 1.0;                                                    // 220  mad r9.w, -r3.w, r3.w, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 221  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 222  sqrt r9.w, r9.w
            r10.w = d3d_max(r2.z, r3.w);                                                  // 223  max r10.w, r2.z, r3.w
            r9.w = d3d_div(r9.w, r10.w);                                                  // 224  div r9.w, r9.w, r10.w
            r3.w = d3d_max(r3.w, 0.0);                                                    // 225  max r3.w, r3.w, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 226  max r7.w, r7.w, l(0.000000)
            r7.w = r2.y * r7.w;                                                           // 227  mul r7.w, r2.y, r7.w
            r7.w = r7.w * r9.w + r4.y;                                                    // 228  mad r7.w, r7.w, r9.w, r4.y
            r7.w = r3.w * r7.w;                                                           // 229  mul r7.w, r3.w, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 230  mul r12.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 231  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 232  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r3.w = d3d_min(r3.w, 1.0);                                                    // 233  min r3.w, r3.w, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 234  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 235  mul r7.w, r7.w, r7.x
            r7.w = r3.w * r7.w;                                                           // 236  mul r7.w, r3.w, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 237  mul r13.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r13.xyz = r2.www * r13.xyz;                                                   // 238  mul r13.xyz, r2.wwww, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 239  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 240  mad r11.xyz, v6.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 241  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 242  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 243  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 244  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r4.xzw));                                         // 245  dp3_sat r9.w, r11.xzyx, r4.xzwx
            r10.w = d3d_log2(r9.w);                                                       // 246  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 247  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 248  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 249  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 250  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r3.w, r6.y);                                                  // 251  min r11.y, r3.w, r6.y
            r9.w = r9.w + r9.w;                                                           // 252  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 253  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 254  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 255  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r3.w, r6.y);                                                  // 256  div r11.w, r3.w, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 257  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 258  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 259  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 260  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 261  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 262  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 263  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 264  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 265  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 266  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 267  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 268  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 269  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 270  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 271  min r7.w, r7.w, l(15.000000)
            r7.w = r3.y * r7.w;                                                           // 272  mul r7.w, r3.y, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 273  mul r11.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r11.xyz = r3.www * r11.xyz;                                                   // 274  mul r11.xyz, r3.wwww, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 275  mul r10.xyz, r7.yyyy, r11.xyzx
            i3.z = (i3.z + 1);                                                            // 276  iadd r3.z, r3.z, l(1)
        }                                                                                 // 277  endloop
        r6.xzw = r9.xyz;                                                                  // 278  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 279  mov r8.yzw, r10.xxyz
    } else { i3.z = (b3.z ? -1 : 0); }                                                    // 280  endif
    r0.xyz = r6.xzw + EmitColor.xyz;                                                      // 281  add r0.xyz, r6.xzwx, cb2[3].yzwy
    r0.xyz = r1.xyz * r0.xyz;                                                             // 282  mul r0.xyz, r1.xyzx, r0.xyzx
    o0.xyz = r0.xyz * lit_COLOR0.xyz + r8.yzw;                                            // 283  mad o0.xyz, r0.xyzx, v7.xyzx, r8.yzwy
    r0.x = r1.w + -AlphaTestRef.x;                                                        // 284  add r0.x, r1.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 285  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 286  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 287  mov o0.w, cb2[2].z
    return;                                                                               // 288  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1509(o0, kill);
}
//#### END Fo4LitPs_rec1509 ####
//#### BEGIN Fo4LitPs_rec1510 ####
// class of identical transcribed code: rec1510 t00000141
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 EnvmapData;                  // name 19, cb1, writer SM 0x14223AA37..AED; .zw none (engine-no-writer seat: fo4 b06 ps EnvmapData.zw)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
uniform vec4 TintColor;                   // name 21, cb1, writer SM 0x14223ABFA..E1B
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1510)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 15)  uniform sampler2D t15;
layout(binding = 2)  uniform sampler2D t2;
layout(binding = 4)  uniform samplerCube t4;
// b06_BSLighting_PS_rec1510_t00000141  technique 0x00000141 = VC|GRADIENT_REMAP|ENVMAP
// constants by name (fxp offset table of rec1510, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, EnvmapData = cb1[2].x, TintColor = cb1[1].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1510(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14;
    bvec4 b0, b2, b4, b5, b8, b9, b11, b12;
    ivec4 i2, i4;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 53  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 54  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 55  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xy = texture(t0, lit_TEXCOORD0.xy).yw;                                             // 56  sample_indexable(texture2d)(float,float,float,float) r1.xy, v1.xyxx, t0.ywxz, s0
    r1.zw = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 57  sample_indexable(texture2d)(float,float,float,float) r1.zw, v1.xyxx, t1.zwxy, s1
    r2.xy = r1.zw * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 58  mad r2.xy, r1.zwzz, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r1.z = dot(r2.xy, r2.xy);                                                             // 59  dp2 r1.z, r2.xyxx, r2.xyxx
    r1.z = d3d_min(r1.z, 1.0);                                                            // 60  min r1.z, r1.z, l(1.000000)
    r1.z = -r1.z + 1.0;                                                                   // 61  add r1.z, -r1.z, l(1.000000)
    r2.z = d3d_sqrt(r1.z);                                                                // 62  sqrt r2.z, r1.z
    r1.z = d3d_log2(lit_COLOR0.x);                                                        // 63  log r1.z, v7.x
    r1.z = r1.z * FO4_L_0_454545;                                                         // 64  mul r1.z, r1.z, l(0.454545)
    r1.z = d3d_exp2(r1.z);                                                                // 65  exp r1.z, r1.z
    r1.x = d3d_log2(r1.x);                                                                // 66  log r1.x, r1.x
    r1.x = r1.x * FO4_L_0_454545;                                                         // 67  mul r1.x, r1.x, l(0.454545)
    r3.x = d3d_exp2(r1.x);                                                                // 68  exp r3.x, r1.x
    r1.x = -r1.z + 1.0;                                                                   // 69  add r1.x, -r1.z, l(1.000000)
    r3.y = -r1.x + TintColor.x;                                                           // 70  add r3.y, -r1.x, cb1[1].x
    r1.xzw = textureLod(t15, r3.xy, 0.0).xyz;                                             // 71  sample_l_indexable(texture2d)(float,float,float,float) r1.xzw, r3.xyxx, t15.xwyz, s15, l(0.000000)
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 72  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.zw = r3.yx * SpecularParam.xy;                                                     // 73  mul r3.zw, r3.yyyx, cb2[11].xxxy
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 74  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 75  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 76  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 77  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 78  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 79  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 80  add r2.w, -r2.w, l(3.000000)
    r3.w = r3.w * FO4_L_PI;                                                               // 81  mul r3.w, r3.w, l(3.141593)
    r3.z = r3.z * 10.0 + 1.0;                                                             // 82  mad r3.z, r3.z, l(10.000000), l(1.000000)
    r3.z = d3d_exp2(r3.z);                                                                // 83  exp r3.z, r3.z
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 84  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 85  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 86  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 87  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 88  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 89  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 90  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 91  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 92  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 93  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 94  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 95  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 96  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 97  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 98  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 99  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 100  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 101  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 102  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 103  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 104  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 105  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 106  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 107  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 108  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 109  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 110  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 111  dp4 r2.y, r6.xyzw, r8.xyzw
            r4.y = dot(r7.xyzw, r8.xyzw);                                                 // 112  dp4 r4.y, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 113  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r4.y);                                                        // 114  ge r2.x, r2.x, r4.y
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 115  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 116  else
            r2.x = 1.0;                                                                   // 117  mov r2.x, l(1.000000)
        }                                                                                 // 118  endif
    } else {                                                                              // 119  else
        r2.x = 1.0;                                                                       // 120  mov r2.x, l(1.000000)
    }                                                                                     // 121  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 122  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 123  dp3 r2.z, r0.ywzy, r4.xzwx
    r4.y = dot(DirLightDirection.xzy, r4.xzw);                                            // 124  dp3 r4.y, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 125  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r4.yyy + DirLightDirection.xyz;                                    // 126  mad r6.xyz, -r4.xwzx, r4.yyyy, cb2[0].xyzx
    r5.w = dot(r5.xyz, r6.xyz);                                                           // 127  dp3 r5.w, r5.xyzx, r6.xyzx
    r6.x = r2.y * r2.y;                                                                   // 128  mul r6.x, r2.y, r2.y
    r6.yz = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 129  mad r6.yz, r2.yyyy, r2.yyyy, l(0.000000, 0.570000, 0.090000, 0.000000)
    r6.xy = vec2(d3d_div(r6.x, r6.y), d3d_div(r6.x, r6.z));                               // 130  div r6.xy, r6.xxxx, r6.yzyy
    r2.y = r6.y * FO4_L_0_45;                                                             // 131  mul r2.y, r6.y, l(0.450000)
    r6.x = -r6.x * 0.5 + 1.0;                                                             // 132  mad r6.x, -r6.x, l(0.500000), l(1.000000)
    r6.y = -r2.z * r2.z + 1.0;                                                            // 133  mad r6.y, -r2.z, r2.z, l(1.000000)
    r6.z = -r4.y * r4.y + 1.0;                                                            // 134  mad r6.z, -r4.y, r4.y, l(1.000000)
    r6.z = d3d_sat(r6.z * r6.y);                                                          // 135  mul_sat r6.z, r6.z, r6.y
    r6.z = d3d_sqrt(r6.z);                                                                // 136  sqrt r6.z, r6.z
    r6.w = d3d_max(r2.z, r4.y);                                                           // 137  max r6.w, r2.z, r4.y
    r6.z = d3d_div(r6.z, r6.w);                                                           // 138  div r6.z, r6.z, r6.w
    r6.w = d3d_max(r4.y, 0.0);                                                            // 139  max r6.w, r4.y, l(0.000000)
    r5.w = d3d_max(r5.w, 0.0);                                                            // 140  max r5.w, r5.w, l(0.000000)
    r5.w = r2.y * r5.w;                                                                   // 141  mul r5.w, r2.y, r5.w
    r5.w = r5.w * r6.z + r6.x;                                                            // 142  mad r5.w, r5.w, r6.z, r6.x
    r5.w = r5.w * r6.w;                                                                   // 143  mul r5.w, r5.w, r6.w
    r7.xyz = r5.www * DirLightColor.xyz;                                                  // 144  mul r7.xyz, r5.wwww, cb2[1].xyzx
    r5.w = d3d_min(r6.w, 1.0);                                                            // 145  min r5.w, r6.w, l(1.000000)
    r6.z = d3d_sat(r2.z);                                                                 // 146  mov_sat r6.z, r2.z
    r6.w = -r6.z + 1.0;                                                                   // 147  add r6.w, -r6.z, l(1.000000)
    r6.w = d3d_log2(r6.w);                                                                // 148  log r6.w, r6.w
    r6.w = r6.w * FO4_L_0_01;                                                             // 149  mul r6.w, r6.w, l(0.010000)
    r6.w = d3d_exp2(r6.w);                                                                // 150  exp r6.w, r6.w
    r7.w = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 151  dp3_sat r7.w, r0.yzwy, -cb2[0].xyzx
    r7.w = r6.w * r7.w;                                                                   // 152  mul r7.w, r6.w, r7.w
    r7.w = r5.w * r7.w;                                                                   // 153  mul r7.w, r5.w, r7.w
    r8.xyz = r7.www * DirLightColor.xyz;                                                  // 154  mul r8.xyz, r7.wwww, cb2[1].xyzx
    r8.xyz = r2.www * r8.xyz;                                                             // 155  mul r8.xyz, r2.wwww, r8.xyzx
    r7.xyz = r7.xyz * r2.xxx + r8.xyz;                                                    // 156  mad r7.xyz, r7.xyzx, r2.xxxx, r8.xyzx
    r8.xyz = r1.xzw * LightingEffectParams.yyy;                                           // 157  mul r8.xyz, r1.xzwx, cb1[7].yyyy
    r7.w = d3d_sat(-r4.y);                                                                // 158  mov_sat r7.w, -r4.y
    r8.xyz = r8.xyz * r7.www;                                                             // 159  mul r8.xyz, r8.xyzx, r7.wwww
    r7.xyz = DirLightColor.xyz * r8.xyz + r7.xyz;                                         // 160  mad r7.xyz, cb2[1].xyzx, r8.xyzx, r7.xyzx
    r4.y = r4.y + LightingEffectParams.x;                                                 // 161  add r4.y, r4.y, cb1[7].x
    r7.w = LightingEffectParams.x + 1.0;                                                  // 162  add r7.w, cb1[7].x, l(1.000000)
    r4.y = d3d_sat(d3d_div(r4.y, r7.w));                                                  // 163  div_sat r4.y, r4.y, r7.w
    r4.y = -r5.w + r4.y;                                                                  // 164  add r4.y, -r5.w, r4.y
    r4.y = d3d_max(r4.y, 0.0);                                                            // 165  max r4.y, r4.y, l(0.000000)
    r8.xyz = r4.yyy * DirLightColor.xyz;                                                  // 166  mul r8.xyz, r4.yyyy, cb2[1].xyzx
    r7.xyz = r8.xyz * r1.xzw + r7.xyz;                                                    // 167  mad r7.xyz, r8.xyzx, r1.xzwx, r7.xyzx
    r7.xyz = r2.xxx * r7.xyz;                                                             // 168  mul r7.xyz, r2.xxxx, r7.xyzx
    r8.xyz = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 169  mad r8.xyz, v6.xyzx, r0.xxxx, cb2[0].xyzx
    r4.y = dot(r8.xyz, r8.xyz);                                                           // 170  dp3 r4.y, r8.xyzx, r8.xyzx
    r4.y = d3d_rsq(r4.y);                                                                 // 171  rsq r4.y, r4.y
    r8.xyz = r4.yyy * r8.xyz;                                                             // 172  mul r8.xyz, r4.yyyy, r8.xyzx
    r4.y = d3d_sat(dot(r0.yzw, r8.xyz));                                                  // 173  dp3_sat r4.y, r0.yzwy, r8.xyzx
    r7.w = d3d_sat(dot(r8.xzy, r4.xzw));                                                  // 174  dp3_sat r7.w, r8.xzyx, r4.xzwx
    r8.x = r3.z + 2.0;                                                                    // 175  add r8.x, r3.z, l(2.000000)
    r8.x = r8.x * FO4_L_INV_2PI;                                                          // 176  mul r8.x, r8.x, l(0.159155)
    r8.y = d3d_log2(r7.w);                                                                // 177  log r8.y, r7.w
    r8.y = r3.z * r8.y;                                                                   // 178  mul r8.y, r3.z, r8.y
    r8.y = d3d_exp2(r8.y);                                                                // 179  exp r8.y, r8.y
    r8.z = d3d_max(r4.y, FO4_L_2POW_M23);                                                 // 180  max r8.z, r4.y, l(0.000000)
    r8.w = d3d_min(r5.w, r6.z);                                                           // 181  min r8.w, r5.w, r6.z
    r7.w = r7.w + r7.w;                                                                   // 182  add r7.w, r7.w, r7.w
    r9.x = r7.w * r8.w;                                                                   // 183  mul r9.x, r7.w, r8.w
    b9.x = (r8.z >= r9.x);                                                                // 184  ge r9.x, r8.z, r9.x
    b8.w = (r6.z == r8.w);                                                                // 185  eq r8.w, r6.z, r8.w
    r9.y = d3d_div(r5.w, r6.z);                                                           // 186  div r9.y, r5.w, r6.z
    r8.w = b8.w ? 1.0 : r9.y;                                                             // 187  movc r8.w, r8.w, l(1.000000), r9.y
    r7.w = r7.w * r8.w;                                                                   // 188  mul r7.w, r7.w, r8.w
    r7.w = d3d_div(r7.w, r8.z);                                                           // 189  div r7.w, r7.w, r8.z
    r8.z = d3d_div(1.0, r6.z);                                                            // 190  div r8.z, l(1.000000, 1.000000, 1.000000, 1.000000), r6.z
    r7.w = b9.x ? r7.w : r8.z;                                                            // 191  movc r7.w, r9.x, r7.w, r8.z
    r4.y = -r4.y + 1.0;                                                                   // 192  add r4.y, -r4.y, l(1.000000)
    r8.w = r4.y * r4.y;                                                                   // 193  mul r8.w, r4.y, r4.y
    r8.yw = r8.yw * r8.xw;                                                                // 194  mul r8.yw, r8.yyyw, r8.xxxw
    r9.x = r4.y * r8.w;                                                                   // 195  mul r9.x, r4.y, r8.w
    r4.y = -r4.y * r8.w + 1.0;                                                            // 196  mad r4.y, -r4.y, r8.w, l(1.000000)
    r4.y = r4.y * FO4_L_0_2 + r9.x;                                                       // 197  mad r4.y, r4.y, l(0.200000), r9.x
    r4.y = d3d_min(r4.y, 1.0);                                                            // 198  min r4.y, r4.y, l(1.000000)
    r4.y = r7.w * r4.y;                                                                   // 199  mul r4.y, r7.w, r4.y
    r4.y = r8.y * r4.y;                                                                   // 200  mul r4.y, r8.y, r4.y
    r4.y = r4.y * 0.25;                                                                   // 201  mul r4.y, r4.y, l(0.250000)
    r4.y = d3d_min(r4.y, 15.0);                                                           // 202  min r4.y, r4.y, l(15.000000)
    r4.y = r3.w * r4.y;                                                                   // 203  mul r4.y, r3.w, r4.y
    r9.xyz = r4.yyy * DirLightColor.xyz;                                                  // 204  mul r9.xyz, r4.yyyy, cb2[1].xyzx
    r9.xyz = r5.www * r9.xyz;                                                             // 205  mul r9.xyz, r5.wwww, r9.xyzx
    r9.xyz = r2.xxx * r9.xyz;                                                             // 206  mul r9.xyz, r2.xxxx, r9.xyzx
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 207  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 208  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 209  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 210  max r2.x, r2.x, l(0.000000)
    b4.y = (0.0 < r2.x);                                                                  // 211  lt r4.y, l(0.000000), r2.x
    if (b4.y) {                                                                           // 212  if_nz r4.y
        r10.xyz = r7.xyz;                                                                 // 213  mov r10.xyz, r7.xyzx
        r11.xyz = r9.xyz;                                                                 // 214  mov r11.xyz, r9.xyzx
        i4.y = 0;                                                                         // 215  mov r4.y, l(0)
        for (;;) {                                                                        // 216  loop
            r5.w = float(i4.y);                                                           // 217  itof r5.w, r4.y
            b5.w = (r5.w >= r2.x);                                                        // 218  ge r5.w, r5.w, r2.x
            if (b5.w) break;                                                              // 219  breakc_nz r5.w
            r12.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i4.y + 13).xyz;                    // 220  add r12.xyz, -v2.xyzx, cb2[r4.y + 13].xyzx
            r5.w = dot(r12.xyz, r12.xyz);                                                 // 221  dp3 r5.w, r12.xyzx, r12.xyzx
            r7.w = d3d_sqrt(r5.w);                                                        // 222  sqrt r7.w, r5.w
            r7.w = d3d_sat(d3d_div(r7.w, fo4_cb2_row(i4.y + 13).w));                      // 223  div_sat r7.w, r7.w, cb2[r4.y + 13].w
            r7.w = -r7.w * r7.w + 1.0;                                                    // 224  mad r7.w, -r7.w, r7.w, l(1.000000)
            r7.w = d3d_log2(r7.w);                                                        // 225  log r7.w, r7.w
            r7.w = r7.w * FO4_L_2_2;                                                      // 226  mul r7.w, r7.w, l(2.200000)
            r7.w = d3d_exp2(r7.w);                                                        // 227  exp r7.w, r7.w
            r5.w = d3d_rsq(r5.w);                                                         // 228  rsq r5.w, r5.w
            r12.xyz = r5.www * r12.xyz;                                                   // 229  mul r12.xyz, r5.wwww, r12.xyzx
            r5.w = dot(r12.xzy, r4.xzw);                                                  // 230  dp3 r5.w, r12.xzyx, r4.xzwx
            r13.xyz = -r4.xwz * r5.www + r12.xyz;                                         // 231  mad r13.xyz, -r4.xwzx, r5.wwww, r12.xyzx
            r8.y = dot(r5.xyz, r13.xyz);                                                  // 232  dp3 r8.y, r5.xyzx, r13.xyzx
            r8.w = -r5.w * r5.w + 1.0;                                                    // 233  mad r8.w, -r5.w, r5.w, l(1.000000)
            r8.w = d3d_sat(r6.y * r8.w);                                                  // 234  mul_sat r8.w, r6.y, r8.w
            r8.w = d3d_sqrt(r8.w);                                                        // 235  sqrt r8.w, r8.w
            r9.w = d3d_max(r2.z, r5.w);                                                   // 236  max r9.w, r2.z, r5.w
            r8.w = d3d_div(r8.w, r9.w);                                                   // 237  div r8.w, r8.w, r9.w
            r5.w = d3d_max(r5.w, 0.0);                                                    // 238  max r5.w, r5.w, l(0.000000)
            r8.y = d3d_max(r8.y, 0.0);                                                    // 239  max r8.y, r8.y, l(0.000000)
            r8.y = r2.y * r8.y;                                                           // 240  mul r8.y, r2.y, r8.y
            r8.y = r8.y * r8.w + r6.x;                                                    // 241  mad r8.y, r8.y, r8.w, r6.x
            r8.y = r5.w * r8.y;                                                           // 242  mul r8.y, r5.w, r8.y
            r13.xyz = r8.yyy * fo4_cb2_row(i4.y + 19).xyz;                                // 243  mul r13.xyz, r8.yyyy, cb2[r4.y + 19].xyzx
            r8.y = r7.w * r7.w;                                                           // 244  mul r8.y, r7.w, r7.w
            r13.xyz = r8.yyy * r13.xyz + r10.xyz;                                         // 245  mad r13.xyz, r8.yyyy, r13.xyzx, r10.xyzx
            r5.w = d3d_min(r5.w, 1.0);                                                    // 246  min r5.w, r5.w, l(1.000000)
            r8.y = d3d_sat(dot(r0.yzw, -r12.xyz));                                        // 247  dp3_sat r8.y, r0.yzwy, -r12.xyzx
            r8.y = r6.w * r8.y;                                                           // 248  mul r8.y, r6.w, r8.y
            r8.y = r5.w * r8.y;                                                           // 249  mul r8.y, r5.w, r8.y
            r14.xyz = r8.yyy * fo4_cb2_row(i4.y + 19).xyz;                                // 250  mul r14.xyz, r8.yyyy, cb2[r4.y + 19].xyzx
            r14.xyz = r2.www * r14.xyz;                                                   // 251  mul r14.xyz, r2.wwww, r14.xyzx
            r10.xyz = r14.xyz * r7.www + r13.xyz;                                         // 252  mad r10.xyz, r14.xyzx, r7.wwww, r13.xyzx
            r12.xyz = lit_TEXCOORD5.xyz * r0.xxx + r12.xyz;                               // 253  mad r12.xyz, v6.xyzx, r0.xxxx, r12.xyzx
            r8.y = dot(r12.xyz, r12.xyz);                                                 // 254  dp3 r8.y, r12.xyzx, r12.xyzx
            r8.y = d3d_rsq(r8.y);                                                         // 255  rsq r8.y, r8.y
            r12.xyz = r8.yyy * r12.xyz;                                                   // 256  mul r12.xyz, r8.yyyy, r12.xyzx
            r8.y = d3d_sat(dot(r0.yzw, r12.xyz));                                         // 257  dp3_sat r8.y, r0.yzwy, r12.xyzx
            r8.w = d3d_sat(dot(r12.xzy, r4.xzw));                                         // 258  dp3_sat r8.w, r12.xzyx, r4.xzwx
            r9.w = d3d_log2(r8.w);                                                        // 259  log r9.w, r8.w
            r9.w = r3.z * r9.w;                                                           // 260  mul r9.w, r3.z, r9.w
            r9.w = d3d_exp2(r9.w);                                                        // 261  exp r9.w, r9.w
            r9.w = r8.x * r9.w;                                                           // 262  mul r9.w, r8.x, r9.w
            r10.w = d3d_max(r8.y, FO4_L_2POW_M23);                                        // 263  max r10.w, r8.y, l(0.000000)
            r11.w = d3d_min(r5.w, r6.z);                                                  // 264  min r11.w, r5.w, r6.z
            r8.w = r8.w + r8.w;                                                           // 265  add r8.w, r8.w, r8.w
            r12.x = r8.w * r11.w;                                                         // 266  mul r12.x, r8.w, r11.w
            b12.x = (r10.w >= r12.x);                                                     // 267  ge r12.x, r10.w, r12.x
            b11.w = (r6.z == r11.w);                                                      // 268  eq r11.w, r6.z, r11.w
            r12.y = d3d_div(r5.w, r6.z);                                                  // 269  div r12.y, r5.w, r6.z
            r11.w = b11.w ? 1.0 : r12.y;                                                  // 270  movc r11.w, r11.w, l(1.000000), r12.y
            r8.w = r8.w * r11.w;                                                          // 271  mul r8.w, r8.w, r11.w
            r8.w = d3d_div(r8.w, r10.w);                                                  // 272  div r8.w, r8.w, r10.w
            r8.w = b12.x ? r8.w : r8.z;                                                   // 273  movc r8.w, r12.x, r8.w, r8.z
            r8.y = -r8.y + 1.0;                                                           // 274  add r8.y, -r8.y, l(1.000000)
            r10.w = r8.y * r8.y;                                                          // 275  mul r10.w, r8.y, r8.y
            r10.w = r10.w * r10.w;                                                        // 276  mul r10.w, r10.w, r10.w
            r11.w = r8.y * r10.w;                                                         // 277  mul r11.w, r8.y, r10.w
            r8.y = -r8.y * r10.w + 1.0;                                                   // 278  mad r8.y, -r8.y, r10.w, l(1.000000)
            r8.y = r8.y * FO4_L_0_2 + r11.w;                                              // 279  mad r8.y, r8.y, l(0.200000), r11.w
            r8.y = d3d_min(r8.y, 1.0);                                                    // 280  min r8.y, r8.y, l(1.000000)
            r8.y = r8.w * r8.y;                                                           // 281  mul r8.y, r8.w, r8.y
            r8.y = r9.w * r8.y;                                                           // 282  mul r8.y, r9.w, r8.y
            r8.y = r8.y * 0.25;                                                           // 283  mul r8.y, r8.y, l(0.250000)
            r8.y = d3d_min(r8.y, 15.0);                                                   // 284  min r8.y, r8.y, l(15.000000)
            r8.y = r3.w * r8.y;                                                           // 285  mul r8.y, r3.w, r8.y
            r12.xyz = r8.yyy * fo4_cb2_row(i4.y + 19).xyz;                                // 286  mul r12.xyz, r8.yyyy, cb2[r4.y + 19].xyzx
            r12.xyz = r5.www * r12.xyz;                                                   // 287  mul r12.xyz, r5.wwww, r12.xyzx
            r11.xyz = r7.www * r12.xyz;                                                   // 288  mul r11.xyz, r7.wwww, r12.xyzx
            i4.y = (i4.y + 1);                                                            // 289  iadd r4.y, r4.y, l(1)
        }                                                                                 // 290  endloop
        r7.xyz = r10.xyz;                                                                 // 291  mov r7.xyz, r10.xyzx
        r9.xyz = r11.xyz;                                                                 // 292  mov r9.xyz, r11.xyzx
    } else { i4.y = (b4.y ? -1 : 0); }                                                    // 293  endif
    r0.x = -r3.y + 1.0;                                                                   // 294  add r0.x, -r3.y, l(1.000000)
    r0.x = r0.x * 6.0;                                                                    // 295  mul r0.x, r0.x, l(6.000000)
    r0.x = litSvPosition.z * 0.001953125 + r0.x;                                          // 296  mad r0.x, v0.z, l(0.001953), r0.x
    r2.x = r3.x * 3.0;                                                                    // 297  mul r2.x, r3.x, l(3.000000)
    r2.y = d3d_sat(r3.y + FO4_L_M0_3);                                                    // 298  add_sat r2.y, r3.y, l(-0.300000)
    r2.y = d3d_rsq(r2.y);                                                                 // 299  rsq r2.y, r2.y
    r2.y = d3d_div(1.0, r2.y);                                                            // 300  div r2.y, l(1.000000, 1.000000, 1.000000, 1.000000), r2.y
    r2.y = d3d_min(r2.y, 1.0);                                                            // 301  min r2.y, r2.y, l(1.000000)
    r2.x = r2.y * r2.x;                                                                   // 302  mul r2.x, r2.y, r2.x
    r2.x = r2.x * SpecularParam.y;                                                        // 303  mul r2.x, r2.x, cb2[11].y
    r2.y = r2.z + r2.z;                                                                   // 304  add r2.y, r2.z, r2.z
    r0.yzw = r2.yyy * r4.xwz + -r0.yzw;                                                   // 305  mad r0.yzw, r2.yyyy, r4.xxwz, -r0.yyzw
    r0.yzw = -r0.yzw;                                                                     // 306  mov r0.yzw, -r0.yyzw
    r0.xyz = textureLod(t4, r0.yzw, r0.x).xyz;                                            // 307  sample_l_indexable(texturecube)(float,float,float,float) r0.xyz, r0.yzwy, t4.xyzw, s4, r0.x
    r0.xyz = r2.xxx * r0.xyz;                                                             // 308  mul r0.xyz, r2.xxxx, r0.xyzx
    r0.xyz = r0.xyz * EnvmapData.xxx;                                                     // 309  mul r0.xyz, r0.xyzx, cb1[2].xxxx
    r2.xyz = r7.xyz + EmitColor.xyz;                                                      // 310  add r2.xyz, r7.xyzx, cb2[3].yzwy
    r1.xzw = r2.xyz * r1.xzw + r9.xyz;                                                    // 311  mad r1.xzw, r2.xxyz, r1.xxzw, r9.xxyz
    o0.xyz = r0.xyz * r2.xyz + r1.xzw;                                                    // 312  mad o0.xyz, r0.xyzx, r2.xyzx, r1.xzwx
    r0.x = r1.y * lit_COLOR0.w + -AlphaTestRef.x;                                         // 313  mad r0.x, r1.y, v7.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 314  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 315  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 316  mov o0.w, cb2[2].z
    return;                                                                               // 317  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1510(o0, kill);
}
//#### END Fo4LitPs_rec1510 ####
//#### BEGIN Fo4LitPs_rec1511 ####
// class of identical transcribed code: rec1511 t00000005
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1511)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 2)  uniform sampler2D t2;
// b06_BSLighting_PS_rec1511_t00000005  technique 0x00000005 = VC|MODELSPACENORMALS
// constants by name (fxp offset table of rec1511, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1511(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b4, b8, b11;
    ivec4 i2, i4;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 42  dp3 r0.x, v3.xyzx, v3.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 43  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 44  mul r0.yzw, r0.xxxx, v3.xxyz
    r1.xyzw = texture(t0, lit_TEXCOORD0.xy).xyzw;                                         // 45  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t0.xyzw, s0
    r2.xyz = texture(t1, lit_TEXCOORD0.xy).xyz;                                           // 46  sample_indexable(texture2d)(float,float,float,float) r2.xyz, v1.xyxx, t1.xyzw, s1
    r2.xyz = r2.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);                       // 47  mad r2.xyz, r2.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 48  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 49  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r3.y = -r3.y * SpecularParam.x + 1.0;                                                 // 50  mad r3.y, -r3.y, cb2[11].x, l(1.000000)
    r3.y = r3.y * 2.0 + -1.0;                                                             // 51  mad r3.y, r3.y, l(2.000000), l(-1.000000)
    r3.yz = r3.yz * vec2(FO4_L_8_65591, FO4_L_PI);                                        // 52  mul r3.yz, r3.yyzy, l(0.000000, 8.655910, 3.141593, 0.000000)
    r3.y = d3d_exp2(r3.y);                                                                // 53  exp r3.y, r3.y
    r3.y = r3.y + 1.0;                                                                    // 54  add r3.y, r3.y, l(1.000000)
    r3.y = d3d_div(3.0, r3.y);                                                            // 55  div r3.y, l(3.000000), r3.y
    r3.y = -r3.y + 3.0;                                                                   // 56  add r3.y, -r3.y, l(3.000000)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 57  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 58  exp r3.x, r3.x
    r2.w = (lit_SV_IsFrontFace0.x != 0) ? r2.z : -r2.z;                                   // 59  movc r2.w, v5.x, r2.z, -r2.z
    b2.z = (ShadowLightCounts.x == 1.0);                                                  // 60  eq r2.z, cb2[10].x, l(1.000000)
    if (b2.z) {                                                                           // 61  if_nz r2.z
        b2.z = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 62  lt r2.z, v2.w, cb2[37].w
        if (b2.z) {                                                                       // 63  if_nz r2.z
            b4.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 64  lt r4.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b4.z, b4.z, b4.z, b4.z));// 65  movc r5.xyzw, r4.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b4.z, b4.z, b4.z, b4.z));// 66  movc r6.xyzw, r4.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b4.z, b4.z, b4.z, b4.z));// 67  movc r7.xyzw, r4.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b4.z ? -1 : 0) & 1065353216);                                        // 68  and r2.z, r4.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b4.y, b4.y, b4.y, b4.y));// 69  movc r5.xyzw, r4.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b4.y, b4.y, b4.y, b4.y));// 70  movc r6.xyzw, r4.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b4.y, b4.y, b4.y, b4.y));// 71  movc r7.xyzw, r4.yyyy, cb2[33].xyzw, r7.xyzw
            i2.z = (b4.y ? 1073741824 : i2.z);                                            // 72  movc r2.z, r4.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b4.x, b4.x, b4.x, b4.x));// 73  movc r5.xyzw, r4.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b4.x, b4.x, b4.x, b4.x));// 74  movc r6.xyzw, r4.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b4.x, b4.x, b4.x, b4.x));// 75  movc r7.xyzw, r4.xxxx, cb2[36].xyzw, r7.xyzw
            i4.z = (b4.x ? 1077936128 : i2.z);                                            // 76  movc r4.z, r4.x, l(3.000000), r2.z
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 77  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 78  mov r8.w, l(1.000000)
            r4.x = dot(r5.xyzw, r8.xyzw);                                                 // 79  dp4 r4.x, r5.xyzw, r8.xyzw
            r4.y = dot(r6.xyzw, r8.xyzw);                                                 // 80  dp4 r4.y, r6.xyzw, r8.xyzw
            r2.z = dot(r7.xyzw, r8.xyzw);                                                 // 81  dp4 r2.z, r7.xyzw, r8.xyzw
            r3.w = texture(t14, vec3(r4.xy, d3d_layer(intBitsToFloat(i4.z), textureSize(t14, 0).z))).x;// 82  sample_indexable(texture2darray)(float,float,float,float) r3.w, r4.xyzx, t14.yzwx, s14
            b2.z = (r3.w >= r2.z);                                                        // 83  ge r2.z, r3.w, r2.z
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 84  and r2.z, r2.z, l(0x3f800000)
        r2.z = intBitsToFloat(i2.z); } else {                                             // 85  else
            r2.z = 1.0;                                                                   // 86  mov r2.z, l(1.000000)
        }                                                                                 // 87  endif
    } else {                                                                              // 88  else
        r2.z = 1.0;                                                                       // 89  mov r2.z, l(1.000000)
    }                                                                                     // 90  endif
    r3.w = -SpecularParam.x + 1.0;                                                        // 91  add r3.w, -cb2[11].x, l(1.000000)
    r4.x = dot(r0.ywz, r2.xyw);                                                           // 92  dp3 r4.x, r0.ywzy, r2.xywx
    r4.y = dot(DirLightDirection.xzy, r2.xyw);                                            // 93  dp3 r4.y, cb2[0].xzyx, r2.xywx
    r5.xyz = -r2.xwy * r4.xxx + r0.yzw;                                                   // 94  mad r5.xyz, -r2.xwyx, r4.xxxx, r0.yzwy
    r6.xyz = -r2.xwy * r4.yyy + DirLightDirection.xyz;                                    // 95  mad r6.xyz, -r2.xwyx, r4.yyyy, cb2[0].xyzx
    r4.z = dot(r5.xyz, r6.xyz);                                                           // 96  dp3 r4.z, r5.xyzx, r6.xyzx
    r4.w = r3.w * r3.w;                                                                   // 97  mul r4.w, r3.w, r3.w
    r6.xy = r3.ww * r3.ww + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 98  mad r6.xy, r3.wwww, r3.wwww, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.w, r6.x), d3d_div(r4.w, r6.y));                               // 99  div r6.xy, r4.wwww, r6.xyxx
    r3.w = r6.y * FO4_L_0_45;                                                             // 100  mul r3.w, r6.y, l(0.450000)
    r4.w = -r6.x * 0.5 + 1.0;                                                             // 101  mad r4.w, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r4.x * r4.x + 1.0;                                                            // 102  mad r5.w, -r4.x, r4.x, l(1.000000)
    r6.x = -r4.y * r4.y + 1.0;                                                            // 103  mad r6.x, -r4.y, r4.y, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 104  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 105  sqrt r6.x, r6.x
    r6.y = d3d_max(r4.y, r4.x);                                                           // 106  max r6.y, r4.y, r4.x
    r6.x = d3d_div(r6.x, r6.y);                                                           // 107  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r4.y, 0.0);                                                            // 108  max r6.y, r4.y, l(0.000000)
    r4.z = d3d_max(r4.z, 0.0);                                                            // 109  max r4.z, r4.z, l(0.000000)
    r4.z = r3.w * r4.z;                                                                   // 110  mul r4.z, r3.w, r4.z
    r4.z = r4.z * r6.x + r4.w;                                                            // 111  mad r4.z, r4.z, r6.x, r4.w
    r4.z = r4.z * r6.y;                                                                   // 112  mul r4.z, r4.z, r6.y
    r6.xzw = r4.zzz * DirLightColor.xyz;                                                  // 113  mul r6.xzw, r4.zzzz, cb2[1].xxyz
    r4.z = d3d_min(r6.y, 1.0);                                                            // 114  min r4.z, r6.y, l(1.000000)
    r6.y = d3d_sat(r4.x);                                                                 // 115  mov_sat r6.y, r4.x
    r7.x = -r6.y + 1.0;                                                                   // 116  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 117  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 118  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 119  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 120  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 121  mul r7.y, r7.y, r7.x
    r7.y = r4.z * r7.y;                                                                   // 122  mul r7.y, r4.z, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 123  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r3.yyy * r7.yzw;                                                             // 124  mul r7.yzw, r3.yyyy, r7.yyzw
    r6.xzw = r6.xzw * r2.zzz + r7.yzw;                                                    // 125  mad r6.xzw, r6.xxzw, r2.zzzz, r7.yyzw
    r7.yzw = r1.xyz * LightingEffectParams.yyy;                                           // 126  mul r7.yzw, r1.xxyz, cb1[7].yyyy
    r8.x = d3d_sat(-r4.y);                                                                // 127  mov_sat r8.x, -r4.y
    r7.yzw = r7.yzw * r8.xxx;                                                             // 128  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 129  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r4.y = r4.y + LightingEffectParams.x;                                                 // 130  add r4.y, r4.y, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 131  add r7.y, cb1[7].x, l(1.000000)
    r4.y = d3d_sat(d3d_div(r4.y, r7.y));                                                  // 132  div_sat r4.y, r4.y, r7.y
    r4.y = -r4.z + r4.y;                                                                  // 133  add r4.y, -r4.z, r4.y
    r4.y = d3d_max(r4.y, 0.0);                                                            // 134  max r4.y, r4.y, l(0.000000)
    r7.yzw = r4.yyy * DirLightColor.xyz;                                                  // 135  mul r7.yzw, r4.yyyy, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xyz + r6.xzw;                                                    // 136  mad r6.xzw, r7.yyzw, r1.xxyz, r6.xxzw
    r6.xzw = r2.zzz * r6.xzw;                                                             // 137  mul r6.xzw, r2.zzzz, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 138  mad r7.yzw, v3.xxyz, r0.xxxx, cb2[0].xxyz
    r4.y = dot(r7.yzw, r7.yzw);                                                           // 139  dp3 r4.y, r7.yzwy, r7.yzwy
    r4.y = d3d_rsq(r4.y);                                                                 // 140  rsq r4.y, r4.y
    r7.yzw = r4.yyy * r7.yzw;                                                             // 141  mul r7.yzw, r4.yyyy, r7.yyzw
    r4.y = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 142  dp3_sat r4.y, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r2.xyw));                                                  // 143  dp3_sat r7.y, r7.ywzy, r2.xywx
    r7.z = r3.x + 2.0;                                                                    // 144  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 145  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 146  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 147  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 148  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 149  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r4.y, FO4_L_2POW_M23);                                                 // 150  max r8.x, r4.y, l(0.000000)
    r8.y = d3d_min(r4.z, r6.y);                                                           // 151  min r8.y, r4.z, r6.y
    r7.y = r7.y + r7.y;                                                                   // 152  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 153  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 154  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 155  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r4.z, r6.y);                                                           // 156  div r8.w, r4.z, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 157  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 158  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 159  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 160  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 161  movc r7.y, r8.z, r7.y, r8.x
    r4.y = -r4.y + 1.0;                                                                   // 162  add r4.y, -r4.y, l(1.000000)
    r8.y = r4.y * r4.y;                                                                   // 163  mul r8.y, r4.y, r4.y
    r8.y = r8.y * r8.y;                                                                   // 164  mul r8.y, r8.y, r8.y
    r8.z = r4.y * r8.y;                                                                   // 165  mul r8.z, r4.y, r8.y
    r4.y = -r4.y * r8.y + 1.0;                                                            // 166  mad r4.y, -r4.y, r8.y, l(1.000000)
    r4.y = r4.y * FO4_L_0_2 + r8.z;                                                       // 167  mad r4.y, r4.y, l(0.200000), r8.z
    r4.y = d3d_min(r4.y, 1.0);                                                            // 168  min r4.y, r4.y, l(1.000000)
    r4.y = r7.y * r4.y;                                                                   // 169  mul r4.y, r7.y, r4.y
    r4.y = r7.w * r4.y;                                                                   // 170  mul r4.y, r7.w, r4.y
    r4.y = r4.y * 0.25;                                                                   // 171  mul r4.y, r4.y, l(0.250000)
    r4.y = d3d_min(r4.y, 15.0);                                                           // 172  min r4.y, r4.y, l(15.000000)
    r4.y = r3.z * r4.y;                                                                   // 173  mul r4.y, r3.z, r4.y
    r8.yzw = r4.yyy * DirLightColor.xyz;                                                  // 174  mul r8.yzw, r4.yyyy, cb2[1].xxyz
    r8.yzw = r4.zzz * r8.yzw;                                                             // 175  mul r8.yzw, r4.zzzz, r8.yyzw
    r8.yzw = r2.zzz * r8.yzw;                                                             // 176  mul r8.yzw, r2.zzzz, r8.yyzw
    r2.z = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 177  frc r2.z, cb2[19].w
    r2.z = -r2.z + PointLightColor[0].w;                                                  // 178  add r2.z, -r2.z, cb2[19].w
    r2.z = d3d_min(r2.z, 20.0);                                                           // 179  min r2.z, r2.z, l(20.000000)
    r2.z = d3d_max(r2.z, 0.0);                                                            // 180  max r2.z, r2.z, l(0.000000)
    b4.y = (0.0 < r2.z);                                                                  // 181  lt r4.y, l(0.000000), r2.z
    if (b4.y) {                                                                           // 182  if_nz r4.y
        r9.xyz = r6.xzw;                                                                  // 183  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 184  mov r10.xyz, r8.yzwy
        i4.y = 0;                                                                         // 185  mov r4.y, l(0)
        for (;;) {                                                                        // 186  loop
            r4.z = float(i4.y);                                                           // 187  itof r4.z, r4.y
            b4.z = (r4.z >= r2.z);                                                        // 188  ge r4.z, r4.z, r2.z
            if (b4.z) break;                                                              // 189  breakc_nz r4.z
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i4.y + 13).xyz;                    // 190  add r11.xyz, -v2.xyzx, cb2[r4.y + 13].xyzx
            r4.z = dot(r11.xyz, r11.xyz);                                                 // 191  dp3 r4.z, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r4.z);                                                        // 192  sqrt r7.y, r4.z
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i4.y + 13).w));                      // 193  div_sat r7.y, r7.y, cb2[r4.y + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 194  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 195  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 196  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 197  exp r7.y, r7.y
            r4.z = d3d_rsq(r4.z);                                                         // 198  rsq r4.z, r4.z
            r11.xyz = r4.zzz * r11.xyz;                                                   // 199  mul r11.xyz, r4.zzzz, r11.xyzx
            r4.z = dot(r11.xzy, r2.xyw);                                                  // 200  dp3 r4.z, r11.xzyx, r2.xywx
            r12.xyz = -r2.xwy * r4.zzz + r11.xyz;                                         // 201  mad r12.xyz, -r2.xwyx, r4.zzzz, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 202  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r4.z * r4.z + 1.0;                                                    // 203  mad r9.w, -r4.z, r4.z, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 204  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 205  sqrt r9.w, r9.w
            r10.w = d3d_max(r4.z, r4.x);                                                  // 206  max r10.w, r4.z, r4.x
            r9.w = d3d_div(r9.w, r10.w);                                                  // 207  div r9.w, r9.w, r10.w
            r4.z = d3d_max(r4.z, 0.0);                                                    // 208  max r4.z, r4.z, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 209  max r7.w, r7.w, l(0.000000)
            r7.w = r3.w * r7.w;                                                           // 210  mul r7.w, r3.w, r7.w
            r7.w = r7.w * r9.w + r4.w;                                                    // 211  mad r7.w, r7.w, r9.w, r4.w
            r7.w = r4.z * r7.w;                                                           // 212  mul r7.w, r4.z, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i4.y + 19).xyz;                                // 213  mul r12.xyz, r7.wwww, cb2[r4.y + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 214  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 215  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r4.z = d3d_min(r4.z, 1.0);                                                    // 216  min r4.z, r4.z, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 217  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 218  mul r7.w, r7.w, r7.x
            r7.w = r4.z * r7.w;                                                           // 219  mul r7.w, r4.z, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i4.y + 19).xyz;                                // 220  mul r13.xyz, r7.wwww, cb2[r4.y + 19].xyzx
            r13.xyz = r3.yyy * r13.xyz;                                                   // 221  mul r13.xyz, r3.yyyy, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 222  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 223  mad r11.xyz, v3.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 224  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 225  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 226  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 227  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r2.xyw));                                         // 228  dp3_sat r9.w, r11.xzyx, r2.xywx
            r10.w = d3d_log2(r9.w);                                                       // 229  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 230  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 231  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 232  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 233  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r4.z, r6.y);                                                  // 234  min r11.y, r4.z, r6.y
            r9.w = r9.w + r9.w;                                                           // 235  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 236  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 237  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 238  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r4.z, r6.y);                                                  // 239  div r11.w, r4.z, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 240  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 241  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 242  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 243  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 244  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 245  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 246  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 247  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 248  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 249  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 250  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 251  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 252  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 253  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 254  min r7.w, r7.w, l(15.000000)
            r7.w = r3.z * r7.w;                                                           // 255  mul r7.w, r3.z, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i4.y + 19).xyz;                                // 256  mul r11.xyz, r7.wwww, cb2[r4.y + 19].xyzx
            r11.xyz = r4.zzz * r11.xyz;                                                   // 257  mul r11.xyz, r4.zzzz, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 258  mul r10.xyz, r7.yyyy, r11.xyzx
            i4.y = (i4.y + 1);                                                            // 259  iadd r4.y, r4.y, l(1)
        }                                                                                 // 260  endloop
        r6.xzw = r9.xyz;                                                                  // 261  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 262  mov r8.yzw, r10.xxyz
    } else { i4.y = (b4.y ? -1 : 0); }                                                    // 263  endif
    r0.xyz = r6.xzw + EmitColor.xyz;                                                      // 264  add r0.xyz, r6.xzwx, cb2[3].yzwy
    r0.xyz = r1.xyz * r0.xyz;                                                             // 265  mul r0.xyz, r1.xyzx, r0.xyzx
    o0.xyz = r0.xyz * lit_COLOR0.xyz + r8.yzw;                                            // 266  mad o0.xyz, r0.xyzx, v4.xyzx, r8.yzwy
    r0.x = r1.w * lit_COLOR0.w + -AlphaTestRef.x;                                         // 267  mad r0.x, r1.w, v4.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 268  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 269  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 270  mov o0.w, cb2[2].z
    return;                                                                               // 271  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1511(o0, kill);
}
//#### END Fo4LitPs_rec1511 ####
//#### BEGIN Fo4LitPs_rec1512 ####
// class of identical transcribed code: rec1512 t00000201, rec1513 t00000211
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1512)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 2)  uniform sampler2D t2;
layout(binding = 6)  uniform sampler2D t6;
// b06_BSLighting_PS_rec1512_t00000201  technique 0x00000201 = VC|GLOWMAP
// constants by name (fxp offset table of rec1512, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1512(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b3, b8, b11;
    ivec4 i2, i3;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 50  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 51  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 52  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xyzw = texture(t0, lit_TEXCOORD0.xy).xyzw;                                         // 53  sample_indexable(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t0.xyzw, s0
    r2.xy = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 54  sample_indexable(texture2d)(float,float,float,float) r2.xy, v1.xyxx, t1.xyzw, s1
    r2.xy = r2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 55  mad r2.xy, r2.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r2.w = dot(r2.xy, r2.xy);                                                             // 56  dp2 r2.w, r2.xyxx, r2.xyxx
    r2.w = d3d_min(r2.w, 1.0);                                                            // 57  min r2.w, r2.w, l(1.000000)
    r2.w = -r2.w + 1.0;                                                                   // 58  add r2.w, -r2.w, l(1.000000)
    r2.z = d3d_sqrt(r2.w);                                                                // 59  sqrt r2.z, r2.w
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 60  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 61  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 62  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 63  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 64  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 65  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 66  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 67  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 68  add r2.w, -r2.w, l(3.000000)
    r3.y = r3.z * FO4_L_PI;                                                               // 69  mul r3.y, r3.z, l(3.141593)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 70  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 71  exp r3.x, r3.x
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 72  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 73  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 74  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 75  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 76  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 77  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 78  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 79  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 80  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 81  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 82  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 83  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 84  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 85  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 86  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 87  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 88  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 89  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 90  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 91  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 92  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 93  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 94  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 95  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 96  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 97  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 98  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 99  dp4 r2.y, r6.xyzw, r8.xyzw
            r3.z = dot(r7.xyzw, r8.xyzw);                                                 // 100  dp4 r3.z, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 101  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r3.z);                                                        // 102  ge r2.x, r2.x, r3.z
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 103  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 104  else
            r2.x = 1.0;                                                                   // 105  mov r2.x, l(1.000000)
        }                                                                                 // 106  endif
    } else {                                                                              // 107  else
        r2.x = 1.0;                                                                       // 108  mov r2.x, l(1.000000)
    }                                                                                     // 109  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 110  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 111  dp3 r2.z, r0.ywzy, r4.xzwx
    r3.z = dot(DirLightDirection.xzy, r4.xzw);                                            // 112  dp3 r3.z, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 113  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r3.zzz + DirLightDirection.xyz;                                    // 114  mad r6.xyz, -r4.xwzx, r3.zzzz, cb2[0].xyzx
    r3.w = dot(r5.xyz, r6.xyz);                                                           // 115  dp3 r3.w, r5.xyzx, r6.xyzx
    r4.y = r2.y * r2.y;                                                                   // 116  mul r4.y, r2.y, r2.y
    r6.xy = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 117  mad r6.xy, r2.yyyy, r2.yyyy, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.y, r6.x), d3d_div(r4.y, r6.y));                               // 118  div r6.xy, r4.yyyy, r6.xyxx
    r2.y = r6.y * FO4_L_0_45;                                                             // 119  mul r2.y, r6.y, l(0.450000)
    r4.y = -r6.x * 0.5 + 1.0;                                                             // 120  mad r4.y, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r2.z * r2.z + 1.0;                                                            // 121  mad r5.w, -r2.z, r2.z, l(1.000000)
    r6.x = -r3.z * r3.z + 1.0;                                                            // 122  mad r6.x, -r3.z, r3.z, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 123  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 124  sqrt r6.x, r6.x
    r6.y = d3d_max(r2.z, r3.z);                                                           // 125  max r6.y, r2.z, r3.z
    r6.x = d3d_div(r6.x, r6.y);                                                           // 126  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r3.z, 0.0);                                                            // 127  max r6.y, r3.z, l(0.000000)
    r3.w = d3d_max(r3.w, 0.0);                                                            // 128  max r3.w, r3.w, l(0.000000)
    r3.w = r2.y * r3.w;                                                                   // 129  mul r3.w, r2.y, r3.w
    r3.w = r3.w * r6.x + r4.y;                                                            // 130  mad r3.w, r3.w, r6.x, r4.y
    r3.w = r3.w * r6.y;                                                                   // 131  mul r3.w, r3.w, r6.y
    r6.xzw = r3.www * DirLightColor.xyz;                                                  // 132  mul r6.xzw, r3.wwww, cb2[1].xxyz
    r3.w = d3d_min(r6.y, 1.0);                                                            // 133  min r3.w, r6.y, l(1.000000)
    r6.y = d3d_sat(r2.z);                                                                 // 134  mov_sat r6.y, r2.z
    r7.x = -r6.y + 1.0;                                                                   // 135  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 136  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 137  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 138  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 139  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 140  mul r7.y, r7.y, r7.x
    r7.y = r3.w * r7.y;                                                                   // 141  mul r7.y, r3.w, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 142  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r2.www * r7.yzw;                                                             // 143  mul r7.yzw, r2.wwww, r7.yyzw
    r6.xzw = r6.xzw * r2.xxx + r7.yzw;                                                    // 144  mad r6.xzw, r6.xxzw, r2.xxxx, r7.yyzw
    r7.yzw = r1.xyz * LightingEffectParams.yyy;                                           // 145  mul r7.yzw, r1.xxyz, cb1[7].yyyy
    r8.x = d3d_sat(-r3.z);                                                                // 146  mov_sat r8.x, -r3.z
    r7.yzw = r7.yzw * r8.xxx;                                                             // 147  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 148  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r3.z = r3.z + LightingEffectParams.x;                                                 // 149  add r3.z, r3.z, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 150  add r7.y, cb1[7].x, l(1.000000)
    r3.z = d3d_sat(d3d_div(r3.z, r7.y));                                                  // 151  div_sat r3.z, r3.z, r7.y
    r3.z = -r3.w + r3.z;                                                                  // 152  add r3.z, -r3.w, r3.z
    r3.z = d3d_max(r3.z, 0.0);                                                            // 153  max r3.z, r3.z, l(0.000000)
    r7.yzw = r3.zzz * DirLightColor.xyz;                                                  // 154  mul r7.yzw, r3.zzzz, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xyz + r6.xzw;                                                    // 155  mad r6.xzw, r7.yyzw, r1.xxyz, r6.xxzw
    r6.xzw = r2.xxx * r6.xzw;                                                             // 156  mul r6.xzw, r2.xxxx, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 157  mad r7.yzw, v6.xxyz, r0.xxxx, cb2[0].xxyz
    r3.z = dot(r7.yzw, r7.yzw);                                                           // 158  dp3 r3.z, r7.yzwy, r7.yzwy
    r3.z = d3d_rsq(r3.z);                                                                 // 159  rsq r3.z, r3.z
    r7.yzw = r3.zzz * r7.yzw;                                                             // 160  mul r7.yzw, r3.zzzz, r7.yyzw
    r3.z = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 161  dp3_sat r3.z, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r4.xzw));                                                  // 162  dp3_sat r7.y, r7.ywzy, r4.xzwx
    r7.z = r3.x + 2.0;                                                                    // 163  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 164  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 165  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 166  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 167  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 168  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r3.z, FO4_L_2POW_M23);                                                 // 169  max r8.x, r3.z, l(0.000000)
    r8.y = d3d_min(r3.w, r6.y);                                                           // 170  min r8.y, r3.w, r6.y
    r7.y = r7.y + r7.y;                                                                   // 171  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 172  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 173  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 174  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r3.w, r6.y);                                                           // 175  div r8.w, r3.w, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 176  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 177  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 178  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 179  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 180  movc r7.y, r8.z, r7.y, r8.x
    r3.z = -r3.z + 1.0;                                                                   // 181  add r3.z, -r3.z, l(1.000000)
    r8.y = r3.z * r3.z;                                                                   // 182  mul r8.y, r3.z, r3.z
    r8.y = r8.y * r8.y;                                                                   // 183  mul r8.y, r8.y, r8.y
    r8.z = r3.z * r8.y;                                                                   // 184  mul r8.z, r3.z, r8.y
    r3.z = -r3.z * r8.y + 1.0;                                                            // 185  mad r3.z, -r3.z, r8.y, l(1.000000)
    r3.z = r3.z * FO4_L_0_2 + r8.z;                                                       // 186  mad r3.z, r3.z, l(0.200000), r8.z
    r3.z = d3d_min(r3.z, 1.0);                                                            // 187  min r3.z, r3.z, l(1.000000)
    r3.z = r7.y * r3.z;                                                                   // 188  mul r3.z, r7.y, r3.z
    r3.z = r7.w * r3.z;                                                                   // 189  mul r3.z, r7.w, r3.z
    r3.z = r3.z * 0.25;                                                                   // 190  mul r3.z, r3.z, l(0.250000)
    r3.z = d3d_min(r3.z, 15.0);                                                           // 191  min r3.z, r3.z, l(15.000000)
    r3.z = r3.z * r3.y;                                                                   // 192  mul r3.z, r3.z, r3.y
    r8.yzw = r3.zzz * DirLightColor.xyz;                                                  // 193  mul r8.yzw, r3.zzzz, cb2[1].xxyz
    r8.yzw = r3.www * r8.yzw;                                                             // 194  mul r8.yzw, r3.wwww, r8.yyzw
    r8.yzw = r2.xxx * r8.yzw;                                                             // 195  mul r8.yzw, r2.xxxx, r8.yyzw
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 196  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 197  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 198  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 199  max r2.x, r2.x, l(0.000000)
    b3.z = (0.0 < r2.x);                                                                  // 200  lt r3.z, l(0.000000), r2.x
    if (b3.z) {                                                                           // 201  if_nz r3.z
        r9.xyz = r6.xzw;                                                                  // 202  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 203  mov r10.xyz, r8.yzwy
        i3.z = 0;                                                                         // 204  mov r3.z, l(0)
        for (;;) {                                                                        // 205  loop
            r3.w = float(i3.z);                                                           // 206  itof r3.w, r3.z
            b3.w = (r3.w >= r2.x);                                                        // 207  ge r3.w, r3.w, r2.x
            if (b3.w) break;                                                              // 208  breakc_nz r3.w
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i3.z + 13).xyz;                    // 209  add r11.xyz, -v2.xyzx, cb2[r3.z + 13].xyzx
            r3.w = dot(r11.xyz, r11.xyz);                                                 // 210  dp3 r3.w, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r3.w);                                                        // 211  sqrt r7.y, r3.w
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i3.z + 13).w));                      // 212  div_sat r7.y, r7.y, cb2[r3.z + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 213  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 214  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 215  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 216  exp r7.y, r7.y
            r3.w = d3d_rsq(r3.w);                                                         // 217  rsq r3.w, r3.w
            r11.xyz = r3.www * r11.xyz;                                                   // 218  mul r11.xyz, r3.wwww, r11.xyzx
            r3.w = dot(r11.xzy, r4.xzw);                                                  // 219  dp3 r3.w, r11.xzyx, r4.xzwx
            r12.xyz = -r4.xwz * r3.www + r11.xyz;                                         // 220  mad r12.xyz, -r4.xwzx, r3.wwww, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 221  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r3.w * r3.w + 1.0;                                                    // 222  mad r9.w, -r3.w, r3.w, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 223  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 224  sqrt r9.w, r9.w
            r10.w = d3d_max(r2.z, r3.w);                                                  // 225  max r10.w, r2.z, r3.w
            r9.w = d3d_div(r9.w, r10.w);                                                  // 226  div r9.w, r9.w, r10.w
            r3.w = d3d_max(r3.w, 0.0);                                                    // 227  max r3.w, r3.w, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 228  max r7.w, r7.w, l(0.000000)
            r7.w = r2.y * r7.w;                                                           // 229  mul r7.w, r2.y, r7.w
            r7.w = r7.w * r9.w + r4.y;                                                    // 230  mad r7.w, r7.w, r9.w, r4.y
            r7.w = r3.w * r7.w;                                                           // 231  mul r7.w, r3.w, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 232  mul r12.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 233  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 234  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r3.w = d3d_min(r3.w, 1.0);                                                    // 235  min r3.w, r3.w, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 236  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 237  mul r7.w, r7.w, r7.x
            r7.w = r3.w * r7.w;                                                           // 238  mul r7.w, r3.w, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 239  mul r13.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r13.xyz = r2.www * r13.xyz;                                                   // 240  mul r13.xyz, r2.wwww, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 241  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 242  mad r11.xyz, v6.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 243  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 244  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 245  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 246  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r4.xzw));                                         // 247  dp3_sat r9.w, r11.xzyx, r4.xzwx
            r10.w = d3d_log2(r9.w);                                                       // 248  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 249  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 250  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 251  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 252  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r3.w, r6.y);                                                  // 253  min r11.y, r3.w, r6.y
            r9.w = r9.w + r9.w;                                                           // 254  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 255  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 256  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 257  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r3.w, r6.y);                                                  // 258  div r11.w, r3.w, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 259  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 260  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 261  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 262  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 263  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 264  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 265  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 266  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 267  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 268  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 269  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 270  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 271  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 272  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 273  min r7.w, r7.w, l(15.000000)
            r7.w = r3.y * r7.w;                                                           // 274  mul r7.w, r3.y, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 275  mul r11.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r11.xyz = r3.www * r11.xyz;                                                   // 276  mul r11.xyz, r3.wwww, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 277  mul r10.xyz, r7.yyyy, r11.xyzx
            i3.z = (i3.z + 1);                                                            // 278  iadd r3.z, r3.z, l(1)
        }                                                                                 // 279  endloop
        r6.xzw = r9.xyz;                                                                  // 280  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 281  mov r8.yzw, r10.xxyz
    } else { i3.z = (b3.z ? -1 : 0); }                                                    // 282  endif
    r0.xyz = texture(t6, lit_TEXCOORD0.xy).xyz;                                           // 283  sample_indexable(texture2d)(float,float,float,float) r0.xyz, v1.xyxx, t6.xyzw, s6
    r0.xyz = EmitColor.xyz * r0.xyz + r6.xzw;                                             // 284  mad r0.xyz, cb2[3].yzwy, r0.xyzx, r6.xzwx
    r0.xyz = r1.xyz * r0.xyz;                                                             // 285  mul r0.xyz, r1.xyzx, r0.xyzx
    o0.xyz = r0.xyz * lit_COLOR0.xyz + r8.yzw;                                            // 286  mad o0.xyz, r0.xyzx, v7.xyzx, r8.yzwy
    r0.x = r1.w * lit_COLOR0.w + -AlphaTestRef.x;                                         // 287  mad r0.x, r1.w, v7.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 288  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 289  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 290  mov o0.w, cb2[2].z
    return;                                                                               // 291  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1512(o0, kill);
}
//#### END Fo4LitPs_rec1512 ####
//#### BEGIN Fo4LitPs_rec1514 ####
// class of identical transcribed code: rec1514 t00000041, rec1515 t00000051
// PS inputs: the VS outputs by semantic (lit_<SEMANTIC><index>); SV_POSITION.xy = litSvPosition (the app entry sets it)
in vec4 lit_TEXCOORD0;
in vec4 lit_TEXCOORD4;
in vec4 lit_TEXCOORD1;
in vec4 lit_TEXCOORD2;
in vec4 lit_TEXCOORD3;
in vec4 lit_TEXCOORD5;
in vec4 lit_COLOR0;
flat in int lit_SV_IsFrontFace0;
uniform vec4 AlphaTestRef;                // name 8, cb2, writer SG 0x14223B958; .yzw none (engine-no-writer seat: fo4 b06 ps AlphaTestRef.yzw)
uniform vec4 DirLightColor;               // name 3, cb2, writer SG>0x14223C3C0 0x14223C4C9..4F0; .w none (engine-no-writer seat: fo4 b06 ps DirLightColor.w)
uniform vec4 DirLightDirection;           // name 2, cb2, writer SG>0x14223C3C0 0x14223C5AD..61E; .w none (engine-no-writer seat: fo4 b06 ps DirLightDirection.w)
uniform vec4 DirShadowMapProj[12];            // name 16, cb2, writer SG 0x14223B679..684 rows 0..3 without SKINNED (0x14223B5A4); SG>0x14223C3C0 0x14223C714..8B9 3 rows per cascade
uniform vec4 EmitColor;                   // name 7, cb2, writer SG 0x14223B7E1..7E5; .w none (engine-no-writer seat: fo4 b06 ps EmitColor.w)
uniform vec4 LightingEffectParams;        // name 27, cb1, writer SM 0x14223B09C..0A5; .zw none (engine-no-writer seat: fo4 b06 ps LightingEffectParams.zw)
uniform vec4 MaterialData;                // name 6, cb2, writer SG 0x14223B363..730; .yw none (engine-no-writer seat: fo4 b06 ps MaterialData.yw)
uniform vec4 PointLightColor[6];             // name 1, cb2, writer SG 0x14223B8F5; SG>0x14223CE00 0x14223CE6F..0x14223D044
uniform vec4 PointLightPosition[6];          // name 0, cb2, writer SG>0x14223CE00 0x14223CFEF..0x14223D052
uniform vec4 ShadowLightCounts;           // name 13, cb2, writer SG>0x14223C3C0 0x14223C45B; .yzw none (engine-no-writer seat: fo4 b06 ps ShadowLightCounts.yzw)
uniform vec4 SpecularParam;               // name 14, cb2, writer SG 0x14223B845..866
uniform vec4 SplitDistances;              // name 17, cb2, writer SG>0x14223C3C0 0x14223CA5A
uniform vec4 TintColor;                   // name 21, cb1, writer SM 0x14223ABFA..E1B
// the record's cb2 by row (D3D11.3 7.5: a dynamic read indexes the buffer, not a name; rows 13..33 by the fxp table of rec1514)
vec4 fo4_cb2_row(int r)
{
    if (r == 13) return PointLightPosition[0];
    if (r == 14) return PointLightPosition[1];
    if (r == 15) return PointLightPosition[2];
    if (r == 16) return PointLightPosition[3];
    if (r == 17) return PointLightPosition[4];
    if (r == 18) return PointLightPosition[5];
    if (r == 19) return PointLightColor[0];
    if (r == 20) return PointLightColor[1];
    if (r == 21) return PointLightColor[2];
    if (r == 22) return PointLightColor[3];
    if (r == 23) return PointLightColor[4];
    if (r == 24) return PointLightColor[5];
    if (r == 25) return DirShadowMapProj[0];
    if (r == 26) return DirShadowMapProj[1];
    if (r == 27) return DirShadowMapProj[2];
    if (r == 28) return DirShadowMapProj[3];
    if (r == 29) return DirShadowMapProj[4];
    if (r == 30) return DirShadowMapProj[5];
    if (r == 31) return DirShadowMapProj[6];
    if (r == 32) return DirShadowMapProj[7];
    if (r == 33) return DirShadowMapProj[8];
    return vec4(0.0);
}
layout(binding = 0)  uniform sampler2D t0;
layout(binding = 1)  uniform sampler2D t1;
layout(binding = 14)  uniform sampler2DArray t14;
layout(binding = 15)  uniform sampler2D t15;
layout(binding = 2)  uniform sampler2D t2;
// b06_BSLighting_PS_rec1514_t00000041  technique 0x00000041 = VC|GRADIENT_REMAP
// constants by name (fxp offset table of rec1514, loader 0x14181DDD0, obj+0x58; names 0x142243B80): PointLightPosition = cb2[13].x, PointLightColor = cb2[19].x, DirLightDirection = cb2[0].x, DirLightColor = cb2[1].x, MaterialData = cb2[2].x, EmitColor = cb2[3].y, AlphaTestRef = cb2[3].x, ShadowLightCounts = cb2[10].x, SpecularParam = cb2[11].x, DirShadowMapProj = cb2[25].x, SplitDistances = cb2[37].x, TintColor = cb1[1].x, LightingEffectParams = cb1[7].x
void Fo4LitPs_rec1514(out vec4 o0, out bool kill)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13;
    bvec4 b0, b2, b3, b8, b11;
    ivec4 i2, i3;
    o0 = vec4(0.0);   // unwritten components (notas D9)
    kill = false;
    r0.x = dot(lit_TEXCOORD5.xyz, lit_TEXCOORD5.xyz);                                     // 50  dp3 r0.x, v6.xyzx, v6.xyzx
    r0.x = d3d_rsq(r0.x);                                                                 // 51  rsq r0.x, r0.x
    r0.yzw = r0.xxx * lit_TEXCOORD5.xyz;                                                  // 52  mul r0.yzw, r0.xxxx, v6.xxyz
    r1.xy = texture(t0, lit_TEXCOORD0.xy).yw;                                             // 53  sample_indexable(texture2d)(float,float,float,float) r1.xy, v1.xyxx, t0.ywxz, s0
    r1.zw = texture(t1, lit_TEXCOORD0.xy).xy;                                             // 54  sample_indexable(texture2d)(float,float,float,float) r1.zw, v1.xyxx, t1.zwxy, s1
    r2.xy = r1.zw * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 55  mad r2.xy, r1.zwzz, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r1.z = dot(r2.xy, r2.xy);                                                             // 56  dp2 r1.z, r2.xyxx, r2.xyxx
    r1.z = d3d_min(r1.z, 1.0);                                                            // 57  min r1.z, r1.z, l(1.000000)
    r1.z = -r1.z + 1.0;                                                                   // 58  add r1.z, -r1.z, l(1.000000)
    r2.z = d3d_sqrt(r1.z);                                                                // 59  sqrt r2.z, r1.z
    r1.z = d3d_log2(lit_COLOR0.x);                                                        // 60  log r1.z, v7.x
    r1.z = r1.z * FO4_L_0_454545;                                                         // 61  mul r1.z, r1.z, l(0.454545)
    r1.z = d3d_exp2(r1.z);                                                                // 62  exp r1.z, r1.z
    r1.x = d3d_log2(r1.x);                                                                // 63  log r1.x, r1.x
    r1.x = r1.x * FO4_L_0_454545;                                                         // 64  mul r1.x, r1.x, l(0.454545)
    r3.x = d3d_exp2(r1.x);                                                                // 65  exp r3.x, r1.x
    r1.x = -r1.z + 1.0;                                                                   // 66  add r1.x, -r1.z, l(1.000000)
    r3.y = -r1.x + TintColor.x;                                                           // 67  add r3.y, -r1.x, cb1[1].x
    r1.xzw = textureLod(t15, r3.xy, 0.0).xyz;                                             // 68  sample_l_indexable(texture2d)(float,float,float,float) r1.xzw, r3.xyxx, t15.xwyz, s15, l(0.000000)
    r3.xy = texture(t2, lit_TEXCOORD0.xy).xy;                                             // 69  sample_indexable(texture2d)(float,float,float,float) r3.xy, v1.xyxx, t2.xyzw, s2
    r3.xz = r3.yx * SpecularParam.xy;                                                     // 70  mul r3.xz, r3.yyxy, cb2[11].xxyx
    r2.w = -r3.y * SpecularParam.x + 1.0;                                                 // 71  mad r2.w, -r3.y, cb2[11].x, l(1.000000)
    r2.w = r2.w * 2.0 + -1.0;                                                             // 72  mad r2.w, r2.w, l(2.000000), l(-1.000000)
    r2.w = r2.w * FO4_L_8_65591;                                                          // 73  mul r2.w, r2.w, l(8.655910)
    r2.w = d3d_exp2(r2.w);                                                                // 74  exp r2.w, r2.w
    r2.w = r2.w + 1.0;                                                                    // 75  add r2.w, r2.w, l(1.000000)
    r2.w = d3d_div(3.0, r2.w);                                                            // 76  div r2.w, l(3.000000), r2.w
    r2.w = -r2.w + 3.0;                                                                   // 77  add r2.w, -r2.w, l(3.000000)
    r3.y = r3.z * FO4_L_PI;                                                               // 78  mul r3.y, r3.z, l(3.141593)
    r3.x = r3.x * 10.0 + 1.0;                                                             // 79  mad r3.x, r3.x, l(10.000000), l(1.000000)
    r3.x = d3d_exp2(r3.x);                                                                // 80  exp r3.x, r3.x
    r4.x = dot(lit_TEXCOORD1.xyz, r2.xyz);                                                // 81  dp3 r4.x, v3.xyzx, r2.xyzx
    r4.y = dot(lit_TEXCOORD2.xyz, r2.xyz);                                                // 82  dp3 r4.y, v4.xyzx, r2.xyzx
    r4.z = dot(lit_TEXCOORD3.xyz, r2.xyz);                                                // 83  dp3 r4.z, v5.xyzx, r2.xyzx
    r2.x = dot(r4.xyz, r4.xyz);                                                           // 84  dp3 r2.x, r4.xyzx, r4.xyzx
    r2.x = d3d_rsq(r2.x);                                                                 // 85  rsq r2.x, r2.x
    r4.xyz = r2.xxx * r4.xyz;                                                             // 86  mul r4.xyz, r2.xxxx, r4.xyzx
    r4.w = (lit_SV_IsFrontFace0.x != 0) ? r4.y : -r4.y;                                   // 87  movc r4.w, v8.x, r4.y, -r4.y
    b2.x = (ShadowLightCounts.x == 1.0);                                                  // 88  eq r2.x, cb2[10].x, l(1.000000)
    if (b2.x) {                                                                           // 89  if_nz r2.x
        b2.x = (lit_TEXCOORD4.w < SplitDistances.w);                                      // 90  lt r2.x, v2.w, cb2[37].w
        if (b2.x) {                                                                       // 91  if_nz r2.x
            b2.xyz = lessThan(SplitDistances.zyx, lit_TEXCOORD4.www);                     // 92  lt r2.xyz, cb2[37].zyxz, v2.wwww
            r5.xyzw = mix(DirShadowMapProj[0].xyzw, DirShadowMapProj[3].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 93  movc r5.xyzw, r2.zzzz, cb2[28].xyzw, cb2[25].xyzw
            r6.xyzw = mix(DirShadowMapProj[1].xyzw, DirShadowMapProj[4].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 94  movc r6.xyzw, r2.zzzz, cb2[29].xyzw, cb2[26].xyzw
            r7.xyzw = mix(DirShadowMapProj[2].xyzw, DirShadowMapProj[5].xyzw, bvec4(b2.z, b2.z, b2.z, b2.z));// 95  movc r7.xyzw, r2.zzzz, cb2[30].xyzw, cb2[27].xyzw
            i2.z = ((b2.z ? -1 : 0) & 1065353216);                                        // 96  and r2.z, r2.z, l(0x3f800000)
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[6].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 97  movc r5.xyzw, r2.yyyy, cb2[31].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[7].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 98  movc r6.xyzw, r2.yyyy, cb2[32].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[8].xyzw, bvec4(b2.y, b2.y, b2.y, b2.y));// 99  movc r7.xyzw, r2.yyyy, cb2[33].xyzw, r7.xyzw
            i2.y = (b2.y ? 1073741824 : i2.z);                                            // 100  movc r2.y, r2.y, l(2.000000), r2.z
            r5.xyzw = mix(r5.xyzw, DirShadowMapProj[9].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 101  movc r5.xyzw, r2.xxxx, cb2[34].xyzw, r5.xyzw
            r6.xyzw = mix(r6.xyzw, DirShadowMapProj[10].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 102  movc r6.xyzw, r2.xxxx, cb2[35].xyzw, r6.xyzw
            r7.xyzw = mix(r7.xyzw, DirShadowMapProj[11].xyzw, bvec4(b2.x, b2.x, b2.x, b2.x));// 103  movc r7.xyzw, r2.xxxx, cb2[36].xyzw, r7.xyzw
            i2.z = (b2.x ? 1077936128 : i2.y);                                            // 104  movc r2.z, r2.x, l(3.000000), r2.y
            r8.xyz = lit_TEXCOORD4.xyz;                                                   // 105  mov r8.xyz, v2.xyzx
            r8.w = 1.0;                                                                   // 106  mov r8.w, l(1.000000)
            r2.x = dot(r5.xyzw, r8.xyzw);                                                 // 107  dp4 r2.x, r5.xyzw, r8.xyzw
            r2.y = dot(r6.xyzw, r8.xyzw);                                                 // 108  dp4 r2.y, r6.xyzw, r8.xyzw
            r3.z = dot(r7.xyzw, r8.xyzw);                                                 // 109  dp4 r3.z, r7.xyzw, r8.xyzw
            r2.x = texture(t14, vec3(r2.xy, d3d_layer(intBitsToFloat(i2.z), textureSize(t14, 0).z))).x;// 110  sample_indexable(texture2darray)(float,float,float,float) r2.x, r2.xyzx, t14.xyzw, s14
            b2.x = (r2.x >= r3.z);                                                        // 111  ge r2.x, r2.x, r3.z
            i2.x = ((b2.x ? -1 : 0) & 1065353216);                                        // 112  and r2.x, r2.x, l(0x3f800000)
        r2.x = intBitsToFloat(i2.x); r2.z = intBitsToFloat(i2.z); } else {                // 113  else
            r2.x = 1.0;                                                                   // 114  mov r2.x, l(1.000000)
        }                                                                                 // 115  endif
    } else {                                                                              // 116  else
        r2.x = 1.0;                                                                       // 117  mov r2.x, l(1.000000)
    }                                                                                     // 118  endif
    r2.y = -SpecularParam.x + 1.0;                                                        // 119  add r2.y, -cb2[11].x, l(1.000000)
    r2.z = dot(r0.ywz, r4.xzw);                                                           // 120  dp3 r2.z, r0.ywzy, r4.xzwx
    r3.z = dot(DirLightDirection.xzy, r4.xzw);                                            // 121  dp3 r3.z, cb2[0].xzyx, r4.xzwx
    r5.xyz = -r4.xwz * r2.zzz + r0.yzw;                                                   // 122  mad r5.xyz, -r4.xwzx, r2.zzzz, r0.yzwy
    r6.xyz = -r4.xwz * r3.zzz + DirLightDirection.xyz;                                    // 123  mad r6.xyz, -r4.xwzx, r3.zzzz, cb2[0].xyzx
    r3.w = dot(r5.xyz, r6.xyz);                                                           // 124  dp3 r3.w, r5.xyzx, r6.xyzx
    r4.y = r2.y * r2.y;                                                                   // 125  mul r4.y, r2.y, r2.y
    r6.xy = r2.yy * r2.yy + vec2(FO4_L_0_57, FO4_L_0_09);                                 // 126  mad r6.xy, r2.yyyy, r2.yyyy, l(0.570000, 0.090000, 0.000000, 0.000000)
    r6.xy = vec2(d3d_div(r4.y, r6.x), d3d_div(r4.y, r6.y));                               // 127  div r6.xy, r4.yyyy, r6.xyxx
    r2.y = r6.y * FO4_L_0_45;                                                             // 128  mul r2.y, r6.y, l(0.450000)
    r4.y = -r6.x * 0.5 + 1.0;                                                             // 129  mad r4.y, -r6.x, l(0.500000), l(1.000000)
    r5.w = -r2.z * r2.z + 1.0;                                                            // 130  mad r5.w, -r2.z, r2.z, l(1.000000)
    r6.x = -r3.z * r3.z + 1.0;                                                            // 131  mad r6.x, -r3.z, r3.z, l(1.000000)
    r6.x = d3d_sat(r5.w * r6.x);                                                          // 132  mul_sat r6.x, r5.w, r6.x
    r6.x = d3d_sqrt(r6.x);                                                                // 133  sqrt r6.x, r6.x
    r6.y = d3d_max(r2.z, r3.z);                                                           // 134  max r6.y, r2.z, r3.z
    r6.x = d3d_div(r6.x, r6.y);                                                           // 135  div r6.x, r6.x, r6.y
    r6.y = d3d_max(r3.z, 0.0);                                                            // 136  max r6.y, r3.z, l(0.000000)
    r3.w = d3d_max(r3.w, 0.0);                                                            // 137  max r3.w, r3.w, l(0.000000)
    r3.w = r2.y * r3.w;                                                                   // 138  mul r3.w, r2.y, r3.w
    r3.w = r3.w * r6.x + r4.y;                                                            // 139  mad r3.w, r3.w, r6.x, r4.y
    r3.w = r3.w * r6.y;                                                                   // 140  mul r3.w, r3.w, r6.y
    r6.xzw = r3.www * DirLightColor.xyz;                                                  // 141  mul r6.xzw, r3.wwww, cb2[1].xxyz
    r3.w = d3d_min(r6.y, 1.0);                                                            // 142  min r3.w, r6.y, l(1.000000)
    r6.y = d3d_sat(r2.z);                                                                 // 143  mov_sat r6.y, r2.z
    r7.x = -r6.y + 1.0;                                                                   // 144  add r7.x, -r6.y, l(1.000000)
    r7.x = d3d_log2(r7.x);                                                                // 145  log r7.x, r7.x
    r7.x = r7.x * FO4_L_0_01;                                                             // 146  mul r7.x, r7.x, l(0.010000)
    r7.x = d3d_exp2(r7.x);                                                                // 147  exp r7.x, r7.x
    r7.y = d3d_sat(dot(r0.yzw, -DirLightDirection.xyz));                                  // 148  dp3_sat r7.y, r0.yzwy, -cb2[0].xyzx
    r7.y = r7.y * r7.x;                                                                   // 149  mul r7.y, r7.y, r7.x
    r7.y = r3.w * r7.y;                                                                   // 150  mul r7.y, r3.w, r7.y
    r7.yzw = r7.yyy * DirLightColor.xyz;                                                  // 151  mul r7.yzw, r7.yyyy, cb2[1].xxyz
    r7.yzw = r2.www * r7.yzw;                                                             // 152  mul r7.yzw, r2.wwww, r7.yyzw
    r6.xzw = r6.xzw * r2.xxx + r7.yzw;                                                    // 153  mad r6.xzw, r6.xxzw, r2.xxxx, r7.yyzw
    r7.yzw = r1.xzw * LightingEffectParams.yyy;                                           // 154  mul r7.yzw, r1.xxzw, cb1[7].yyyy
    r8.x = d3d_sat(-r3.z);                                                                // 155  mov_sat r8.x, -r3.z
    r7.yzw = r7.yzw * r8.xxx;                                                             // 156  mul r7.yzw, r7.yyzw, r8.xxxx
    r6.xzw = DirLightColor.xyz * r7.yzw + r6.xzw;                                         // 157  mad r6.xzw, cb2[1].xxyz, r7.yyzw, r6.xxzw
    r3.z = r3.z + LightingEffectParams.x;                                                 // 158  add r3.z, r3.z, cb1[7].x
    r7.y = LightingEffectParams.x + 1.0;                                                  // 159  add r7.y, cb1[7].x, l(1.000000)
    r3.z = d3d_sat(d3d_div(r3.z, r7.y));                                                  // 160  div_sat r3.z, r3.z, r7.y
    r3.z = -r3.w + r3.z;                                                                  // 161  add r3.z, -r3.w, r3.z
    r3.z = d3d_max(r3.z, 0.0);                                                            // 162  max r3.z, r3.z, l(0.000000)
    r7.yzw = r3.zzz * DirLightColor.xyz;                                                  // 163  mul r7.yzw, r3.zzzz, cb2[1].xxyz
    r6.xzw = r7.yzw * r1.xzw + r6.xzw;                                                    // 164  mad r6.xzw, r7.yyzw, r1.xxzw, r6.xxzw
    r6.xzw = r2.xxx * r6.xzw;                                                             // 165  mul r6.xzw, r2.xxxx, r6.xxzw
    r7.yzw = lit_TEXCOORD5.xyz * r0.xxx + DirLightDirection.xyz;                          // 166  mad r7.yzw, v6.xxyz, r0.xxxx, cb2[0].xxyz
    r3.z = dot(r7.yzw, r7.yzw);                                                           // 167  dp3 r3.z, r7.yzwy, r7.yzwy
    r3.z = d3d_rsq(r3.z);                                                                 // 168  rsq r3.z, r3.z
    r7.yzw = r3.zzz * r7.yzw;                                                             // 169  mul r7.yzw, r3.zzzz, r7.yyzw
    r3.z = d3d_sat(dot(r0.yzw, r7.yzw));                                                  // 170  dp3_sat r3.z, r0.yzwy, r7.yzwy
    r7.y = d3d_sat(dot(r7.ywz, r4.xzw));                                                  // 171  dp3_sat r7.y, r7.ywzy, r4.xzwx
    r7.z = r3.x + 2.0;                                                                    // 172  add r7.z, r3.x, l(2.000000)
    r7.z = r7.z * FO4_L_INV_2PI;                                                          // 173  mul r7.z, r7.z, l(0.159155)
    r7.w = d3d_log2(r7.y);                                                                // 174  log r7.w, r7.y
    r7.w = r3.x * r7.w;                                                                   // 175  mul r7.w, r3.x, r7.w
    r7.w = d3d_exp2(r7.w);                                                                // 176  exp r7.w, r7.w
    r7.w = r7.w * r7.z;                                                                   // 177  mul r7.w, r7.w, r7.z
    r8.x = d3d_max(r3.z, FO4_L_2POW_M23);                                                 // 178  max r8.x, r3.z, l(0.000000)
    r8.y = d3d_min(r3.w, r6.y);                                                           // 179  min r8.y, r3.w, r6.y
    r7.y = r7.y + r7.y;                                                                   // 180  add r7.y, r7.y, r7.y
    r8.z = r7.y * r8.y;                                                                   // 181  mul r8.z, r7.y, r8.y
    b8.z = (r8.x >= r8.z);                                                                // 182  ge r8.z, r8.x, r8.z
    b8.y = (r6.y == r8.y);                                                                // 183  eq r8.y, r6.y, r8.y
    r8.w = d3d_div(r3.w, r6.y);                                                           // 184  div r8.w, r3.w, r6.y
    r8.y = b8.y ? 1.0 : r8.w;                                                             // 185  movc r8.y, r8.y, l(1.000000), r8.w
    r7.y = r7.y * r8.y;                                                                   // 186  mul r7.y, r7.y, r8.y
    r7.y = d3d_div(r7.y, r8.x);                                                           // 187  div r7.y, r7.y, r8.x
    r8.x = d3d_div(1.0, r6.y);                                                            // 188  div r8.x, l(1.000000, 1.000000, 1.000000, 1.000000), r6.y
    r7.y = b8.z ? r7.y : r8.x;                                                            // 189  movc r7.y, r8.z, r7.y, r8.x
    r3.z = -r3.z + 1.0;                                                                   // 190  add r3.z, -r3.z, l(1.000000)
    r8.y = r3.z * r3.z;                                                                   // 191  mul r8.y, r3.z, r3.z
    r8.y = r8.y * r8.y;                                                                   // 192  mul r8.y, r8.y, r8.y
    r8.z = r3.z * r8.y;                                                                   // 193  mul r8.z, r3.z, r8.y
    r3.z = -r3.z * r8.y + 1.0;                                                            // 194  mad r3.z, -r3.z, r8.y, l(1.000000)
    r3.z = r3.z * FO4_L_0_2 + r8.z;                                                       // 195  mad r3.z, r3.z, l(0.200000), r8.z
    r3.z = d3d_min(r3.z, 1.0);                                                            // 196  min r3.z, r3.z, l(1.000000)
    r3.z = r7.y * r3.z;                                                                   // 197  mul r3.z, r7.y, r3.z
    r3.z = r7.w * r3.z;                                                                   // 198  mul r3.z, r7.w, r3.z
    r3.z = r3.z * 0.25;                                                                   // 199  mul r3.z, r3.z, l(0.250000)
    r3.z = d3d_min(r3.z, 15.0);                                                           // 200  min r3.z, r3.z, l(15.000000)
    r3.z = r3.z * r3.y;                                                                   // 201  mul r3.z, r3.z, r3.y
    r8.yzw = r3.zzz * DirLightColor.xyz;                                                  // 202  mul r8.yzw, r3.zzzz, cb2[1].xxyz
    r8.yzw = r3.www * r8.yzw;                                                             // 203  mul r8.yzw, r3.wwww, r8.yyzw
    r8.yzw = r2.xxx * r8.yzw;                                                             // 204  mul r8.yzw, r2.xxxx, r8.yyzw
    r2.x = (PointLightColor[0].w - floor(PointLightColor[0].w));                          // 205  frc r2.x, cb2[19].w
    r2.x = -r2.x + PointLightColor[0].w;                                                  // 206  add r2.x, -r2.x, cb2[19].w
    r2.x = d3d_min(r2.x, 20.0);                                                           // 207  min r2.x, r2.x, l(20.000000)
    r2.x = d3d_max(r2.x, 0.0);                                                            // 208  max r2.x, r2.x, l(0.000000)
    b3.z = (0.0 < r2.x);                                                                  // 209  lt r3.z, l(0.000000), r2.x
    if (b3.z) {                                                                           // 210  if_nz r3.z
        r9.xyz = r6.xzw;                                                                  // 211  mov r9.xyz, r6.xzwx
        r10.xyz = r8.yzw;                                                                 // 212  mov r10.xyz, r8.yzwy
        i3.z = 0;                                                                         // 213  mov r3.z, l(0)
        for (;;) {                                                                        // 214  loop
            r3.w = float(i3.z);                                                           // 215  itof r3.w, r3.z
            b3.w = (r3.w >= r2.x);                                                        // 216  ge r3.w, r3.w, r2.x
            if (b3.w) break;                                                              // 217  breakc_nz r3.w
            r11.xyz = -lit_TEXCOORD4.xyz + fo4_cb2_row(i3.z + 13).xyz;                    // 218  add r11.xyz, -v2.xyzx, cb2[r3.z + 13].xyzx
            r3.w = dot(r11.xyz, r11.xyz);                                                 // 219  dp3 r3.w, r11.xyzx, r11.xyzx
            r7.y = d3d_sqrt(r3.w);                                                        // 220  sqrt r7.y, r3.w
            r7.y = d3d_sat(d3d_div(r7.y, fo4_cb2_row(i3.z + 13).w));                      // 221  div_sat r7.y, r7.y, cb2[r3.z + 13].w
            r7.y = -r7.y * r7.y + 1.0;                                                    // 222  mad r7.y, -r7.y, r7.y, l(1.000000)
            r7.y = d3d_log2(r7.y);                                                        // 223  log r7.y, r7.y
            r7.y = r7.y * FO4_L_2_2;                                                      // 224  mul r7.y, r7.y, l(2.200000)
            r7.y = d3d_exp2(r7.y);                                                        // 225  exp r7.y, r7.y
            r3.w = d3d_rsq(r3.w);                                                         // 226  rsq r3.w, r3.w
            r11.xyz = r3.www * r11.xyz;                                                   // 227  mul r11.xyz, r3.wwww, r11.xyzx
            r3.w = dot(r11.xzy, r4.xzw);                                                  // 228  dp3 r3.w, r11.xzyx, r4.xzwx
            r12.xyz = -r4.xwz * r3.www + r11.xyz;                                         // 229  mad r12.xyz, -r4.xwzx, r3.wwww, r11.xyzx
            r7.w = dot(r5.xyz, r12.xyz);                                                  // 230  dp3 r7.w, r5.xyzx, r12.xyzx
            r9.w = -r3.w * r3.w + 1.0;                                                    // 231  mad r9.w, -r3.w, r3.w, l(1.000000)
            r9.w = d3d_sat(r5.w * r9.w);                                                  // 232  mul_sat r9.w, r5.w, r9.w
            r9.w = d3d_sqrt(r9.w);                                                        // 233  sqrt r9.w, r9.w
            r10.w = d3d_max(r2.z, r3.w);                                                  // 234  max r10.w, r2.z, r3.w
            r9.w = d3d_div(r9.w, r10.w);                                                  // 235  div r9.w, r9.w, r10.w
            r3.w = d3d_max(r3.w, 0.0);                                                    // 236  max r3.w, r3.w, l(0.000000)
            r7.w = d3d_max(r7.w, 0.0);                                                    // 237  max r7.w, r7.w, l(0.000000)
            r7.w = r2.y * r7.w;                                                           // 238  mul r7.w, r2.y, r7.w
            r7.w = r7.w * r9.w + r4.y;                                                    // 239  mad r7.w, r7.w, r9.w, r4.y
            r7.w = r3.w * r7.w;                                                           // 240  mul r7.w, r3.w, r7.w
            r12.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 241  mul r12.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r7.w = r7.y * r7.y;                                                           // 242  mul r7.w, r7.y, r7.y
            r12.xyz = r7.www * r12.xyz + r9.xyz;                                          // 243  mad r12.xyz, r7.wwww, r12.xyzx, r9.xyzx
            r3.w = d3d_min(r3.w, 1.0);                                                    // 244  min r3.w, r3.w, l(1.000000)
            r7.w = d3d_sat(dot(r0.yzw, -r11.xyz));                                        // 245  dp3_sat r7.w, r0.yzwy, -r11.xyzx
            r7.w = r7.w * r7.x;                                                           // 246  mul r7.w, r7.w, r7.x
            r7.w = r3.w * r7.w;                                                           // 247  mul r7.w, r3.w, r7.w
            r13.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 248  mul r13.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r13.xyz = r2.www * r13.xyz;                                                   // 249  mul r13.xyz, r2.wwww, r13.xyzx
            r9.xyz = r13.xyz * r7.yyy + r12.xyz;                                          // 250  mad r9.xyz, r13.xyzx, r7.yyyy, r12.xyzx
            r11.xyz = lit_TEXCOORD5.xyz * r0.xxx + r11.xyz;                               // 251  mad r11.xyz, v6.xyzx, r0.xxxx, r11.xyzx
            r7.w = dot(r11.xyz, r11.xyz);                                                 // 252  dp3 r7.w, r11.xyzx, r11.xyzx
            r7.w = d3d_rsq(r7.w);                                                         // 253  rsq r7.w, r7.w
            r11.xyz = r7.www * r11.xyz;                                                   // 254  mul r11.xyz, r7.wwww, r11.xyzx
            r7.w = d3d_sat(dot(r0.yzw, r11.xyz));                                         // 255  dp3_sat r7.w, r0.yzwy, r11.xyzx
            r9.w = d3d_sat(dot(r11.xzy, r4.xzw));                                         // 256  dp3_sat r9.w, r11.xzyx, r4.xzwx
            r10.w = d3d_log2(r9.w);                                                       // 257  log r10.w, r9.w
            r10.w = r3.x * r10.w;                                                         // 258  mul r10.w, r3.x, r10.w
            r10.w = d3d_exp2(r10.w);                                                      // 259  exp r10.w, r10.w
            r10.w = r7.z * r10.w;                                                         // 260  mul r10.w, r7.z, r10.w
            r11.x = d3d_max(r7.w, FO4_L_2POW_M23);                                        // 261  max r11.x, r7.w, l(0.000000)
            r11.y = d3d_min(r3.w, r6.y);                                                  // 262  min r11.y, r3.w, r6.y
            r9.w = r9.w + r9.w;                                                           // 263  add r9.w, r9.w, r9.w
            r11.z = r9.w * r11.y;                                                         // 264  mul r11.z, r9.w, r11.y
            b11.z = (r11.x >= r11.z);                                                     // 265  ge r11.z, r11.x, r11.z
            b11.y = (r6.y == r11.y);                                                      // 266  eq r11.y, r6.y, r11.y
            r11.w = d3d_div(r3.w, r6.y);                                                  // 267  div r11.w, r3.w, r6.y
            r11.y = b11.y ? 1.0 : r11.w;                                                  // 268  movc r11.y, r11.y, l(1.000000), r11.w
            r9.w = r9.w * r11.y;                                                          // 269  mul r9.w, r9.w, r11.y
            r9.w = d3d_div(r9.w, r11.x);                                                  // 270  div r9.w, r9.w, r11.x
            r9.w = b11.z ? r9.w : r8.x;                                                   // 271  movc r9.w, r11.z, r9.w, r8.x
            r7.w = -r7.w + 1.0;                                                           // 272  add r7.w, -r7.w, l(1.000000)
            r11.x = r7.w * r7.w;                                                          // 273  mul r11.x, r7.w, r7.w
            r11.x = r11.x * r11.x;                                                        // 274  mul r11.x, r11.x, r11.x
            r11.y = r7.w * r11.x;                                                         // 275  mul r11.y, r7.w, r11.x
            r7.w = -r7.w * r11.x + 1.0;                                                   // 276  mad r7.w, -r7.w, r11.x, l(1.000000)
            r7.w = r7.w * FO4_L_0_2 + r11.y;                                              // 277  mad r7.w, r7.w, l(0.200000), r11.y
            r7.w = d3d_min(r7.w, 1.0);                                                    // 278  min r7.w, r7.w, l(1.000000)
            r7.w = r9.w * r7.w;                                                           // 279  mul r7.w, r9.w, r7.w
            r7.w = r10.w * r7.w;                                                          // 280  mul r7.w, r10.w, r7.w
            r7.w = r7.w * 0.25;                                                           // 281  mul r7.w, r7.w, l(0.250000)
            r7.w = d3d_min(r7.w, 15.0);                                                   // 282  min r7.w, r7.w, l(15.000000)
            r7.w = r3.y * r7.w;                                                           // 283  mul r7.w, r3.y, r7.w
            r11.xyz = r7.www * fo4_cb2_row(i3.z + 19).xyz;                                // 284  mul r11.xyz, r7.wwww, cb2[r3.z + 19].xyzx
            r11.xyz = r3.www * r11.xyz;                                                   // 285  mul r11.xyz, r3.wwww, r11.xyzx
            r10.xyz = r7.yyy * r11.xyz;                                                   // 286  mul r10.xyz, r7.yyyy, r11.xyzx
            i3.z = (i3.z + 1);                                                            // 287  iadd r3.z, r3.z, l(1)
        }                                                                                 // 288  endloop
        r6.xzw = r9.xyz;                                                                  // 289  mov r6.xzw, r9.xxyz
        r8.yzw = r10.xyz;                                                                 // 290  mov r8.yzw, r10.xxyz
    } else { i3.z = (b3.z ? -1 : 0); }                                                    // 291  endif
    r0.xyz = r6.xzw + EmitColor.xyz;                                                      // 292  add r0.xyz, r6.xzwx, cb2[3].yzwy
    o0.xyz = r0.xyz * r1.xzw + r8.yzw;                                                    // 293  mad o0.xyz, r0.xyzx, r1.xzwx, r8.yzwy
    r0.x = r1.y * lit_COLOR0.w + -AlphaTestRef.x;                                         // 294  mad r0.x, r1.y, v7.w, -cb2[3].x
    b0.x = (r0.x < 0.0);                                                                  // 295  lt r0.x, r0.x, l(0.000000)
    kill = kill || b0.x;                                                                  // 296  discard_nz r0.x
    o0.w = MaterialData.z;                                                                // 297  mov o0.w, cb2[2].z
    return;                                                                               // 298  ret
}
void engine_main(out vec4 o0, out bool kill)
{
    Fo4LitPs_rec1514(o0, kill);
}
//#### END Fo4LitPs_rec1514 ####
//#### BEGIN Fo4LitVs_rec1480 ####
// class of identical transcribed code: rec1480 t00000000, rec1496 t00000200, rec1482 t00000400, rec1484 t00000500, rec1486 t00000600
// VS inputs: vertex attributes at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 WorldViewProj[4];               // name 0, cb2, writer SG 0x14223B679..684
#ifdef ENGINE_MOTION_VECTORS
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
#endif
// b06_BSLighting_VS_rec1480_t00000000  technique 0x00000000 = 
// constants by name (fxp offset table of rec1480, loader 0x14181E030, obj+0x68; names 0x142243A40): WorldViewProj = cb2[0].x
void Fo4LitVs_rec1480(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0, r1;
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
    r0.xyz = vs_POSITION0.xyz;                                                            // 45  mov r0.xyz, v0.xyzx
    r0.w = 1.0;                                                                           // 46  mov r0.w, l(1.000000)
    r1.x = dot(WorldViewProj[2].xyzw, r0.xyzw);                                           // 47  dp4 r1.x, cb2[2].xyzw, r0.xyzw
    o0.z = r1.x;                                                                          // 48  mov o0.z, r1.x
#ifdef ENGINE_MOTION_VECTORS
    o2.w = r1.x;                                                                          // 49  mov o2.w, r1.x
#endif
    o0.x = dot(WorldViewProj[0].xyzw, r0.xyzw);                                           // 50  dp4 o0.x, cb2[0].xyzw, r0.xyzw
    o0.y = dot(WorldViewProj[1].xyzw, r0.xyzw);                                           // 51  dp4 o0.y, cb2[1].xyzw, r0.xyzw
    o0.w = dot(WorldViewProj[3].xyzw, r0.xyzw);                                           // 52  dp4 o0.w, cb2[3].xyzw, r0.xyzw
#ifdef ENGINE_MOTION_VECTORS
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 53  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    o2.xyz = vs_POSITION0.xyz;                                                            // 54  mov o2.xyz, v0.xyzx
    o3.x = vs_POSITION0.w;                                                                // 55  mov o3.x, v0.w
    o3.y = vs_BINORMAL0.x * 2.0 + -1.0;                                                   // 56  mad o3.y, v3.x, l(2.000000), l(-1.000000)
    o3.z = vs_NORMAL0.x * 2.0 + -1.0;                                                     // 57  mad o3.z, v2.x, l(2.000000), l(-1.000000)
    o4.xz = vs_NORMAL0.wy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                            // 58  mad o4.xz, v2.wwyw, l(2.000000, 0.000000, 2.000000, 0.000000), l(-1.000000, 0.000000, -1.000000, 0.000000)
    o4.y = vs_BINORMAL0.y * 2.0 + -1.0;                                                   // 59  mad o4.y, v3.y, l(2.000000), l(-1.000000)
    o5.xy = vs_BINORMAL0.wz * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                          // 60  mad o5.xy, v3.wzww, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    o5.z = vs_NORMAL0.z * 2.0 + -1.0;                                                     // 61  mad o5.z, v2.z, l(2.000000), l(-1.000000)
    o6.xyz = -vs_POSITION0.xyz + EyePosition.xyz;                                         // 62  add o6.xyz, -v0.xyzx, cb2[7].xyzx
    o7.xyzw = vec4(1.0, 1.0, 1.0, 1.0);                                                   // 63  mov o7.xyzw, l(1.000000,1.000000,1.000000,1.000000)
#endif
    return;                                                                               // 64  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVs_rec1480(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVs_rec1480 ####
//#### BEGIN Fo4LitVs_rec1481 ####
// class of identical transcribed code: rec1481 t00000001, rec1497 t00000201, rec1483 t00000401, rec1485 t00000501, rec1487 t00000601
// VS inputs: vertex attributes at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
layout(location = 5) in vec4 vs_COLOR0;
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
uniform vec4 WorldViewProj[4];               // name 0, cb2, writer SG 0x14223B679..684
// b06_BSLighting_VS_rec1481_t00000001  technique 0x00000001 = VC
// constants by name (fxp offset table of rec1481, loader 0x14181E030, obj+0x68; names 0x142243A40): WorldViewProj = cb2[0].x, EyePosition = cb2[7].x, TexcoordOffset = cb1[2].x
void Fo4LitVs_rec1481(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0, r1;
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
    r0.xyz = vs_POSITION0.xyz;                                                            // 47  mov r0.xyz, v0.xyzx
    r0.w = 1.0;                                                                           // 48  mov r0.w, l(1.000000)
    r1.x = dot(WorldViewProj[2].xyzw, r0.xyzw);                                           // 49  dp4 r1.x, cb2[2].xyzw, r0.xyzw
    o0.z = r1.x;                                                                          // 50  mov o0.z, r1.x
    o2.w = r1.x;                                                                          // 51  mov o2.w, r1.x
    o0.x = dot(WorldViewProj[0].xyzw, r0.xyzw);                                           // 52  dp4 o0.x, cb2[0].xyzw, r0.xyzw
    o0.y = dot(WorldViewProj[1].xyzw, r0.xyzw);                                           // 53  dp4 o0.y, cb2[1].xyzw, r0.xyzw
    o0.w = dot(WorldViewProj[3].xyzw, r0.xyzw);                                           // 54  dp4 o0.w, cb2[3].xyzw, r0.xyzw
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 55  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    o2.xyz = vs_POSITION0.xyz;                                                            // 56  mov o2.xyz, v0.xyzx
    o3.x = vs_POSITION0.w;                                                                // 57  mov o3.x, v0.w
    o3.y = vs_BINORMAL0.x * 2.0 + -1.0;                                                   // 58  mad o3.y, v3.x, l(2.000000), l(-1.000000)
    o3.z = vs_NORMAL0.x * 2.0 + -1.0;                                                     // 59  mad o3.z, v2.x, l(2.000000), l(-1.000000)
    o4.xz = vs_NORMAL0.wy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                            // 60  mad o4.xz, v2.wwyw, l(2.000000, 0.000000, 2.000000, 0.000000), l(-1.000000, 0.000000, -1.000000, 0.000000)
    o4.y = vs_BINORMAL0.y * 2.0 + -1.0;                                                   // 61  mad o4.y, v3.y, l(2.000000), l(-1.000000)
    o5.xy = vs_BINORMAL0.wz * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                          // 62  mad o5.xy, v3.wzww, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    o5.z = vs_NORMAL0.z * 2.0 + -1.0;                                                     // 63  mad o5.z, v2.z, l(2.000000), l(-1.000000)
    o6.xyz = -vs_POSITION0.xyz + EyePosition.xyz;                                         // 64  add o6.xyz, -v0.xyzx, cb2[7].xyzx
    r0.xyz = vec3(d3d_log2(vs_COLOR0.x), d3d_log2(vs_COLOR0.y), d3d_log2(vs_COLOR0.z));   // 65  log r0.xyz, v4.xyzx
    r0.xyz = r0.xyz * vec3(FO4_L_2_2);                                                    // 66  mul r0.xyz, r0.xyzx, l(2.200000, 2.200000, 2.200000, 0.000000)
    o7.xyz = vec3(d3d_exp2(r0.x), d3d_exp2(r0.y), d3d_exp2(r0.z));                        // 67  exp o7.xyz, r0.xyzx
    o7.w = vs_COLOR0.w;                                                                   // 68  mov o7.w, v4.w
    return;                                                                               // 69  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVs_rec1481(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVs_rec1481 ####
//#### BEGIN Fo4LitVs_rec1488 ####
// class of identical transcribed code: rec1488 t00000002, rec1491 t00000102
// VS inputs: vertex attributes at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
layout(location = 6) in vec4 vs_BLENDWEIGHT0;
layout(location = 7) in vec4 vs_BLENDINDICES0;
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 cb12_viewproj[4];      // cb12 rows 8..11: view-projection rows (0x14181E368..3D5)
uniform vec4 cb12_35;               // cb12 row 35: eye (0x14181E70B..729)
#ifdef ENGINE_MOTION_VECTORS
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
#endif
// b06_BSLighting_VS_rec1488_t00000002  technique 0x00000002 = SKINNED
// constants by name (fxp offset table of rec1488, loader 0x14181E030, obj+0x68; names 0x142243A40): 
void Fo4LitVs_rec1488(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9;
    ivec4 i2, i3, i5;
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
    r0.x = vs_BLENDWEIGHT0.y + vs_BLENDWEIGHT0.x;                                         // 51  add r0.x, v4.y, v4.x
    r0.x = d3d_sat(r0.x + vs_BLENDWEIGHT0.z);                                             // 52  add_sat r0.x, r0.x, v4.z
    r0.x = -r0.x + 1.0;                                                                   // 53  add r0.x, -r0.x, l(1.000000)
    r1.xyz = vec3(-0.0, -0.0, -0.0);                                                      // 54  mov r1.xyz, l(-0.000000,-0.000000,-0.000000,0)
    r1.w = -cb12_35.z;                                                                    // 55  mov r1.w, -cb12[35].z
    r2.xyzw = vs_BLENDINDICES0.xyzw * vec4(FO4_L_765_01001);                              // 56  mul r2.xyzw, v5.xyzw, l(765.010010, 765.010010, 765.010010, 765.010010)
    i2.xyzw = ivec4(d3d_ftoi(r2.x), d3d_ftoi(r2.y), d3d_ftoi(r2.z), d3d_ftoi(r2.w));      // 57  ftoi r2.xyzw, r2.xyzw
    i3.xyzw = ivec4((i2.x + 1), (i2.x + 2), (i2.y + 1), (i2.y + 2));                      // 58  iadd r3.xyzw, r2.xxyy, l(1, 2, 1, 2)
    r4.xyzw = r1.zzzw + d3d_cb10(i3.w + 0).xyzw;                                          // 59  add r4.xyzw, r1.zzzw, cb10[r3.w + 0].xyzw
    r4.xyzw = r4.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 60  mul r4.xyzw, r4.xyzw, v4.yyyy
    r5.xyzw = r1.zzzw + d3d_cb10(i3.y + 0).xyzw;                                          // 61  add r5.xyzw, r1.zzzw, cb10[r3.y + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.xxxx * r5.xyzw + r4.xyzw;                                   // 62  mad r4.xyzw, v4.xxxx, r5.xyzw, r4.xyzw
    i5.xyzw = ivec4((i2.z + 1), (i2.z + 2), (i2.w + 1), (i2.w + 2));                      // 63  iadd r5.xyzw, r2.zzww, l(1, 2, 1, 2)
    r6.xyzw = r1.zzzw + d3d_cb10(i5.y + 0).xyzw;                                          // 64  add r6.xyzw, r1.zzzw, cb10[r5.y + 0].xyzw
    r1.xyzw = r1.xyzw + d3d_cb10(i5.w + 0).xyzw;                                          // 65  add r1.xyzw, r1.xyzw, cb10[r5.w + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.zzzz * r6.xyzw + r4.xyzw;                                   // 66  mad r4.xyzw, v4.zzzz, r6.xyzw, r4.xyzw
    r1.xyzw = r0.xxxx * r1.xyzw + r4.xyzw;                                                // 67  mad r1.xyzw, r0.xxxx, r1.xyzw, r4.xyzw
    r4.xyz = vs_POSITION0.xyz;                                                            // 68  mov r4.xyz, v0.xyzx
    r4.w = 1.0;                                                                           // 69  mov r4.w, l(1.000000)
    r6.z = dot(r4.xyzw, r1.xyzw);                                                         // 70  dp4 r6.z, r4.xyzw, r1.xyzw
    r7.xz = vec2(-0.0, -0.0);                                                             // 71  mov r7.xz, l(-0.000000,0,-0.000000,0)
    r7.yw = -cb12_35.xy;                                                                  // 72  mov r7.yw, -cb12[35].xxxy
    r8.xyzw = r7.xxxy + d3d_cb10(i2.y + 0).xyzw;                                          // 73  add r8.xyzw, r7.xxxy, cb10[r2.y + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 74  mul r8.xyzw, r8.xyzw, v4.yyyy
    r9.xyzw = r7.xxxy + d3d_cb10(i2.x + 0).xyzw;                                          // 75  add r9.xyzw, r7.xxxy, cb10[r2.x + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.xxxx * r9.xyzw + r8.xyzw;                                   // 76  mad r8.xyzw, v4.xxxx, r9.xyzw, r8.xyzw
    r9.xyzw = r7.xxxy + d3d_cb10(i2.z + 0).xyzw;                                          // 77  add r9.xyzw, r7.xxxy, cb10[r2.z + 0].xyzw
    r2.xyzw = r7.xxxy + d3d_cb10(i2.w + 0).xyzw;                                          // 78  add r2.xyzw, r7.xxxy, cb10[r2.w + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.zzzz * r9.xyzw + r8.xyzw;                                   // 79  mad r8.xyzw, v4.zzzz, r9.xyzw, r8.xyzw
    r2.xyzw = r0.xxxx * r2.xyzw + r8.xyzw;                                                // 80  mad r2.xyzw, r0.xxxx, r2.xyzw, r8.xyzw
    r6.x = dot(r4.xyzw, r2.xyzw);                                                         // 81  dp4 r6.x, r4.xyzw, r2.xyzw
    r8.xyzw = r7.zzzw + d3d_cb10(i3.z + 0).xyzw;                                          // 82  add r8.xyzw, r7.zzzw, cb10[r3.z + 0].xyzw
    r3.xyzw = r7.zzzw + d3d_cb10(i3.x + 0).xyzw;                                          // 83  add r3.xyzw, r7.zzzw, cb10[r3.x + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 84  mul r8.xyzw, r8.xyzw, v4.yyyy
    r3.xyzw = vs_BLENDWEIGHT0.xxxx * r3.xyzw + r8.xyzw;                                   // 85  mad r3.xyzw, v4.xxxx, r3.xyzw, r8.xyzw
    r8.xyzw = r7.zzzw + d3d_cb10(i5.x + 0).xyzw;                                          // 86  add r8.xyzw, r7.zzzw, cb10[r5.x + 0].xyzw
    r5.xyzw = r7.zzzw + d3d_cb10(i5.z + 0).xyzw;                                          // 87  add r5.xyzw, r7.zzzw, cb10[r5.z + 0].xyzw
    r3.xyzw = vs_BLENDWEIGHT0.zzzz * r8.xyzw + r3.xyzw;                                   // 88  mad r3.xyzw, v4.zzzz, r8.xyzw, r3.xyzw
    r0.xyzw = r0.xxxx * r5.xyzw + r3.xyzw;                                                // 89  mad r0.xyzw, r0.xxxx, r5.xyzw, r3.xyzw
    r6.y = dot(r4.xyzw, r0.xyzw);                                                         // 90  dp4 r6.y, r4.xyzw, r0.xyzw
    r6.w = 1.0;                                                                           // 91  mov r6.w, l(1.000000)
    o0.x = dot(cb12_viewproj[0].xyzw, r6.xyzw);                                           // 92  dp4 o0.x, cb12[8].xyzw, r6.xyzw
    o0.y = dot(cb12_viewproj[1].xyzw, r6.xyzw);                                           // 93  dp4 o0.y, cb12[9].xyzw, r6.xyzw
    o0.w = dot(cb12_viewproj[3].xyzw, r6.xyzw);                                           // 94  dp4 o0.w, cb12[11].xyzw, r6.xyzw
    r0.w = dot(cb12_viewproj[2].xyzw, r6.xyzw);                                           // 95  dp4 r0.w, cb12[10].xyzw, r6.xyzw
    o0.z = r0.w;                                                                          // 96  mov o0.z, r0.w
#ifdef ENGINE_MOTION_VECTORS
    o2.w = r0.w;                                                                          // 97  mov o2.w, r0.w
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 98  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    o2.xyz = r6.xyz;                                                                      // 99  mov o2.xyz, r6.xyzx
    o6.xyz = -r6.xyz + EyePosition.xyz;                                                   // 100  add o6.xyz, -r6.xyzx, cb2[3].xyzx
    r3.x = vs_POSITION0.w;                                                                // 101  mov r3.x, v0.w
    r3.y = vs_NORMAL0.w * 2.0 + -1.0;                                                     // 102  mad r3.y, v2.w, l(2.000000), l(-1.000000)
    r3.z = vs_BINORMAL0.w * 2.0 + -1.0;                                                   // 103  mad r3.z, v3.w, l(2.000000), l(-1.000000)
    r4.y = dot(r3.xyz, r0.xyz);                                                           // 104  dp3 r4.y, r3.xyzx, r0.xyzx
    r4.z = dot(r3.xyz, r1.xyz);                                                           // 105  dp3 r4.z, r3.xyzx, r1.xyzx
    r4.x = dot(r3.xyz, r2.xyz);                                                           // 106  dp3 r4.x, r3.xyzx, r2.xyzx
    r0.w = dot(r4.xyz, r4.xyz);                                                           // 107  dp3 r0.w, r4.xyzx, r4.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 108  rsq r0.w, r0.w
    r3.xyz = r0.www * r4.xyz;                                                             // 109  mul r3.xyz, r0.wwww, r4.xyzx
    o3.x = r3.x;                                                                          // 110  mov o3.x, r3.x
    r4.xyz = vs_BINORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);             // 111  mad r4.xyz, v3.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    r5.y = dot(r4.xyz, r0.xyz);                                                           // 112  dp3 r5.y, r4.xyzx, r0.xyzx
    r5.z = dot(r4.xyz, r1.xyz);                                                           // 113  dp3 r5.z, r4.xyzx, r1.xyzx
    r5.x = dot(r4.xyz, r2.xyz);                                                           // 114  dp3 r5.x, r4.xyzx, r2.xyzx
    r0.w = dot(r5.xyz, r5.xyz);                                                           // 115  dp3 r0.w, r5.xyzx, r5.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 116  rsq r0.w, r0.w
    r4.xyz = r0.www * r5.xyz;                                                             // 117  mul r4.xyz, r0.wwww, r5.xyzx
    o3.y = r4.x;                                                                          // 118  mov o3.y, r4.x
    r5.xyz = vs_NORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);               // 119  mad r5.xyz, v2.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    r0.y = dot(r5.xyz, r0.xyz);                                                           // 120  dp3 r0.y, r5.xyzx, r0.xyzx
    r0.z = dot(r5.xyz, r1.xyz);                                                           // 121  dp3 r0.z, r5.xyzx, r1.xyzx
    r0.x = dot(r5.xyz, r2.xyz);                                                           // 122  dp3 r0.x, r5.xyzx, r2.xyzx
    r0.w = dot(r0.xyz, r0.xyz);                                                           // 123  dp3 r0.w, r0.xyzx, r0.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 124  rsq r0.w, r0.w
    r0.xyz = r0.www * r0.xyz;                                                             // 125  mul r0.xyz, r0.wwww, r0.xyzx
    o3.z = r0.x;                                                                          // 126  mov o3.z, r0.x
    o4.x = r3.y;                                                                          // 127  mov o4.x, r3.y
    o5.x = r3.z;                                                                          // 128  mov o5.x, r3.z
    o4.y = r4.y;                                                                          // 129  mov o4.y, r4.y
    o5.y = r4.z;                                                                          // 130  mov o5.y, r4.z
    o4.z = r0.y;                                                                          // 131  mov o4.z, r0.y
    o5.z = r0.z;                                                                          // 132  mov o5.z, r0.z
    o7.xyzw = vec4(1.0, 1.0, 1.0, 1.0);                                                   // 133  mov o7.xyzw, l(1.000000,1.000000,1.000000,1.000000)
#endif
    return;                                                                               // 134  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVs_rec1488(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVs_rec1488 ####
//#### BEGIN Fo4LitVs_rec1489 ####
// class of identical transcribed code: rec1489 t00000100
// VS inputs: vertex attributes at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 WorldViewProj[4];               // name 0, cb2, writer SG 0x14223B679..684
#ifdef ENGINE_MOTION_VECTORS
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
uniform vec4 World[4];                       // name 1, cb2, writer SG>0x14223C2E0 0x14223C394..3AA (the buffer of SG, 0x14223B332 / 0x14223B45D)
#endif
// b06_BSLighting_VS_rec1489_t00000100  technique 0x00000100 = ENVMAP
// constants by name (fxp offset table of rec1489, loader 0x14181E030, obj+0x68; names 0x142243A40): WorldViewProj = cb2[0].x
void Fo4LitVs_rec1489(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0, r1;
#ifdef ENGINE_MOTION_VECTORS
    vec4 r2;
#endif
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
    r0.xyz = vs_POSITION0.xyz;                                                            // 45  mov r0.xyz, v0.xyzx
    r0.w = 1.0;                                                                           // 46  mov r0.w, l(1.000000)
    r1.x = dot(WorldViewProj[2].xyzw, r0.xyzw);                                           // 47  dp4 r1.x, cb2[2].xyzw, r0.xyzw
    o0.z = r1.x;                                                                          // 48  mov o0.z, r1.x
#ifdef ENGINE_MOTION_VECTORS
    o2.w = r1.x;                                                                          // 49  mov o2.w, r1.x
#endif
    o0.x = dot(WorldViewProj[0].xyzw, r0.xyzw);                                           // 50  dp4 o0.x, cb2[0].xyzw, r0.xyzw
    o0.y = dot(WorldViewProj[1].xyzw, r0.xyzw);                                           // 51  dp4 o0.y, cb2[1].xyzw, r0.xyzw
    o0.w = dot(WorldViewProj[3].xyzw, r0.xyzw);                                           // 52  dp4 o0.w, cb2[3].xyzw, r0.xyzw
#ifdef ENGINE_MOTION_VECTORS
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 53  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    r1.x = dot(World[0].xyzw, r0.xyzw);                                                   // 54  dp4 r1.x, cb2[4].xyzw, r0.xyzw
    r1.y = dot(World[1].xyzw, r0.xyzw);                                                   // 55  dp4 r1.y, cb2[5].xyzw, r0.xyzw
    r1.z = dot(World[2].xyzw, r0.xyzw);                                                   // 56  dp4 r1.z, cb2[6].xyzw, r0.xyzw
    o2.xyz = r1.xyz;                                                                      // 57  mov o2.xyz, r1.xyzx
    o6.xyz = -r1.xyz + EyePosition.xyz;                                                   // 58  add o6.xyz, -r1.xyzx, cb2[7].xyzx
    r0.xyz = vs_BINORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);             // 59  mad r0.xyz, v3.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    o3.y = dot(r0.xyz, World[0].xyz);                                                     // 60  dp3 o3.y, r0.xyzx, cb2[4].xyzx
    r1.xyz = vs_NORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);               // 61  mad r1.xyz, v2.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    o3.z = dot(r1.xyz, World[0].xyz);                                                     // 62  dp3 o3.z, r1.xyzx, cb2[4].xyzx
    r2.x = vs_POSITION0.w;                                                                // 63  mov r2.x, v0.w
    r2.y = vs_NORMAL0.w * 2.0 + -1.0;                                                     // 64  mad r2.y, v2.w, l(2.000000), l(-1.000000)
    r2.z = vs_BINORMAL0.w * 2.0 + -1.0;                                                   // 65  mad r2.z, v3.w, l(2.000000), l(-1.000000)
    o3.x = dot(r2.xyz, World[0].xyz);                                                     // 66  dp3 o3.x, r2.xyzx, cb2[4].xyzx
    o4.x = dot(r2.xyz, World[1].xyz);                                                     // 67  dp3 o4.x, r2.xyzx, cb2[5].xyzx
    o5.x = dot(r2.xyz, World[2].xyz);                                                     // 68  dp3 o5.x, r2.xyzx, cb2[6].xyzx
    o4.y = dot(r0.xyz, World[1].xyz);                                                     // 69  dp3 o4.y, r0.xyzx, cb2[5].xyzx
    o5.y = dot(r0.xyz, World[2].xyz);                                                     // 70  dp3 o5.y, r0.xyzx, cb2[6].xyzx
    o4.z = dot(r1.xyz, World[1].xyz);                                                     // 71  dp3 o4.z, r1.xyzx, cb2[5].xyzx
    o5.z = dot(r1.xyz, World[2].xyz);                                                     // 72  dp3 o5.z, r1.xyzx, cb2[6].xyzx
    o7.xyzw = vec4(1.0, 1.0, 1.0, 1.0);                                                   // 73  mov o7.xyzw, l(1.000000,1.000000,1.000000,1.000000)
#endif
    return;                                                                               // 74  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVs_rec1489(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVs_rec1489 ####
//#### BEGIN Fo4LitVs_rec1490 ####
// class of identical transcribed code: rec1490 t00000101
// VS inputs: vertex attributes at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
layout(location = 5) in vec4 vs_COLOR0;
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
uniform vec4 World[4];                       // name 1, cb2, writer SG>0x14223C2E0 0x14223C394..3AA (the buffer of SG, 0x14223B332 / 0x14223B45D)
uniform vec4 WorldViewProj[4];               // name 0, cb2, writer SG 0x14223B679..684
// b06_BSLighting_VS_rec1490_t00000101  technique 0x00000101 = VC|ENVMAP
// constants by name (fxp offset table of rec1490, loader 0x14181E030, obj+0x68; names 0x142243A40): WorldViewProj = cb2[0].x, World = cb2[4].x, EyePosition = cb2[7].x, TexcoordOffset = cb1[2].x
void Fo4LitVs_rec1490(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0, r1, r2;
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
    r0.xyz = vs_POSITION0.xyz;                                                            // 47  mov r0.xyz, v0.xyzx
    r0.w = 1.0;                                                                           // 48  mov r0.w, l(1.000000)
    r1.x = dot(WorldViewProj[2].xyzw, r0.xyzw);                                           // 49  dp4 r1.x, cb2[2].xyzw, r0.xyzw
    o0.z = r1.x;                                                                          // 50  mov o0.z, r1.x
    o2.w = r1.x;                                                                          // 51  mov o2.w, r1.x
    o0.x = dot(WorldViewProj[0].xyzw, r0.xyzw);                                           // 52  dp4 o0.x, cb2[0].xyzw, r0.xyzw
    o0.y = dot(WorldViewProj[1].xyzw, r0.xyzw);                                           // 53  dp4 o0.y, cb2[1].xyzw, r0.xyzw
    o0.w = dot(WorldViewProj[3].xyzw, r0.xyzw);                                           // 54  dp4 o0.w, cb2[3].xyzw, r0.xyzw
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 55  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    r1.x = dot(World[0].xyzw, r0.xyzw);                                                   // 56  dp4 r1.x, cb2[4].xyzw, r0.xyzw
    r1.y = dot(World[1].xyzw, r0.xyzw);                                                   // 57  dp4 r1.y, cb2[5].xyzw, r0.xyzw
    r1.z = dot(World[2].xyzw, r0.xyzw);                                                   // 58  dp4 r1.z, cb2[6].xyzw, r0.xyzw
    o2.xyz = r1.xyz;                                                                      // 59  mov o2.xyz, r1.xyzx
    o6.xyz = -r1.xyz + EyePosition.xyz;                                                   // 60  add o6.xyz, -r1.xyzx, cb2[7].xyzx
    r0.xyz = vs_BINORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);             // 61  mad r0.xyz, v3.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    o3.y = dot(r0.xyz, World[0].xyz);                                                     // 62  dp3 o3.y, r0.xyzx, cb2[4].xyzx
    r1.xyz = vs_NORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);               // 63  mad r1.xyz, v2.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    o3.z = dot(r1.xyz, World[0].xyz);                                                     // 64  dp3 o3.z, r1.xyzx, cb2[4].xyzx
    r2.x = vs_POSITION0.w;                                                                // 65  mov r2.x, v0.w
    r2.y = vs_NORMAL0.w * 2.0 + -1.0;                                                     // 66  mad r2.y, v2.w, l(2.000000), l(-1.000000)
    r2.z = vs_BINORMAL0.w * 2.0 + -1.0;                                                   // 67  mad r2.z, v3.w, l(2.000000), l(-1.000000)
    o3.x = dot(r2.xyz, World[0].xyz);                                                     // 68  dp3 o3.x, r2.xyzx, cb2[4].xyzx
    o4.x = dot(r2.xyz, World[1].xyz);                                                     // 69  dp3 o4.x, r2.xyzx, cb2[5].xyzx
    o5.x = dot(r2.xyz, World[2].xyz);                                                     // 70  dp3 o5.x, r2.xyzx, cb2[6].xyzx
    o4.y = dot(r0.xyz, World[1].xyz);                                                     // 71  dp3 o4.y, r0.xyzx, cb2[5].xyzx
    o5.y = dot(r0.xyz, World[2].xyz);                                                     // 72  dp3 o5.y, r0.xyzx, cb2[6].xyzx
    o4.z = dot(r1.xyz, World[1].xyz);                                                     // 73  dp3 o4.z, r1.xyzx, cb2[5].xyzx
    o5.z = dot(r1.xyz, World[2].xyz);                                                     // 74  dp3 o5.z, r1.xyzx, cb2[6].xyzx
    r0.xyz = vec3(d3d_log2(vs_COLOR0.x), d3d_log2(vs_COLOR0.y), d3d_log2(vs_COLOR0.z));   // 75  log r0.xyz, v4.xyzx
    r0.xyz = r0.xyz * vec3(FO4_L_2_2);                                                    // 76  mul r0.xyz, r0.xyzx, l(2.200000, 2.200000, 2.200000, 0.000000)
    o7.xyz = vec3(d3d_exp2(r0.x), d3d_exp2(r0.y), d3d_exp2(r0.z));                        // 77  exp o7.xyz, r0.xyzx
    o7.w = vs_COLOR0.w;                                                                   // 78  mov o7.w, v4.w
    return;                                                                               // 79  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVs_rec1490(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVs_rec1490 ####
//#### BEGIN Fo4LitVs_rec1492 ####
// class of identical transcribed code: rec1492 t00000103
// VS inputs: vertex attributes at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
layout(location = 5) in vec4 vs_COLOR0;
layout(location = 6) in vec4 vs_BLENDWEIGHT0;
layout(location = 7) in vec4 vs_BLENDINDICES0;
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
uniform vec4 cb12_viewproj[4];      // cb12 rows 8..11: view-projection rows (0x14181E368..3D5)
uniform vec4 cb12_35;               // cb12 row 35: eye (0x14181E70B..729)
// b06_BSLighting_VS_rec1492_t00000103  technique 0x00000103 = VC|SKINNED|ENVMAP
// constants by name (fxp offset table of rec1492, loader 0x14181E030, obj+0x68; names 0x142243A40): EyePosition = cb2[3].x, TexcoordOffset = cb1[2].x
void Fo4LitVs_rec1492(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9;
    ivec4 i2, i3, i5;
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
    r0.x = vs_BLENDWEIGHT0.y + vs_BLENDWEIGHT0.x;                                         // 53  add r0.x, v5.y, v5.x
    r0.x = d3d_sat(r0.x + vs_BLENDWEIGHT0.z);                                             // 54  add_sat r0.x, r0.x, v5.z
    r0.x = -r0.x + 1.0;                                                                   // 55  add r0.x, -r0.x, l(1.000000)
    r1.xyz = vec3(-0.0, -0.0, -0.0);                                                      // 56  mov r1.xyz, l(-0.000000,-0.000000,-0.000000,0)
    r1.w = -cb12_35.z;                                                                    // 57  mov r1.w, -cb12[35].z
    r2.xyzw = vs_BLENDINDICES0.xyzw * vec4(FO4_L_765_01001);                              // 58  mul r2.xyzw, v6.xyzw, l(765.010010, 765.010010, 765.010010, 765.010010)
    i2.xyzw = ivec4(d3d_ftoi(r2.x), d3d_ftoi(r2.y), d3d_ftoi(r2.z), d3d_ftoi(r2.w));      // 59  ftoi r2.xyzw, r2.xyzw
    i3.xyzw = ivec4((i2.x + 1), (i2.x + 2), (i2.y + 1), (i2.y + 2));                      // 60  iadd r3.xyzw, r2.xxyy, l(1, 2, 1, 2)
    r4.xyzw = r1.zzzw + d3d_cb10(i3.w + 0).xyzw;                                          // 61  add r4.xyzw, r1.zzzw, cb10[r3.w + 0].xyzw
    r4.xyzw = r4.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 62  mul r4.xyzw, r4.xyzw, v5.yyyy
    r5.xyzw = r1.zzzw + d3d_cb10(i3.y + 0).xyzw;                                          // 63  add r5.xyzw, r1.zzzw, cb10[r3.y + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.xxxx * r5.xyzw + r4.xyzw;                                   // 64  mad r4.xyzw, v5.xxxx, r5.xyzw, r4.xyzw
    i5.xyzw = ivec4((i2.z + 1), (i2.z + 2), (i2.w + 1), (i2.w + 2));                      // 65  iadd r5.xyzw, r2.zzww, l(1, 2, 1, 2)
    r6.xyzw = r1.zzzw + d3d_cb10(i5.y + 0).xyzw;                                          // 66  add r6.xyzw, r1.zzzw, cb10[r5.y + 0].xyzw
    r1.xyzw = r1.xyzw + d3d_cb10(i5.w + 0).xyzw;                                          // 67  add r1.xyzw, r1.xyzw, cb10[r5.w + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.zzzz * r6.xyzw + r4.xyzw;                                   // 68  mad r4.xyzw, v5.zzzz, r6.xyzw, r4.xyzw
    r1.xyzw = r0.xxxx * r1.xyzw + r4.xyzw;                                                // 69  mad r1.xyzw, r0.xxxx, r1.xyzw, r4.xyzw
    r4.xyz = vs_POSITION0.xyz;                                                            // 70  mov r4.xyz, v0.xyzx
    r4.w = 1.0;                                                                           // 71  mov r4.w, l(1.000000)
    r6.z = dot(r4.xyzw, r1.xyzw);                                                         // 72  dp4 r6.z, r4.xyzw, r1.xyzw
    r7.xz = vec2(-0.0, -0.0);                                                             // 73  mov r7.xz, l(-0.000000,0,-0.000000,0)
    r7.yw = -cb12_35.xy;                                                                  // 74  mov r7.yw, -cb12[35].xxxy
    r8.xyzw = r7.xxxy + d3d_cb10(i2.y + 0).xyzw;                                          // 75  add r8.xyzw, r7.xxxy, cb10[r2.y + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 76  mul r8.xyzw, r8.xyzw, v5.yyyy
    r9.xyzw = r7.xxxy + d3d_cb10(i2.x + 0).xyzw;                                          // 77  add r9.xyzw, r7.xxxy, cb10[r2.x + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.xxxx * r9.xyzw + r8.xyzw;                                   // 78  mad r8.xyzw, v5.xxxx, r9.xyzw, r8.xyzw
    r9.xyzw = r7.xxxy + d3d_cb10(i2.z + 0).xyzw;                                          // 79  add r9.xyzw, r7.xxxy, cb10[r2.z + 0].xyzw
    r2.xyzw = r7.xxxy + d3d_cb10(i2.w + 0).xyzw;                                          // 80  add r2.xyzw, r7.xxxy, cb10[r2.w + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.zzzz * r9.xyzw + r8.xyzw;                                   // 81  mad r8.xyzw, v5.zzzz, r9.xyzw, r8.xyzw
    r2.xyzw = r0.xxxx * r2.xyzw + r8.xyzw;                                                // 82  mad r2.xyzw, r0.xxxx, r2.xyzw, r8.xyzw
    r6.x = dot(r4.xyzw, r2.xyzw);                                                         // 83  dp4 r6.x, r4.xyzw, r2.xyzw
    r8.xyzw = r7.zzzw + d3d_cb10(i3.z + 0).xyzw;                                          // 84  add r8.xyzw, r7.zzzw, cb10[r3.z + 0].xyzw
    r3.xyzw = r7.zzzw + d3d_cb10(i3.x + 0).xyzw;                                          // 85  add r3.xyzw, r7.zzzw, cb10[r3.x + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 86  mul r8.xyzw, r8.xyzw, v5.yyyy
    r3.xyzw = vs_BLENDWEIGHT0.xxxx * r3.xyzw + r8.xyzw;                                   // 87  mad r3.xyzw, v5.xxxx, r3.xyzw, r8.xyzw
    r8.xyzw = r7.zzzw + d3d_cb10(i5.x + 0).xyzw;                                          // 88  add r8.xyzw, r7.zzzw, cb10[r5.x + 0].xyzw
    r5.xyzw = r7.zzzw + d3d_cb10(i5.z + 0).xyzw;                                          // 89  add r5.xyzw, r7.zzzw, cb10[r5.z + 0].xyzw
    r3.xyzw = vs_BLENDWEIGHT0.zzzz * r8.xyzw + r3.xyzw;                                   // 90  mad r3.xyzw, v5.zzzz, r8.xyzw, r3.xyzw
    r0.xyzw = r0.xxxx * r5.xyzw + r3.xyzw;                                                // 91  mad r0.xyzw, r0.xxxx, r5.xyzw, r3.xyzw
    r6.y = dot(r4.xyzw, r0.xyzw);                                                         // 92  dp4 r6.y, r4.xyzw, r0.xyzw
    r6.w = 1.0;                                                                           // 93  mov r6.w, l(1.000000)
    o0.x = dot(cb12_viewproj[0].xyzw, r6.xyzw);                                           // 94  dp4 o0.x, cb12[8].xyzw, r6.xyzw
    o0.y = dot(cb12_viewproj[1].xyzw, r6.xyzw);                                           // 95  dp4 o0.y, cb12[9].xyzw, r6.xyzw
    o0.w = dot(cb12_viewproj[3].xyzw, r6.xyzw);                                           // 96  dp4 o0.w, cb12[11].xyzw, r6.xyzw
    r0.w = dot(cb12_viewproj[2].xyzw, r6.xyzw);                                           // 97  dp4 r0.w, cb12[10].xyzw, r6.xyzw
    o0.z = r0.w;                                                                          // 98  mov o0.z, r0.w
    o2.w = r0.w;                                                                          // 99  mov o2.w, r0.w
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 100  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    o2.xyz = r6.xyz;                                                                      // 101  mov o2.xyz, r6.xyzx
    o6.xyz = -r6.xyz + EyePosition.xyz;                                                   // 102  add o6.xyz, -r6.xyzx, cb2[3].xyzx
    r3.x = vs_POSITION0.w;                                                                // 103  mov r3.x, v0.w
    r3.y = vs_NORMAL0.w * 2.0 + -1.0;                                                     // 104  mad r3.y, v2.w, l(2.000000), l(-1.000000)
    r3.z = vs_BINORMAL0.w * 2.0 + -1.0;                                                   // 105  mad r3.z, v3.w, l(2.000000), l(-1.000000)
    r4.y = dot(r3.xyz, r0.xyz);                                                           // 106  dp3 r4.y, r3.xyzx, r0.xyzx
    r4.z = dot(r3.xyz, r1.xyz);                                                           // 107  dp3 r4.z, r3.xyzx, r1.xyzx
    r4.x = dot(r3.xyz, r2.xyz);                                                           // 108  dp3 r4.x, r3.xyzx, r2.xyzx
    r0.w = dot(r4.xyz, r4.xyz);                                                           // 109  dp3 r0.w, r4.xyzx, r4.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 110  rsq r0.w, r0.w
    r3.xyz = r0.www * r4.xyz;                                                             // 111  mul r3.xyz, r0.wwww, r4.xyzx
    o3.x = r3.x;                                                                          // 112  mov o3.x, r3.x
    r4.xyz = vs_BINORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);             // 113  mad r4.xyz, v3.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    r5.y = dot(r4.xyz, r0.xyz);                                                           // 114  dp3 r5.y, r4.xyzx, r0.xyzx
    r5.z = dot(r4.xyz, r1.xyz);                                                           // 115  dp3 r5.z, r4.xyzx, r1.xyzx
    r5.x = dot(r4.xyz, r2.xyz);                                                           // 116  dp3 r5.x, r4.xyzx, r2.xyzx
    r0.w = dot(r5.xyz, r5.xyz);                                                           // 117  dp3 r0.w, r5.xyzx, r5.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 118  rsq r0.w, r0.w
    r4.xyz = r0.www * r5.xyz;                                                             // 119  mul r4.xyz, r0.wwww, r5.xyzx
    o3.y = r4.x;                                                                          // 120  mov o3.y, r4.x
    r5.xyz = vs_NORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);               // 121  mad r5.xyz, v2.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    r0.xyz = appSkinNormal(r2.xyz, r0.xyz, r1.xyz, r5.xyz);   // APP RULE (user decision 12-oct-2026, D2): normal by the inverse-transpose of the blended 3x3 (AppSkinLaw); engine applies M (rec1492 L122-124)// 122  dp3 r0.y, r5.xyzx, r0.xyzx
    // 123 APP RULE D2: folded into line 122                                              // 123  dp3 r0.z, r5.xyzx, r1.xyzx
    // 124 APP RULE D2: folded into line 122                                              // 124  dp3 r0.x, r5.xyzx, r2.xyzx
    r0.w = dot(r0.xyz, r0.xyz);                                                           // 125  dp3 r0.w, r0.xyzx, r0.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 126  rsq r0.w, r0.w
    r0.xyz = r0.www * r0.xyz;                                                             // 127  mul r0.xyz, r0.wwww, r0.xyzx
    o3.z = r0.x;                                                                          // 128  mov o3.z, r0.x
    o4.x = r3.y;                                                                          // 129  mov o4.x, r3.y
    o5.x = r3.z;                                                                          // 130  mov o5.x, r3.z
    o4.y = r4.y;                                                                          // 131  mov o4.y, r4.y
    o5.y = r4.z;                                                                          // 132  mov o5.y, r4.z
    o4.z = r0.y;                                                                          // 133  mov o4.z, r0.y
    o5.z = r0.z;                                                                          // 134  mov o5.z, r0.z
    r0.xyz = vec3(d3d_log2(vs_COLOR0.x), d3d_log2(vs_COLOR0.y), d3d_log2(vs_COLOR0.z));   // 135  log r0.xyz, v4.xyzx
    r0.xyz = r0.xyz * vec3(FO4_L_2_2);                                                    // 136  mul r0.xyz, r0.xyzx, l(2.200000, 2.200000, 2.200000, 0.000000)
    o7.xyz = vec3(d3d_exp2(r0.x), d3d_exp2(r0.y), d3d_exp2(r0.z));                        // 137  exp o7.xyz, r0.xyzx
    o7.w = vs_COLOR0.w;                                                                   // 138  mov o7.w, v4.w
    return;                                                                               // 139  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVs_rec1492(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVs_rec1492 ####
//#### BEGIN Fo4LitVs_rec1493 ####
// class of identical transcribed code: rec1493 t00000003
// VS inputs: vertex attributes at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
layout(location = 5) in vec4 vs_COLOR0;
layout(location = 6) in vec4 vs_BLENDWEIGHT0;
layout(location = 7) in vec4 vs_BLENDINDICES0;
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
uniform vec4 cb12_viewproj[4];      // cb12 rows 8..11: view-projection rows (0x14181E368..3D5)
uniform vec4 cb12_35;               // cb12 row 35: eye (0x14181E70B..729)
// b06_BSLighting_VS_rec1493_t00000003  technique 0x00000003 = VC|SKINNED
// constants by name (fxp offset table of rec1493, loader 0x14181E030, obj+0x68; names 0x142243A40): EyePosition = cb2[3].x, TexcoordOffset = cb1[2].x
void Fo4LitVs_rec1493(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0, r1, r2, r3, r4, r5, r6, r7, r8, r9;
    ivec4 i2, i3, i5;
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
    r0.x = vs_BLENDWEIGHT0.y + vs_BLENDWEIGHT0.x;                                         // 53  add r0.x, v5.y, v5.x
    r0.x = d3d_sat(r0.x + vs_BLENDWEIGHT0.z);                                             // 54  add_sat r0.x, r0.x, v5.z
    r0.x = -r0.x + 1.0;                                                                   // 55  add r0.x, -r0.x, l(1.000000)
    r1.xyz = vec3(-0.0, -0.0, -0.0);                                                      // 56  mov r1.xyz, l(-0.000000,-0.000000,-0.000000,0)
    r1.w = -cb12_35.z;                                                                    // 57  mov r1.w, -cb12[35].z
    r2.xyzw = vs_BLENDINDICES0.xyzw * vec4(FO4_L_765_01001);                              // 58  mul r2.xyzw, v6.xyzw, l(765.010010, 765.010010, 765.010010, 765.010010)
    i2.xyzw = ivec4(d3d_ftoi(r2.x), d3d_ftoi(r2.y), d3d_ftoi(r2.z), d3d_ftoi(r2.w));      // 59  ftoi r2.xyzw, r2.xyzw
    i3.xyzw = ivec4((i2.x + 1), (i2.x + 2), (i2.y + 1), (i2.y + 2));                      // 60  iadd r3.xyzw, r2.xxyy, l(1, 2, 1, 2)
    r4.xyzw = r1.zzzw + d3d_cb10(i3.w + 0).xyzw;                                          // 61  add r4.xyzw, r1.zzzw, cb10[r3.w + 0].xyzw
    r4.xyzw = r4.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 62  mul r4.xyzw, r4.xyzw, v5.yyyy
    r5.xyzw = r1.zzzw + d3d_cb10(i3.y + 0).xyzw;                                          // 63  add r5.xyzw, r1.zzzw, cb10[r3.y + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.xxxx * r5.xyzw + r4.xyzw;                                   // 64  mad r4.xyzw, v5.xxxx, r5.xyzw, r4.xyzw
    i5.xyzw = ivec4((i2.z + 1), (i2.z + 2), (i2.w + 1), (i2.w + 2));                      // 65  iadd r5.xyzw, r2.zzww, l(1, 2, 1, 2)
    r6.xyzw = r1.zzzw + d3d_cb10(i5.y + 0).xyzw;                                          // 66  add r6.xyzw, r1.zzzw, cb10[r5.y + 0].xyzw
    r1.xyzw = r1.xyzw + d3d_cb10(i5.w + 0).xyzw;                                          // 67  add r1.xyzw, r1.xyzw, cb10[r5.w + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.zzzz * r6.xyzw + r4.xyzw;                                   // 68  mad r4.xyzw, v5.zzzz, r6.xyzw, r4.xyzw
    r1.xyzw = r0.xxxx * r1.xyzw + r4.xyzw;                                                // 69  mad r1.xyzw, r0.xxxx, r1.xyzw, r4.xyzw
    r4.xyz = vs_POSITION0.xyz;                                                            // 70  mov r4.xyz, v0.xyzx
    r4.w = 1.0;                                                                           // 71  mov r4.w, l(1.000000)
    r6.z = dot(r4.xyzw, r1.xyzw);                                                         // 72  dp4 r6.z, r4.xyzw, r1.xyzw
    r7.xz = vec2(-0.0, -0.0);                                                             // 73  mov r7.xz, l(-0.000000,0,-0.000000,0)
    r7.yw = -cb12_35.xy;                                                                  // 74  mov r7.yw, -cb12[35].xxxy
    r8.xyzw = r7.xxxy + d3d_cb10(i2.y + 0).xyzw;                                          // 75  add r8.xyzw, r7.xxxy, cb10[r2.y + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 76  mul r8.xyzw, r8.xyzw, v5.yyyy
    r9.xyzw = r7.xxxy + d3d_cb10(i2.x + 0).xyzw;                                          // 77  add r9.xyzw, r7.xxxy, cb10[r2.x + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.xxxx * r9.xyzw + r8.xyzw;                                   // 78  mad r8.xyzw, v5.xxxx, r9.xyzw, r8.xyzw
    r9.xyzw = r7.xxxy + d3d_cb10(i2.z + 0).xyzw;                                          // 79  add r9.xyzw, r7.xxxy, cb10[r2.z + 0].xyzw
    r2.xyzw = r7.xxxy + d3d_cb10(i2.w + 0).xyzw;                                          // 80  add r2.xyzw, r7.xxxy, cb10[r2.w + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.zzzz * r9.xyzw + r8.xyzw;                                   // 81  mad r8.xyzw, v5.zzzz, r9.xyzw, r8.xyzw
    r2.xyzw = r0.xxxx * r2.xyzw + r8.xyzw;                                                // 82  mad r2.xyzw, r0.xxxx, r2.xyzw, r8.xyzw
    r6.x = dot(r4.xyzw, r2.xyzw);                                                         // 83  dp4 r6.x, r4.xyzw, r2.xyzw
    r8.xyzw = r7.zzzw + d3d_cb10(i3.z + 0).xyzw;                                          // 84  add r8.xyzw, r7.zzzw, cb10[r3.z + 0].xyzw
    r3.xyzw = r7.zzzw + d3d_cb10(i3.x + 0).xyzw;                                          // 85  add r3.xyzw, r7.zzzw, cb10[r3.x + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 86  mul r8.xyzw, r8.xyzw, v5.yyyy
    r3.xyzw = vs_BLENDWEIGHT0.xxxx * r3.xyzw + r8.xyzw;                                   // 87  mad r3.xyzw, v5.xxxx, r3.xyzw, r8.xyzw
    r8.xyzw = r7.zzzw + d3d_cb10(i5.x + 0).xyzw;                                          // 88  add r8.xyzw, r7.zzzw, cb10[r5.x + 0].xyzw
    r5.xyzw = r7.zzzw + d3d_cb10(i5.z + 0).xyzw;                                          // 89  add r5.xyzw, r7.zzzw, cb10[r5.z + 0].xyzw
    r3.xyzw = vs_BLENDWEIGHT0.zzzz * r8.xyzw + r3.xyzw;                                   // 90  mad r3.xyzw, v5.zzzz, r8.xyzw, r3.xyzw
    r0.xyzw = r0.xxxx * r5.xyzw + r3.xyzw;                                                // 91  mad r0.xyzw, r0.xxxx, r5.xyzw, r3.xyzw
    r6.y = dot(r4.xyzw, r0.xyzw);                                                         // 92  dp4 r6.y, r4.xyzw, r0.xyzw
    r6.w = 1.0;                                                                           // 93  mov r6.w, l(1.000000)
    o0.x = dot(cb12_viewproj[0].xyzw, r6.xyzw);                                           // 94  dp4 o0.x, cb12[8].xyzw, r6.xyzw
    o0.y = dot(cb12_viewproj[1].xyzw, r6.xyzw);                                           // 95  dp4 o0.y, cb12[9].xyzw, r6.xyzw
    o0.w = dot(cb12_viewproj[3].xyzw, r6.xyzw);                                           // 96  dp4 o0.w, cb12[11].xyzw, r6.xyzw
    r0.w = dot(cb12_viewproj[2].xyzw, r6.xyzw);                                           // 97  dp4 r0.w, cb12[10].xyzw, r6.xyzw
    o0.z = r0.w;                                                                          // 98  mov o0.z, r0.w
    o2.w = r0.w;                                                                          // 99  mov o2.w, r0.w
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 100  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    o2.xyz = r6.xyz;                                                                      // 101  mov o2.xyz, r6.xyzx
    o6.xyz = -r6.xyz + EyePosition.xyz;                                                   // 102  add o6.xyz, -r6.xyzx, cb2[3].xyzx
    r3.x = vs_POSITION0.w;                                                                // 103  mov r3.x, v0.w
    r3.y = vs_NORMAL0.w * 2.0 + -1.0;                                                     // 104  mad r3.y, v2.w, l(2.000000), l(-1.000000)
    r3.z = vs_BINORMAL0.w * 2.0 + -1.0;                                                   // 105  mad r3.z, v3.w, l(2.000000), l(-1.000000)
    r4.y = dot(r3.xyz, r0.xyz);                                                           // 106  dp3 r4.y, r3.xyzx, r0.xyzx
    r4.z = dot(r3.xyz, r1.xyz);                                                           // 107  dp3 r4.z, r3.xyzx, r1.xyzx
    r4.x = dot(r3.xyz, r2.xyz);                                                           // 108  dp3 r4.x, r3.xyzx, r2.xyzx
    r0.w = dot(r4.xyz, r4.xyz);                                                           // 109  dp3 r0.w, r4.xyzx, r4.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 110  rsq r0.w, r0.w
    r3.xyz = r0.www * r4.xyz;                                                             // 111  mul r3.xyz, r0.wwww, r4.xyzx
    o3.x = r3.x;                                                                          // 112  mov o3.x, r3.x
    r4.xyz = vs_BINORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);             // 113  mad r4.xyz, v3.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    r5.y = dot(r4.xyz, r0.xyz);                                                           // 114  dp3 r5.y, r4.xyzx, r0.xyzx
    r5.z = dot(r4.xyz, r1.xyz);                                                           // 115  dp3 r5.z, r4.xyzx, r1.xyzx
    r5.x = dot(r4.xyz, r2.xyz);                                                           // 116  dp3 r5.x, r4.xyzx, r2.xyzx
    r0.w = dot(r5.xyz, r5.xyz);                                                           // 117  dp3 r0.w, r5.xyzx, r5.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 118  rsq r0.w, r0.w
    r4.xyz = r0.www * r5.xyz;                                                             // 119  mul r4.xyz, r0.wwww, r5.xyzx
    o3.y = r4.x;                                                                          // 120  mov o3.y, r4.x
    r5.xyz = vs_NORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);               // 121  mad r5.xyz, v2.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    r0.xyz = appSkinNormal(r2.xyz, r0.xyz, r1.xyz, r5.xyz);   // APP RULE (user decision 12-oct-2026, D2): normal by the inverse-transpose of the blended 3x3 (AppSkinLaw); engine applies M (rec1493 L122-124)// 122  dp3 r0.y, r5.xyzx, r0.xyzx
    // 123 APP RULE D2: folded into line 122                                              // 123  dp3 r0.z, r5.xyzx, r1.xyzx
    // 124 APP RULE D2: folded into line 122                                              // 124  dp3 r0.x, r5.xyzx, r2.xyzx
    r0.w = dot(r0.xyz, r0.xyz);                                                           // 125  dp3 r0.w, r0.xyzx, r0.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 126  rsq r0.w, r0.w
    r0.xyz = r0.www * r0.xyz;                                                             // 127  mul r0.xyz, r0.wwww, r0.xyzx
    o3.z = r0.x;                                                                          // 128  mov o3.z, r0.x
    o4.x = r3.y;                                                                          // 129  mov o4.x, r3.y
    o5.x = r3.z;                                                                          // 130  mov o5.x, r3.z
    o4.y = r4.y;                                                                          // 131  mov o4.y, r4.y
    o5.y = r4.z;                                                                          // 132  mov o5.y, r4.z
    o4.z = r0.y;                                                                          // 133  mov o4.z, r0.y
    o5.z = r0.z;                                                                          // 134  mov o5.z, r0.z
    r0.xyz = vec3(d3d_log2(vs_COLOR0.x), d3d_log2(vs_COLOR0.y), d3d_log2(vs_COLOR0.z));   // 135  log r0.xyz, v4.xyzx
    r0.xyz = r0.xyz * vec3(FO4_L_2_2);                                                    // 136  mul r0.xyz, r0.xyzx, l(2.200000, 2.200000, 2.200000, 0.000000)
    o7.xyz = vec3(d3d_exp2(r0.x), d3d_exp2(r0.y), d3d_exp2(r0.z));                        // 137  exp o7.xyz, r0.xyzx
    o7.w = vs_COLOR0.w;                                                                   // 138  mov o7.w, v4.w
    return;                                                                               // 139  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVs_rec1493(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVs_rec1493 ####
//#### BEGIN Fo4LitVs_rec1494 ####
// class of identical transcribed code: rec1494 t00000C01
// VS inputs: vertex attributes at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
layout(location = 5) in vec4 vs_COLOR0;
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
uniform vec4 TreeParams;                  // name 6, cb2, writer SG 0x14223B4A8..583
uniform vec4 WorldViewProj[4];               // name 0, cb2, writer SG 0x14223B679..684
// b06_BSLighting_VS_rec1494_t00000C01  technique 0x00000C01 = VC|TREE_ANIM
// constants by name (fxp offset table of rec1494, loader 0x14181E030, obj+0x68; names 0x142243A40): WorldViewProj = cb2[0].x, EyePosition = cb2[7].x, TexcoordOffset = cb1[2].x, TreeParams = cb2[12].x
void Fo4LitVs_rec1494(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0;
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
    r0.x = TreeParams.y * TreeParams.w;                                                   // 47  mul r0.x, cb2[12].y, cb2[12].w
    r0.x = r0.x * TreeParams.x;                                                           // 48  mul r0.x, r0.x, cb2[12].x
    r0.y = dot(vs_POSITION0.xyz, vec3(1.0, 1.0, 1.0));                                    // 49  dp3 r0.y, v0.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
    r0.xy = r0.xx * vec2(FO4_L_0_1, 0.25) + r0.yy;                                        // 50  mad r0.xy, r0.xxxx, l(0.100000, 0.250000, 0.000000, 0.000000), r0.yyyy
    r0.xy = r0.xy + vec2(0.5, 0.5);                                                       // 51  add r0.xy, r0.xyxx, l(0.500000, 0.500000, 0.000000, 0.000000)
    r0.xy = vec2((r0.x - floor(r0.x)), (r0.y - floor(r0.y)));                             // 52  frc r0.xy, r0.xyxx
    r0.xy = r0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                                    // 53  mad r0.xy, r0.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    r0.zw = abs(r0.xy) * abs(r0.xy);                                                      // 54  mul r0.zw, |r0.xxxy|, |r0.xxxy|
    r0.xy = -abs(r0.xy) * vec2(2.0, 2.0) + vec2(3.0, 3.0);                                // 55  mad r0.xy, -|r0.xyxx|, l(2.000000, 2.000000, 0.000000, 0.000000), l(3.000000, 3.000000, 0.000000, 0.000000)
    r0.xy = r0.xy * r0.zw;                                                                // 56  mul r0.xy, r0.xyxx, r0.zwzz
    r0.x = r0.y * FO4_L_0_1 + r0.x;                                                       // 57  mad r0.x, r0.y, l(0.100000), r0.x
    r0.y = vs_COLOR0.w * TreeParams.z;                                                    // 58  mul r0.y, v4.w, cb2[12].z
    r0.x = r0.y * r0.x;                                                                   // 59  mul r0.x, r0.y, r0.x
    r0.yzw = vs_NORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);               // 60  mad r0.yzw, v2.xxyz, l(0.000000, 2.000000, 2.000000, 2.000000), l(0.000000, -1.000000, -1.000000, -1.000000)
    r0.xyz = r0.yzw * r0.xxx + vs_POSITION0.xyz;                                          // 61  mad r0.xyz, r0.yzwy, r0.xxxx, v0.xyzx
    r0.w = 1.0;                                                                           // 62  mov r0.w, l(1.000000)
    o0.x = dot(WorldViewProj[0].xyzw, r0.xyzw);                                           // 63  dp4 o0.x, cb2[0].xyzw, r0.xyzw
    o0.y = dot(WorldViewProj[1].xyzw, r0.xyzw);                                           // 64  dp4 o0.y, cb2[1].xyzw, r0.xyzw
    o0.w = dot(WorldViewProj[3].xyzw, r0.xyzw);                                           // 65  dp4 o0.w, cb2[3].xyzw, r0.xyzw
    r0.w = dot(WorldViewProj[2].xyzw, r0.xyzw);                                           // 66  dp4 r0.w, cb2[2].xyzw, r0.xyzw
    o0.z = r0.w;                                                                          // 67  mov o0.z, r0.w
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 68  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    o2.xyzw = r0.xyzw;                                                                    // 69  mov o2.xyzw, r0.xyzw
    o6.xyz = -r0.xyz + EyePosition.xyz;                                                   // 70  add o6.xyz, -r0.xyzx, cb2[7].xyzx
    o3.x = vs_POSITION0.w;                                                                // 71  mov o3.x, v0.w
    o3.y = vs_BINORMAL0.x * 2.0 + -1.0;                                                   // 72  mad o3.y, v3.x, l(2.000000), l(-1.000000)
    o3.z = vs_NORMAL0.x * 2.0 + -1.0;                                                     // 73  mad o3.z, v2.x, l(2.000000), l(-1.000000)
    o4.xz = vs_NORMAL0.wy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                            // 74  mad o4.xz, v2.wwyw, l(2.000000, 0.000000, 2.000000, 0.000000), l(-1.000000, 0.000000, -1.000000, 0.000000)
    o4.y = vs_BINORMAL0.y * 2.0 + -1.0;                                                   // 75  mad o4.y, v3.y, l(2.000000), l(-1.000000)
    o5.xy = vs_BINORMAL0.wz * vec2(2.0, 2.0) + vec2(-1.0, -1.0);                          // 76  mad o5.xy, v3.wzww, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
    o5.z = vs_NORMAL0.z * 2.0 + -1.0;                                                     // 77  mad o5.z, v2.z, l(2.000000), l(-1.000000)
    r0.xyz = vec3(d3d_log2(vs_COLOR0.x), d3d_log2(vs_COLOR0.y), d3d_log2(vs_COLOR0.z));   // 78  log r0.xyz, v4.xyzx
    r0.xyz = r0.xyz * vec3(FO4_L_2_2);                                                    // 79  mul r0.xyz, r0.xyzx, l(2.200000, 2.200000, 2.200000, 0.000000)
    o7.xyz = vec3(d3d_exp2(r0.x), d3d_exp2(r0.y), d3d_exp2(r0.z));                        // 80  exp o7.xyz, r0.xyzx
#ifdef ENGINE_MOTION_VECTORS
    o7.w = vs_COLOR0.w;                                                                   // 81  mov o7.w, v4.w
#endif
    return;                                                                               // 82  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVs_rec1494(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVs_rec1494 ####
//#### BEGIN Fo4LitVs_rec1495 ####
// class of identical transcribed code: rec1495 t00000004
// VS inputs: vertex attributes at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 WorldViewProj[4];               // name 0, cb2, writer SG 0x14223B679..684
#ifdef ENGINE_MOTION_VECTORS
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
#endif
// b06_BSLighting_VS_rec1495_t00000004  technique 0x00000004 = MODELSPACENORMALS
// constants by name (fxp offset table of rec1495, loader 0x14181E030, obj+0x68; names 0x142243A40): WorldViewProj = cb2[0].x
void Fo4LitVs_rec1495(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4)
{
    vec4 r0, r1;
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0);   // unwritten components (notas D9)
    r0.xyz = vs_POSITION0.xyz;                                                            // 35  mov r0.xyz, v0.xyzx
    r0.w = 1.0;                                                                           // 36  mov r0.w, l(1.000000)
    r1.x = dot(WorldViewProj[2].xyzw, r0.xyzw);                                           // 37  dp4 r1.x, cb2[2].xyzw, r0.xyzw
    o0.z = r1.x;                                                                          // 38  mov o0.z, r1.x
#ifdef ENGINE_MOTION_VECTORS
    o2.w = r1.x;                                                                          // 39  mov o2.w, r1.x
#endif
    o0.x = dot(WorldViewProj[0].xyzw, r0.xyzw);                                           // 40  dp4 o0.x, cb2[0].xyzw, r0.xyzw
    o0.y = dot(WorldViewProj[1].xyzw, r0.xyzw);                                           // 41  dp4 o0.y, cb2[1].xyzw, r0.xyzw
    o0.w = dot(WorldViewProj[3].xyzw, r0.xyzw);                                           // 42  dp4 o0.w, cb2[3].xyzw, r0.xyzw
#ifdef ENGINE_MOTION_VECTORS
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 43  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    o2.xyz = vs_POSITION0.xyz;                                                            // 44  mov o2.xyz, v0.xyzx
    o3.xyz = -vs_POSITION0.xyz + EyePosition.xyz;                                         // 45  add o3.xyz, -v0.xyzx, cb2[7].xyzx
    o4.xyzw = vec4(1.0, 1.0, 1.0, 1.0);                                                   // 46  mov o4.xyzw, l(1.000000,1.000000,1.000000,1.000000)
#endif
    return;                                                                               // 47  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4;
    Fo4LitVs_rec1495(o0, o1, o2, o3, o4);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD5.xyz = o3.xyz;
    lit_COLOR0.xyzw = o4.xyzw;
}
//#### END Fo4LitVs_rec1495 ####
//#### BEGIN Fo4LitVsCpu_rec1488 ####
// class of identical transcribed code: rec1488 t00000002, rec1491 t00000102
// CPU-route VS (layout tbn): the CPU stream at the locations of asm2glsl.CPU_LOC; the engine attributes it still reads
// at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 6) in vec4 cpu_ps;
#ifdef ENGINE_MOTION_VECTORS
layout(location = 7) in vec4 cpu_r0;
layout(location = 12) in vec4 cpu_r1;
layout(location = 13) in vec4 cpu_r2;
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
layout(location = 2) in vec4 vs_BLENDWEIGHT0;
layout(location = 9) in vec4 vs_BLENDINDICES0;
#endif
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 cb12_viewproj[4];      // cb12 rows 8..11: view-projection rows (0x14181E368..3D5)
uniform vec4 cb12_35;               // cb12 row 35: eye (0x14181E70B..729)
#ifdef ENGINE_MOTION_VECTORS
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
#endif
// b06_BSLighting_VS_rec1488_t00000002  technique 0x00000002 = SKINNED
// constants by name (fxp offset table of rec1488, loader 0x14181E030, obj+0x68; names 0x142243A40): 
void Fo4LitVsCpu_rec1488(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0, r6;
#ifdef ENGINE_MOTION_VECTORS
    vec4 r1, r2, r3, r4, r5, r7, r8, r9;
    ivec4 i2, i3, i5;
#endif
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
#ifdef ENGINE_MOTION_VECTORS
    r0.x = vs_BLENDWEIGHT0.y + vs_BLENDWEIGHT0.x;                                         // 51  add r0.x, v4.y, v4.x
    r0.x = d3d_sat(r0.x + vs_BLENDWEIGHT0.z);                                             // 52  add_sat r0.x, r0.x, v4.z
    r0.x = -r0.x + 1.0;                                                                   // 53  add r0.x, -r0.x, l(1.000000)
    r1.xyz = vec3(-0.0, -0.0, -0.0);                                                      // 54  mov r1.xyz, l(-0.000000,-0.000000,-0.000000,0)
    r1.w = -cb12_35.z;                                                                    // 55  mov r1.w, -cb12[35].z
    r2.xyzw = vs_BLENDINDICES0.xyzw * vec4(FO4_L_765_01001);                              // 56  mul r2.xyzw, v5.xyzw, l(765.010010, 765.010010, 765.010010, 765.010010)
    i2.xyzw = ivec4(d3d_ftoi(r2.x), d3d_ftoi(r2.y), d3d_ftoi(r2.z), d3d_ftoi(r2.w));      // 57  ftoi r2.xyzw, r2.xyzw
    i3.xyzw = ivec4((i2.x + 1), (i2.x + 2), (i2.y + 1), (i2.y + 2));                      // 58  iadd r3.xyzw, r2.xxyy, l(1, 2, 1, 2)
    r4.xyzw = r1.zzzw + d3d_cb10(i3.w + 0).xyzw;                                          // 59  add r4.xyzw, r1.zzzw, cb10[r3.w + 0].xyzw
    r4.xyzw = r4.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 60  mul r4.xyzw, r4.xyzw, v4.yyyy
    r5.xyzw = r1.zzzw + d3d_cb10(i3.y + 0).xyzw;                                          // 61  add r5.xyzw, r1.zzzw, cb10[r3.y + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.xxxx * r5.xyzw + r4.xyzw;                                   // 62  mad r4.xyzw, v4.xxxx, r5.xyzw, r4.xyzw
    i5.xyzw = ivec4((i2.z + 1), (i2.z + 2), (i2.w + 1), (i2.w + 2));                      // 63  iadd r5.xyzw, r2.zzww, l(1, 2, 1, 2)
    r6.xyzw = r1.zzzw + d3d_cb10(i5.y + 0).xyzw;                                          // 64  add r6.xyzw, r1.zzzw, cb10[r5.y + 0].xyzw
    r1.xyzw = r1.xyzw + d3d_cb10(i5.w + 0).xyzw;                                          // 65  add r1.xyzw, r1.xyzw, cb10[r5.w + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.zzzz * r6.xyzw + r4.xyzw;                                   // 66  mad r4.xyzw, v4.zzzz, r6.xyzw, r4.xyzw
    r1.xyzw = r0.xxxx * r1.xyzw + r4.xyzw;                                                // 67  mad r1.xyzw, r0.xxxx, r1.xyzw, r4.xyzw
    r4.xyz = vs_POSITION0.xyz;                                                            // 68  mov r4.xyz, v0.xyzx
    r4.w = 1.0;                                                                           // 69  mov r4.w, l(1.000000)
#endif
    r6.z = (cpu_ps.z - cpu_ps.w * cb12_35.z);                                             // 70  dp4 r6.z, r4.xyzw, r1.xyzw   [CPU route: mov r6.z, vcpup.z]
#ifdef ENGINE_MOTION_VECTORS
    r7.xz = vec2(-0.0, -0.0);                                                             // 71  mov r7.xz, l(-0.000000,0,-0.000000,0)
    r7.yw = -cb12_35.xy;                                                                  // 72  mov r7.yw, -cb12[35].xxxy
    r8.xyzw = r7.xxxy + d3d_cb10(i2.y + 0).xyzw;                                          // 73  add r8.xyzw, r7.xxxy, cb10[r2.y + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 74  mul r8.xyzw, r8.xyzw, v4.yyyy
    r9.xyzw = r7.xxxy + d3d_cb10(i2.x + 0).xyzw;                                          // 75  add r9.xyzw, r7.xxxy, cb10[r2.x + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.xxxx * r9.xyzw + r8.xyzw;                                   // 76  mad r8.xyzw, v4.xxxx, r9.xyzw, r8.xyzw
    r9.xyzw = r7.xxxy + d3d_cb10(i2.z + 0).xyzw;                                          // 77  add r9.xyzw, r7.xxxy, cb10[r2.z + 0].xyzw
    r2.xyzw = r7.xxxy + d3d_cb10(i2.w + 0).xyzw;                                          // 78  add r2.xyzw, r7.xxxy, cb10[r2.w + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.zzzz * r9.xyzw + r8.xyzw;                                   // 79  mad r8.xyzw, v4.zzzz, r9.xyzw, r8.xyzw
    r2.xyzw = r0.xxxx * r2.xyzw + r8.xyzw;                                                // 80  mad r2.xyzw, r0.xxxx, r2.xyzw, r8.xyzw
#endif
    r6.x = (cpu_ps.x - cpu_ps.w * cb12_35.x);                                             // 81  dp4 r6.x, r4.xyzw, r2.xyzw   [CPU route: mov r6.x, vcpup.x]
#ifdef ENGINE_MOTION_VECTORS
    r8.xyzw = r7.zzzw + d3d_cb10(i3.z + 0).xyzw;                                          // 82  add r8.xyzw, r7.zzzw, cb10[r3.z + 0].xyzw
    r3.xyzw = r7.zzzw + d3d_cb10(i3.x + 0).xyzw;                                          // 83  add r3.xyzw, r7.zzzw, cb10[r3.x + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 84  mul r8.xyzw, r8.xyzw, v4.yyyy
    r3.xyzw = vs_BLENDWEIGHT0.xxxx * r3.xyzw + r8.xyzw;                                   // 85  mad r3.xyzw, v4.xxxx, r3.xyzw, r8.xyzw
    r8.xyzw = r7.zzzw + d3d_cb10(i5.x + 0).xyzw;                                          // 86  add r8.xyzw, r7.zzzw, cb10[r5.x + 0].xyzw
    r5.xyzw = r7.zzzw + d3d_cb10(i5.z + 0).xyzw;                                          // 87  add r5.xyzw, r7.zzzw, cb10[r5.z + 0].xyzw
    r3.xyzw = vs_BLENDWEIGHT0.zzzz * r8.xyzw + r3.xyzw;                                   // 88  mad r3.xyzw, v4.zzzz, r8.xyzw, r3.xyzw
    r0.xyzw = r0.xxxx * r5.xyzw + r3.xyzw;                                                // 89  mad r0.xyzw, r0.xxxx, r5.xyzw, r3.xyzw
#endif
    r6.y = (cpu_ps.y - cpu_ps.w * cb12_35.y);                                             // 90  dp4 r6.y, r4.xyzw, r0.xyzw   [CPU route: mov r6.y, vcpup.y]
    r6.w = 1.0;                                                                           // 91  mov r6.w, l(1.000000)
    o0.x = dot(cb12_viewproj[0].xyzw, r6.xyzw);                                           // 92  dp4 o0.x, cb12[8].xyzw, r6.xyzw
    o0.y = dot(cb12_viewproj[1].xyzw, r6.xyzw);                                           // 93  dp4 o0.y, cb12[9].xyzw, r6.xyzw
    o0.w = dot(cb12_viewproj[3].xyzw, r6.xyzw);                                           // 94  dp4 o0.w, cb12[11].xyzw, r6.xyzw
    r0.w = dot(cb12_viewproj[2].xyzw, r6.xyzw);                                           // 95  dp4 r0.w, cb12[10].xyzw, r6.xyzw
    o0.z = r0.w;                                                                          // 96  mov o0.z, r0.w
#ifdef ENGINE_MOTION_VECTORS
    o2.w = r0.w;                                                                          // 97  mov o2.w, r0.w
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 98  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    o2.xyz = r6.xyz;                                                                      // 99  mov o2.xyz, r6.xyzx
    o6.xyz = -r6.xyz + EyePosition.xyz;                                                   // 100  add o6.xyz, -r6.xyzx, cb2[3].xyzx
    r3.x = vs_POSITION0.w;                                                                // 101  mov r3.x, v0.w
    r3.y = vs_NORMAL0.w * 2.0 + -1.0;                                                     // 102  mad r3.y, v2.w, l(2.000000), l(-1.000000)
    r3.z = vs_BINORMAL0.w * 2.0 + -1.0;                                                   // 103  mad r3.z, v3.w, l(2.000000), l(-1.000000)
    r4.y = cpu_r2.y;                                                                      // 104  dp3 r4.y, r3.xyzx, r0.xyzx   [CPU route: mov r4.y, vcpux.y]
    r4.z = cpu_r2.z;                                                                      // 105  dp3 r4.z, r3.xyzx, r1.xyzx   [CPU route: mov r4.z, vcpux.z]
    r4.x = cpu_r2.x;                                                                      // 106  dp3 r4.x, r3.xyzx, r2.xyzx   [CPU route: mov r4.x, vcpux.x]
    r0.w = dot(r4.xyz, r4.xyz);                                                           // 107  dp3 r0.w, r4.xyzx, r4.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 108  rsq r0.w, r0.w
    r3.xyz = r0.www * r4.xyz;                                                             // 109  mul r3.xyz, r0.wwww, r4.xyzx
    o3.x = r3.x;                                                                          // 110  mov o3.x, r3.x
    r4.xyz = vs_BINORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);             // 111  mad r4.xyz, v3.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    r5.y = cpu_r1.y;                                                                      // 112  dp3 r5.y, r4.xyzx, r0.xyzx   [CPU route: mov r5.y, vcpub.y]
    r5.z = cpu_r1.z;                                                                      // 113  dp3 r5.z, r4.xyzx, r1.xyzx   [CPU route: mov r5.z, vcpub.z]
    r5.x = cpu_r1.x;                                                                      // 114  dp3 r5.x, r4.xyzx, r2.xyzx   [CPU route: mov r5.x, vcpub.x]
    r0.w = dot(r5.xyz, r5.xyz);                                                           // 115  dp3 r0.w, r5.xyzx, r5.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 116  rsq r0.w, r0.w
    r4.xyz = r0.www * r5.xyz;                                                             // 117  mul r4.xyz, r0.wwww, r5.xyzx
    o3.y = r4.x;                                                                          // 118  mov o3.y, r4.x
    r5.xyz = vs_NORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);               // 119  mad r5.xyz, v2.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
    r0.y = cpu_r0.y;                                                                      // 120  dp3 r0.y, r5.xyzx, r0.xyzx   [CPU route: mov r0.y, vcpun.y]
    r0.z = cpu_r0.z;                                                                      // 121  dp3 r0.z, r5.xyzx, r1.xyzx   [CPU route: mov r0.z, vcpun.z]
    r0.x = cpu_r0.x;                                                                      // 122  dp3 r0.x, r5.xyzx, r2.xyzx   [CPU route: mov r0.x, vcpun.x]
    r0.w = dot(r0.xyz, r0.xyz);                                                           // 123  dp3 r0.w, r0.xyzx, r0.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 124  rsq r0.w, r0.w
    r0.xyz = r0.www * r0.xyz;                                                             // 125  mul r0.xyz, r0.wwww, r0.xyzx
    o3.z = r0.x;                                                                          // 126  mov o3.z, r0.x
    o4.x = r3.y;                                                                          // 127  mov o4.x, r3.y
    o5.x = r3.z;                                                                          // 128  mov o5.x, r3.z
    o4.y = r4.y;                                                                          // 129  mov o4.y, r4.y
    o5.y = r4.z;                                                                          // 130  mov o5.y, r4.z
    o4.z = r0.y;                                                                          // 131  mov o4.z, r0.y
    o5.z = r0.z;                                                                          // 132  mov o5.z, r0.z
    o7.xyzw = vec4(1.0, 1.0, 1.0, 1.0);                                                   // 133  mov o7.xyzw, l(1.000000,1.000000,1.000000,1.000000)
#endif
    return;                                                                               // 134  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVsCpu_rec1488(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVsCpu_rec1488 ####
//#### BEGIN Fo4LitVsCpu_rec1493 ####
// class of identical transcribed code: rec1493 t00000003, rec1492 t00000103
// CPU-route VS (layout tbn): the CPU stream at the locations of asm2glsl.CPU_LOC; the engine attributes it still reads
// at the locations of Fo4EngineVertexLayout.Sem (layout 0x141823210)
layout(location = 6) in vec4 cpu_ps;
layout(location = 7) in vec4 cpu_r0;
layout(location = 12) in vec4 cpu_r1;
layout(location = 13) in vec4 cpu_r2;
layout(location = 1) in vec4 vs_TEXCOORD0;
layout(location = 5) in vec4 vs_COLOR0;
#ifdef ENGINE_MOTION_VECTORS
layout(location = 0) in vec4 vs_POSITION0;
layout(location = 3) in vec4 vs_NORMAL0;
layout(location = 4) in vec4 vs_BINORMAL0;
layout(location = 2) in vec4 vs_BLENDWEIGHT0;
layout(location = 9) in vec4 vs_BLENDINDICES0;
#endif
invariant gl_Position;   // the prepass and the G-buffer draw must give the same depth (GLSL 4.60 4.8.1)
out vec4 lit_TEXCOORD0;
out vec4 lit_TEXCOORD4;
out vec4 lit_TEXCOORD1;
out vec4 lit_TEXCOORD2;
out vec4 lit_TEXCOORD3;
out vec4 lit_TEXCOORD5;
out vec4 lit_COLOR0;
uniform vec4 EyePosition;                 // name 3, cb2, writer SG>0x14223D120 0x14223D19E..23E; .w none (engine-no-writer seat: fo4 b06 vs EyePosition.w)
uniform vec4 TexcoordOffset;              // name 5, cb1, writer SM 0x14223AFB0..FD6
uniform vec4 cb12_viewproj[4];      // cb12 rows 8..11: view-projection rows (0x14181E368..3D5)
uniform vec4 cb12_35;               // cb12 row 35: eye (0x14181E70B..729)
// b06_BSLighting_VS_rec1493_t00000003  technique 0x00000003 = VC|SKINNED
// constants by name (fxp offset table of rec1493, loader 0x14181E030, obj+0x68; names 0x142243A40): EyePosition = cb2[3].x, TexcoordOffset = cb1[2].x
void Fo4LitVsCpu_rec1493(out vec4 o0, out vec4 o1, out vec4 o2, out vec4 o3, out vec4 o4, out vec4 o5, out vec4 o6, out vec4 o7)
{
    vec4 r0, r3, r4, r5, r6;
#ifdef ENGINE_MOTION_VECTORS
    vec4 r1, r2, r7, r8, r9;
    ivec4 i2, i3, i5;
#endif
    o0 = vec4(0.0); o1 = vec4(0.0); o2 = vec4(0.0); o3 = vec4(0.0); o4 = vec4(0.0); o5 = vec4(0.0); o6 = vec4(0.0); o7 = vec4(0.0);   // unwritten components (notas D9)
#ifdef ENGINE_MOTION_VECTORS
    r0.x = vs_BLENDWEIGHT0.y + vs_BLENDWEIGHT0.x;                                         // 53  add r0.x, v5.y, v5.x
    r0.x = d3d_sat(r0.x + vs_BLENDWEIGHT0.z);                                             // 54  add_sat r0.x, r0.x, v5.z
    r0.x = -r0.x + 1.0;                                                                   // 55  add r0.x, -r0.x, l(1.000000)
    r1.xyz = vec3(-0.0, -0.0, -0.0);                                                      // 56  mov r1.xyz, l(-0.000000,-0.000000,-0.000000,0)
    r1.w = -cb12_35.z;                                                                    // 57  mov r1.w, -cb12[35].z
    r2.xyzw = vs_BLENDINDICES0.xyzw * vec4(FO4_L_765_01001);                              // 58  mul r2.xyzw, v6.xyzw, l(765.010010, 765.010010, 765.010010, 765.010010)
    i2.xyzw = ivec4(d3d_ftoi(r2.x), d3d_ftoi(r2.y), d3d_ftoi(r2.z), d3d_ftoi(r2.w));      // 59  ftoi r2.xyzw, r2.xyzw
    i3.xyzw = ivec4((i2.x + 1), (i2.x + 2), (i2.y + 1), (i2.y + 2));                      // 60  iadd r3.xyzw, r2.xxyy, l(1, 2, 1, 2)
    r4.xyzw = r1.zzzw + d3d_cb10(i3.w + 0).xyzw;                                          // 61  add r4.xyzw, r1.zzzw, cb10[r3.w + 0].xyzw
    r4.xyzw = r4.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 62  mul r4.xyzw, r4.xyzw, v5.yyyy
    r5.xyzw = r1.zzzw + d3d_cb10(i3.y + 0).xyzw;                                          // 63  add r5.xyzw, r1.zzzw, cb10[r3.y + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.xxxx * r5.xyzw + r4.xyzw;                                   // 64  mad r4.xyzw, v5.xxxx, r5.xyzw, r4.xyzw
    i5.xyzw = ivec4((i2.z + 1), (i2.z + 2), (i2.w + 1), (i2.w + 2));                      // 65  iadd r5.xyzw, r2.zzww, l(1, 2, 1, 2)
    r6.xyzw = r1.zzzw + d3d_cb10(i5.y + 0).xyzw;                                          // 66  add r6.xyzw, r1.zzzw, cb10[r5.y + 0].xyzw
    r1.xyzw = r1.xyzw + d3d_cb10(i5.w + 0).xyzw;                                          // 67  add r1.xyzw, r1.xyzw, cb10[r5.w + 0].xyzw
    r4.xyzw = vs_BLENDWEIGHT0.zzzz * r6.xyzw + r4.xyzw;                                   // 68  mad r4.xyzw, v5.zzzz, r6.xyzw, r4.xyzw
    r1.xyzw = r0.xxxx * r1.xyzw + r4.xyzw;                                                // 69  mad r1.xyzw, r0.xxxx, r1.xyzw, r4.xyzw
    r4.xyz = vs_POSITION0.xyz;                                                            // 70  mov r4.xyz, v0.xyzx
    r4.w = 1.0;                                                                           // 71  mov r4.w, l(1.000000)
#endif
    r6.z = (cpu_ps.z - cpu_ps.w * cb12_35.z);                                             // 72  dp4 r6.z, r4.xyzw, r1.xyzw   [CPU route: mov r6.z, vcpup.z]
#ifdef ENGINE_MOTION_VECTORS
    r7.xz = vec2(-0.0, -0.0);                                                             // 73  mov r7.xz, l(-0.000000,0,-0.000000,0)
    r7.yw = -cb12_35.xy;                                                                  // 74  mov r7.yw, -cb12[35].xxxy
    r8.xyzw = r7.xxxy + d3d_cb10(i2.y + 0).xyzw;                                          // 75  add r8.xyzw, r7.xxxy, cb10[r2.y + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 76  mul r8.xyzw, r8.xyzw, v5.yyyy
    r9.xyzw = r7.xxxy + d3d_cb10(i2.x + 0).xyzw;                                          // 77  add r9.xyzw, r7.xxxy, cb10[r2.x + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.xxxx * r9.xyzw + r8.xyzw;                                   // 78  mad r8.xyzw, v5.xxxx, r9.xyzw, r8.xyzw
    r9.xyzw = r7.xxxy + d3d_cb10(i2.z + 0).xyzw;                                          // 79  add r9.xyzw, r7.xxxy, cb10[r2.z + 0].xyzw
    r2.xyzw = r7.xxxy + d3d_cb10(i2.w + 0).xyzw;                                          // 80  add r2.xyzw, r7.xxxy, cb10[r2.w + 0].xyzw
    r8.xyzw = vs_BLENDWEIGHT0.zzzz * r9.xyzw + r8.xyzw;                                   // 81  mad r8.xyzw, v5.zzzz, r9.xyzw, r8.xyzw
    r2.xyzw = r0.xxxx * r2.xyzw + r8.xyzw;                                                // 82  mad r2.xyzw, r0.xxxx, r2.xyzw, r8.xyzw
#endif
    r6.x = (cpu_ps.x - cpu_ps.w * cb12_35.x);                                             // 83  dp4 r6.x, r4.xyzw, r2.xyzw   [CPU route: mov r6.x, vcpup.x]
#ifdef ENGINE_MOTION_VECTORS
    r8.xyzw = r7.zzzw + d3d_cb10(i3.z + 0).xyzw;                                          // 84  add r8.xyzw, r7.zzzw, cb10[r3.z + 0].xyzw
    r3.xyzw = r7.zzzw + d3d_cb10(i3.x + 0).xyzw;                                          // 85  add r3.xyzw, r7.zzzw, cb10[r3.x + 0].xyzw
    r8.xyzw = r8.xyzw * vs_BLENDWEIGHT0.yyyy;                                             // 86  mul r8.xyzw, r8.xyzw, v5.yyyy
    r3.xyzw = vs_BLENDWEIGHT0.xxxx * r3.xyzw + r8.xyzw;                                   // 87  mad r3.xyzw, v5.xxxx, r3.xyzw, r8.xyzw
    r8.xyzw = r7.zzzw + d3d_cb10(i5.x + 0).xyzw;                                          // 88  add r8.xyzw, r7.zzzw, cb10[r5.x + 0].xyzw
    r5.xyzw = r7.zzzw + d3d_cb10(i5.z + 0).xyzw;                                          // 89  add r5.xyzw, r7.zzzw, cb10[r5.z + 0].xyzw
    r3.xyzw = vs_BLENDWEIGHT0.zzzz * r8.xyzw + r3.xyzw;                                   // 90  mad r3.xyzw, v5.zzzz, r8.xyzw, r3.xyzw
    r0.xyzw = r0.xxxx * r5.xyzw + r3.xyzw;                                                // 91  mad r0.xyzw, r0.xxxx, r5.xyzw, r3.xyzw
#endif
    r6.y = (cpu_ps.y - cpu_ps.w * cb12_35.y);                                             // 92  dp4 r6.y, r4.xyzw, r0.xyzw   [CPU route: mov r6.y, vcpup.y]
    r6.w = 1.0;                                                                           // 93  mov r6.w, l(1.000000)
    o0.x = dot(cb12_viewproj[0].xyzw, r6.xyzw);                                           // 94  dp4 o0.x, cb12[8].xyzw, r6.xyzw
    o0.y = dot(cb12_viewproj[1].xyzw, r6.xyzw);                                           // 95  dp4 o0.y, cb12[9].xyzw, r6.xyzw
    o0.w = dot(cb12_viewproj[3].xyzw, r6.xyzw);                                           // 96  dp4 o0.w, cb12[11].xyzw, r6.xyzw
    r0.w = dot(cb12_viewproj[2].xyzw, r6.xyzw);                                           // 97  dp4 r0.w, cb12[10].xyzw, r6.xyzw
    o0.z = r0.w;                                                                          // 98  mov o0.z, r0.w
    o2.w = r0.w;                                                                          // 99  mov o2.w, r0.w
    o1.xy = vs_TEXCOORD0.xy * TexcoordOffset.zw + TexcoordOffset.xy;                      // 100  mad o1.xy, v1.xyxx, cb1[2].zwzz, cb1[2].xyxx
    o2.xyz = r6.xyz;                                                                      // 101  mov o2.xyz, r6.xyzx
    o6.xyz = -r6.xyz + EyePosition.xyz;                                                   // 102  add o6.xyz, -r6.xyzx, cb2[3].xyzx
#ifdef ENGINE_MOTION_VECTORS
    r3.x = vs_POSITION0.w;                                                                // 103  mov r3.x, v0.w
    r3.y = vs_NORMAL0.w * 2.0 + -1.0;                                                     // 104  mad r3.y, v2.w, l(2.000000), l(-1.000000)
    r3.z = vs_BINORMAL0.w * 2.0 + -1.0;                                                   // 105  mad r3.z, v3.w, l(2.000000), l(-1.000000)
#endif
    r4.y = cpu_r2.y;                                                                      // 106  dp3 r4.y, r3.xyzx, r0.xyzx   [CPU route: mov r4.y, vcpux.y]
    r4.z = cpu_r2.z;                                                                      // 107  dp3 r4.z, r3.xyzx, r1.xyzx   [CPU route: mov r4.z, vcpux.z]
    r4.x = cpu_r2.x;                                                                      // 108  dp3 r4.x, r3.xyzx, r2.xyzx   [CPU route: mov r4.x, vcpux.x]
    r0.w = dot(r4.xyz, r4.xyz);                                                           // 109  dp3 r0.w, r4.xyzx, r4.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 110  rsq r0.w, r0.w
    r3.xyz = r0.www * r4.xyz;                                                             // 111  mul r3.xyz, r0.wwww, r4.xyzx
    o3.x = r3.x;                                                                          // 112  mov o3.x, r3.x
#ifdef ENGINE_MOTION_VECTORS
    r4.xyz = vs_BINORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);             // 113  mad r4.xyz, v3.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
#endif
    r5.y = cpu_r1.y;                                                                      // 114  dp3 r5.y, r4.xyzx, r0.xyzx   [CPU route: mov r5.y, vcpub.y]
    r5.z = cpu_r1.z;                                                                      // 115  dp3 r5.z, r4.xyzx, r1.xyzx   [CPU route: mov r5.z, vcpub.z]
    r5.x = cpu_r1.x;                                                                      // 116  dp3 r5.x, r4.xyzx, r2.xyzx   [CPU route: mov r5.x, vcpub.x]
    r0.w = dot(r5.xyz, r5.xyz);                                                           // 117  dp3 r0.w, r5.xyzx, r5.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 118  rsq r0.w, r0.w
    r4.xyz = r0.www * r5.xyz;                                                             // 119  mul r4.xyz, r0.wwww, r5.xyzx
    o3.y = r4.x;                                                                          // 120  mov o3.y, r4.x
#ifdef ENGINE_MOTION_VECTORS
    r5.xyz = vs_NORMAL0.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);               // 121  mad r5.xyz, v2.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(-1.000000, -1.000000, -1.000000, 0.000000)
#endif
    r0.y = cpu_r0.y;                                                                      // 122  dp3 r0.y, r5.xyzx, r0.xyzx   [CPU route: mov r0.y, vcpun.y]
    r0.z = cpu_r0.z;                                                                      // 123  dp3 r0.z, r5.xyzx, r1.xyzx   [CPU route: mov r0.z, vcpun.z]
    r0.x = cpu_r0.x;                                                                      // 124  dp3 r0.x, r5.xyzx, r2.xyzx   [CPU route: mov r0.x, vcpun.x]
    r0.w = dot(r0.xyz, r0.xyz);                                                           // 125  dp3 r0.w, r0.xyzx, r0.xyzx
    r0.w = d3d_rsq(r0.w);                                                                 // 126  rsq r0.w, r0.w
    r0.xyz = r0.www * r0.xyz;                                                             // 127  mul r0.xyz, r0.wwww, r0.xyzx
    o3.z = r0.x;                                                                          // 128  mov o3.z, r0.x
    o4.x = r3.y;                                                                          // 129  mov o4.x, r3.y
    o5.x = r3.z;                                                                          // 130  mov o5.x, r3.z
    o4.y = r4.y;                                                                          // 131  mov o4.y, r4.y
    o5.y = r4.z;                                                                          // 132  mov o5.y, r4.z
    o4.z = r0.y;                                                                          // 133  mov o4.z, r0.y
    o5.z = r0.z;                                                                          // 134  mov o5.z, r0.z
    r0.xyz = vec3(d3d_log2(vs_COLOR0.x), d3d_log2(vs_COLOR0.y), d3d_log2(vs_COLOR0.z));   // 135  log r0.xyz, v4.xyzx
    r0.xyz = r0.xyz * vec3(FO4_L_2_2);                                                    // 136  mul r0.xyz, r0.xyzx, l(2.200000, 2.200000, 2.200000, 0.000000)
    o7.xyz = vec3(d3d_exp2(r0.x), d3d_exp2(r0.y), d3d_exp2(r0.z));                        // 137  exp o7.xyz, r0.xyzx
    o7.w = vs_COLOR0.w;                                                                   // 138  mov o7.w, v4.w
    return;                                                                               // 139  ret
}
void engine_main()
{
    vec4 o0, o1, o2, o3, o4, o5, o6, o7;
    Fo4LitVsCpu_rec1493(o0, o1, o2, o3, o4, o5, o6, o7);
    gl_Position = gl43ClipToGl(o0);
    lit_TEXCOORD0.xy = o1.xy;
    lit_TEXCOORD4.xyzw = o2.xyzw;
    lit_TEXCOORD1.xyz = o3.xyz;
    lit_TEXCOORD2.xyz = o4.xyz;
    lit_TEXCOORD3.xyz = o5.xyz;
    lit_TEXCOORD5.xyz = o6.xyz;
    lit_COLOR0.xyzw = o7.xyzw;
}
//#### END Fo4LitVsCpu_rec1493 ####
